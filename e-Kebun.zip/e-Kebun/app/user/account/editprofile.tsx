import React, { useEffect, useState } from 'react';
import { View, Text, TextInput, Button, StyleSheet, Image, TouchableOpacity, Alert } from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import RNPickerSelect from 'react-native-picker-select';
import { db } from '../../src/firebaseConfig';
import { collection, doc, getDocs, updateDoc } from 'firebase/firestore';
import { getAuth } from 'firebase/auth';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { ScrollView } from 'react-native'; 

const EditProfile = () => {
  const [userDetails, setUserDetails] = useState<any>(null);
  const [profilePicture, setProfilePicture] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const router = useRouter();

  const [availableStates, setAvailableStates] = useState<string[]>([]);
  const [availableCities, setAvailableCities] = useState<string[]>([]);
  const [availablePostcodes, setAvailablePostcodes] = useState<number[]>([]);
  const [availableSections, setAvailableSections] = useState<string[]>([]);

  useEffect(() => {
    const fetchUserData = async () => {
      try {
        const auth = getAuth();
        const currentUser = auth.currentUser;

        if (currentUser) {
          const userCollection = collection(db, 'user');
          const querySnapshot = await getDocs(userCollection);

          querySnapshot.forEach((doc) => {
            const data = doc.data();
            if (data.email === currentUser.email) {
              setUserDetails({ ...data, id: doc.id });
              setProfilePicture(data.profilePicture || null);
            }
          });
        } else {
          Alert.alert('Not Authenticated', 'Please log in to edit your profile.');
        }
      } catch (error) {
        console.error('Error fetching user data:', error);
      }
    };

    fetchUserData();
  }, []);

  useEffect(() => {
    const fetchStates = async () => {
      try {
        const locationSnapshot = await getDocs(collection(db, 'location'));
        const states: string[] = [];
        locationSnapshot.forEach((doc) => {
          const state = doc.data().state;
          if (!states.includes(state)) states.push(state);
        });
        setAvailableStates(states);
      } catch (error) {
        console.error('Error fetching states:', error);
      }
    };

    fetchStates();
  }, []);

  useEffect(() => {
    if (userDetails?.location?.state) {
      const fetchCities = async () => {
        try {
          const citySnapshot = await getDocs(collection(db, 'location'));
          const cities: string[] = [];
          citySnapshot.forEach((doc) => {
            const city = doc.data().city;
            if (doc.data().state === userDetails.location.state && !cities.includes(city)) {
              cities.push(city);
            }
          });
          setAvailableCities(cities);
        } catch (error) {
          console.error('Error fetching cities:', error);
        }
      };

      fetchCities();
    }
  }, [userDetails?.location?.state]);

  useEffect(() => {
    if (userDetails?.location?.city) {
      const fetchPostcodes = async () => {
        try {
          const postcodeSnapshot = await getDocs(collection(db, 'location'));
          const postcodes: number[] = [];
          postcodeSnapshot.forEach((doc) => {
            const postcode = doc.data().postcode;
            if (doc.data().city === userDetails.location.city && !postcodes.includes(postcode)) {
              postcodes.push(postcode);
            }
          });
          setAvailablePostcodes(postcodes);
        } catch (error) {
          console.error('Error fetching postcodes:', error);
        }
      };

      fetchPostcodes();
    }
  }, [userDetails?.location?.city]);

  useEffect(() => {
    if (userDetails?.location?.postcode) {
      const fetchSections = async () => {
        try {
          const sectionSnapshot = await getDocs(collection(db, 'location'));
          const sections: string[] = [];
          sectionSnapshot.forEach((doc) => {
            const section = doc.data().section;
            if (doc.data().postcode === userDetails.location.postcode && !sections.includes(section)) {
              sections.push(section);
            }
          });
          setAvailableSections(sections);
        } catch (error) {
          console.error('Error fetching sections:', error);
        }
      };

      fetchSections();
    }
  }, [userDetails?.location?.postcode]);

  const validateUsername = async (username: string) => {
    try {
      const usersSnapshot = await getDocs(collection(db, 'user')); 
      for (const doc of usersSnapshot.docs) {
        if (doc.data().username === username && doc.id !== userDetails.id) {
          return false; 
        }
      }
      return true; 
    } catch (error) {
      console.error('Error validating username:', error);
      return false;
    }
  };

  const handleImageChange = async () => {
    const permissionResult = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (permissionResult.granted) {
      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        quality: 1,
      });

      if (!result.canceled && result.assets && result.assets.length > 0) {
        const imageUri = result.assets[0].uri;
        setProfilePicture(imageUri); 
      }
    } else {
      Alert.alert('Permission', 'Permission to access media library is required!');
    }
  };

  const handleSubmit = async () => {
    if (loading) return;
    setLoading(true);
  
    const isUnique = await validateUsername(userDetails.username);
    if (!isUnique) {
      Alert.alert('Error', 'Username is already taken. Please choose another.');
      setLoading(false);
      return;
    }
  
    try {
      const { id, ...userDataWithoutId } = userDetails;
  
      if (profilePicture) {
        userDataWithoutId.profilePicture = profilePicture; 
      }
  
      const userRef = doc(db, 'user', id); 
      await updateDoc(userRef, userDataWithoutId);                                                                                         
      Alert.alert('Success', 'Your profile has been updated successfully.');
      router.back(); 
    } catch (error) {
      console.error('Error updating user data:', error);
      Alert.alert('Error', 'There was an issue saving your profile.');
    } finally {
      setLoading(false);
    }
  };
  
  return (
    <ScrollView contentContainerStyle={styles.scrollContainer}>
      <View style={styles.container}>
        <View style={styles.header}>
          <TouchableOpacity onPress={() => router.back()}>
            <Ionicons name="arrow-back" size={24} color="black" />
          </TouchableOpacity>
          <Text style={styles.title}>Edit Profile</Text>
        </View>

        <TouchableOpacity onPress={async () => await handleImageChange()} style={styles.profilePicContainer}>
          {profilePicture ? (
            <Image source={{ uri: profilePicture }} style={styles.profileImage} />
          ) : (
            <Text style={styles.addProfileText}>Add Profile Picture</Text>
          )}
        </TouchableOpacity>

        <Text style={styles.label}>Name</Text>
        <TextInput
          value={userDetails?.name || ''} 
          onChangeText={(text) => setUserDetails({ ...userDetails, name: text })}
          placeholder="Name"
          style={styles.input}
        />

        <Text style={styles.label}>Email</Text>
        <TextInput
          value={userDetails?.email || ''} 
          editable={false} 
          style={styles.input}
        />

        <Text style={styles.label}>Phone Number</Text>
        <TextInput
          value={userDetails?.phoneno ? userDetails.phoneno.toString() : ''} 
          onChangeText={(text) => {
            const numericValue = text.replace(/\D/g, ''); 
            setUserDetails({ ...userDetails, phoneno: numericValue });
          }}
          placeholder="Phone Number"
          keyboardType="numeric"  
          style={styles.input}
        />

        <Text style={styles.label}>Username</Text>
        <TextInput
          value={userDetails?.username || ''} 
          onChangeText={(text) => setUserDetails({ ...userDetails, username: text })}
          placeholder="Username"
          style={styles.input}
        />

        <Text style={styles.label}>Section</Text>
        <RNPickerSelect
          value={userDetails?.location?.section}
          onValueChange={(value) =>
            setUserDetails({ ...userDetails, location: { ...userDetails.location, section: value } })
          }
          items={availableSections.map((section) => ({ label: section, value: section }))}
        />

        <Text style={styles.label}>Postcode</Text>
        <RNPickerSelect
          value={userDetails?.location?.postcode}
          onValueChange={(value) =>
            setUserDetails({ ...userDetails, location: { ...userDetails.location, postcode: value } })
          }
          items={availablePostcodes.map((postcode) => ({
            label: postcode.toString(),  
            value: postcode.toString()   
          }))}
        />

        <Text style={styles.label}>City</Text>
        <RNPickerSelect
          value={userDetails?.location?.city}
          onValueChange={(value) =>
            setUserDetails({ ...userDetails, location: { ...userDetails.location, city: value } })
          }
          items={availableCities.map((city) => ({ label: city, value: city }))}
        />

        <Text style={styles.label}>State</Text>
        <RNPickerSelect
          value={userDetails?.location?.state}
          onValueChange={(value) =>
            setUserDetails({ ...userDetails, location: { ...userDetails.location, state: value } })
          }
          items={availableStates.map((state) => ({ label: state, value: state }))}
        />

        <View style={styles.buttonContainer}>
          <TouchableOpacity
            style={[styles.button, { backgroundColor: loading ? '#ddd' : '#4CAF50' }]}
            onPress={handleSubmit}
            disabled={loading}
          >
            <Text style={styles.buttonText}>{loading ? 'Saving...' : 'Save Changes'}</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={[styles.button, { backgroundColor: '#f44336' }]}
            onPress={() => router.push('/user/account/changepassword')} 
          >
            <Text style={styles.buttonText}>Reset Password</Text>
          </TouchableOpacity>
        </View>
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: 'white',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 20,
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
    marginLeft: 10,
  },
  profilePicContainer: {
    alignItems: 'center',
    marginBottom: 20,
  },
  profileImage: {
    width: 100,
    height: 100,
    borderRadius: 50,
  },
  addProfileText: {
    fontSize: 16,
    color: '#888',
  },
  input: {
    borderWidth: 1,
    borderColor: '#ccc',
    padding: 10,
    marginBottom: 10,
    borderRadius: 5,
  },
  label: {
    fontWeight: 'bold',
    marginBottom: 5,
  },
  scrollContainer: {
    flexGrow: 1,
  },
  buttonContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 20,
  },
  button: {
    flex: 1,
    marginHorizontal: 5,
    padding: 15,
    borderRadius: 5,
    alignItems: 'center',
  },
  buttonText: {
    color: 'white',
    fontWeight: 'bold',
  },
});

export default EditProfile;
