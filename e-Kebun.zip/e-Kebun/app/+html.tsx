import { ScrollViewStyleReset } from 'expo-router/html';
import { type PropsWithChildren } from 'react';

/**
 * This file is web-only and configures the root HTML for every web page during static rendering.
 * The contents of this function only run in Node.js environments and do not have access to the DOM or browser APIs.
 */
export default function Root({ children }: PropsWithChildren) {
  return (
    <html lang="en">
      <head>
        <meta charSet="utf-8" />
        <meta httpEquiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />

        {/* 
          Disable body scrolling on web. This makes ScrollView components work closer to how they do on native.
          However, body scrolling can be beneficial for mobile web. Remove this line to enable it.
        */}
        <ScrollViewStyleReset />

        {/* Raw CSS styles to ensure the background color does not flicker in dark mode */}
        <style dangerouslySetInnerHTML={{ __html: responsiveBackground }} />
        {/* Add any additional <head> elements that you want globally available on web... */}
      </head>
      <body>{children}</body>
    </html>
  );
}

// Define responsive background styles
const responsiveBackground = `
  body {
    background-color: #fff;
  }
  @media (prefers-color-scheme: dark) {
    body {
      background-color: #000;
    }
  }
`;
