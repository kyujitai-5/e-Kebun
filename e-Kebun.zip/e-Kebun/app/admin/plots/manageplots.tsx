import React, { useState, useEffect } from 'react';
import { View, Text, FlatList, TextInput, TouchableOpacity, StyleSheet } from 'react-native';
import { db } from '../../src/firebaseConfig';
import { collection, getDocs, query, where } from 'firebase/firestore';
import { useRouter, useLocalSearchParams } from 'expo-router';
import { Ionicons } from '@expo/vector-icons'; // For the back button

interface PlotAreaData {
  id: string;
  name: string;
  description: string;
}

const ManagePlots = () => {
  const { state, city, postcode, section } = useLocalSearchParams();  // Now using 'state', 'city', 'postcode', and 'section' as filters
  const router = useRouter();
  const [plotAreas, setPlotAreas] = useState<PlotAreaData[]>([]);
  const [searchText, setSearchText] = useState('');

  useEffect(() => {
    console.log('Query Params:', { state, city, postcode, section });

    const fetchPlotAreas = async () => {
      try {
        let plotAreaQuery = query(collection(db, 'plotarea'));

        // Filter by state
        if (state) {
          plotAreaQuery = query(plotAreaQuery, where('location.state', '==', state));
          console.log('Filter: State =', state);
        }

        // Filter by city
        if (city) {
          plotAreaQuery = query(plotAreaQuery, where('location.city', '==', city));
          console.log('Filter: City =', city);
        }

        // Filter by postcode
        if (postcode) {
          plotAreaQuery = query(plotAreaQuery, where('location.postcode', '==', parseInt(postcode as string))); // Ensure postcode is treated as a number
          console.log('Filter: Postcode =', postcode);
        }

        // Filter by section
        if (section) {
          plotAreaQuery = query(plotAreaQuery, where('location.section', '==', section));
          console.log('Filter: Section =', section);
        }

        // Fetch plot areas
        const plotAreaSnapshot = await getDocs(plotAreaQuery);

        // Check if no documents are returned
        if (plotAreaSnapshot.empty) {
          console.log('No plot areas found for the given filter.');
          setPlotAreas([]); // Reset to empty list
          return;
        }

        // Map fetched data
        const fetchedPlotAreas = plotAreaSnapshot.docs.map((doc) => ({
          id: doc.id,
          name: doc.data().name,
          description: doc.data().description || '',
        }));

        console.log('Fetched Plot Areas:', fetchedPlotAreas);
        setPlotAreas(fetchedPlotAreas);
      } catch (error) {
        console.error('Error fetching plot areas:', error);
      }
    };

    fetchPlotAreas();
  }, [state, city, postcode, section]);  

  const filteredPlotAreas = plotAreas.filter((plotArea) =>
    (plotArea.name?.toLowerCase() || "").includes(searchText.toLowerCase()) ||
    (plotArea.id?.toLowerCase() || "").includes(searchText.toLowerCase()) ||
    (plotArea.description?.toLowerCase() || "").includes(searchText.toLowerCase())
  );

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.push('/admin/dashboard')}>
        <Ionicons name="arrow-back" size={24} color="black" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Manage Plot Area</Text>
      </View>

      <View style={styles.searchContainer}>
        <TextInput
          style={styles.searchInput}
          placeholder="Search by name, ID, or description..."
          value={searchText}
          onChangeText={setSearchText}
        />
      </View>

      <View style={styles.buttonContainer}>
        <TouchableOpacity style={styles.button} onPress={() => router.push('/admin/plots/plotattributes')}>
          <Text style={styles.buttonText}>Attributes</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.button} onPress={() => router.push('/admin/plots/archivedplotareas')}>
          <Text style={styles.buttonText}>Archived</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.button} onPress={() => router.push('/admin/plots/addnewarea')}>
          <Text style={styles.buttonText}>Add New</Text>
        </TouchableOpacity>
      </View>

      <FlatList
        data={filteredPlotAreas}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <TouchableOpacity
            onPress={() => router.push(`/admin/plots/plotareadetails?id=${item.id}`)}
            style={styles.plotItem}
          >
            <Text style={styles.plotId}>ID: {item.id}</Text>
            <Text style={styles.plotName}>{item.name}</Text>
            <Text style={styles.plotDescription}>{item.description}</Text>
          </TouchableOpacity>
        )}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#fff',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 20,
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    marginLeft: 10,
  },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginVertical: 10,
  },
  searchInput: {
    flex: 1,
    height: 40,
    borderColor: '#ccc',
    borderWidth: 1,
    paddingLeft: 8,
    marginRight: 10,
  },
  filterIcon: {
    padding: 10,
  },
  filterText: {
    fontSize: 20,
  },
  buttonContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginVertical: 10,
  },
  button: {
    backgroundColor: '#007BFF',
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 5,
  },
  buttonText: {
    color: '#fff',
    fontSize: 16,
  },
  plotItem: {
    padding: 15,
    backgroundColor: '#f9f9f9',
    marginVertical: 5,
    borderRadius: 5,
  },
  plotId: {
    fontSize: 14,
    color: '#777',
  },
  plotName: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  plotDescription: {
    fontSize: 14,
    color: '#777',
  },
});

export default ManagePlots;
