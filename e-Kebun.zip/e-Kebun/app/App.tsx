import { useEffect } from 'react';
import { useRouter } from 'expo-router';
import { app } from './src/firebaseConfig';
import { getAuth } from 'firebase/auth';

export default function App() {
  const router = useRouter(); 

  useEffect(() => {
    const auth = getAuth(app);
    const user = auth.currentUser; 

    if (user) {
      router.push('/splash'); 
    } else {
      router.push('/splash'); 
    }
  }, [router]);
}