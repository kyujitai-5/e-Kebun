import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Image, Alert } from 'react-native';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import { getFirestore, collection, getDocs } from 'firebase/firestore';
import { LineChart } from 'react-native-chart-kit';
import { Dimensions } from 'react-native';

interface SalesData {
  rentalStartDate: string;
  price: number;
}

interface GroupedSales {
  [month: string]: number; 
}

const groupSalesByMonth = (sales: SalesData[]): GroupedSales => {
  const grouped: GroupedSales = {}; 
  sales.forEach(sale => {
    const date = new Date(sale.rentalStartDate);
    const month = `${date.getFullYear()}-${date.getMonth() + 1}`;
    if (!grouped[month]) {
      grouped[month] = 0;
    }
    grouped[month] += sale.price;
  });
  return grouped;
};

const Dashboard = () => {
  const router = useRouter();
  const [salesData, setSalesData] = useState<SalesData[]>([]); 
  const [monthlySales, setMonthlySales] = useState<GroupedSales>({});

  useEffect(() => {
    const fetchData = async () => {
      const db = getFirestore();
      const rentRef = collection(db, 'rent');
      const snapshot = await getDocs(rentRef);
      const rentData = snapshot.docs.map(doc => doc.data()) as SalesData[]; 
      setSalesData(rentData);

      const groupedSales = groupSalesByMonth(rentData);
      setMonthlySales(groupedSales);
    };

    fetchData(); 
  }, []); 

  const chartData = {
    labels: Object.keys(monthlySales), 
    datasets: [
      {
        data: Object.values(monthlySales), 
      },
    ],
  };

  const handleLogOut = () => {
    Alert.alert(
      "Log Out", 
      "Are you sure you want to log out?", 
      [
        { text: "Cancel", style: "cancel" },
        { text: "Log Out", onPress: () => router.push('/(auth)/login') },
      ],
      { cancelable: true }
    );
  };

  const managePage = (path: string) => {
    router.push(path as any);
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Image source={require('../../assets/images/Logo.png')} style={styles.logo} />
        <View style={styles.headerIcons}>
          <TouchableOpacity onPress={handleLogOut}>
            <MaterialCommunityIcons name="logout" size={24} color="black" style={styles.icon} />
          </TouchableOpacity>
        </View>
      </View>

      <View style={styles.graphPlaceholder}>
        <Text style={styles.graphText}>Monthly Plot Rental Sales</Text>
        {Object.keys(monthlySales).length > 0 ? (
          <LineChart
            data={chartData}
            width={Dimensions.get('window').width - 40} 
            height={220}
            chartConfig={{
              backgroundColor: 'transparent',
              backgroundGradientFrom: 'white',
              backgroundGradientTo: 'white',
              decimalPlaces: 2,
              color: (opacity = 1) => `rgba(0, 0, 255, ${opacity})`,
              labelColor: (opacity = 1) => `rgba(0, 0, 0, ${opacity})`,
              style: {
                borderRadius: 16
              },
              propsForDots: {
                r: '6',
                strokeWidth: '2',
                stroke: '#ffa726',
              },
            }}
            bezier
          />
        ) : (
          <Text>No sales data available</Text>
        )}
      </View>

      <View style={styles.iconContainer}>
        <View style={styles.row}>
          <TouchableOpacity
            style={styles.iconButton}
            onPress={() => managePage('/admin/manage/manageusers')}
          >
            <MaterialCommunityIcons name="account" size={28} color="black" />
            <Text style={styles.iconLabel}>User</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={styles.iconButton}
            onPress={() => managePage('/admin/plots/manageplots')}
          >
            <MaterialCommunityIcons name="leaf" size={28} color="black" />
            <Text style={styles.iconLabel}>Plot</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={styles.iconButton}
            onPress={() => managePage('/admin/manage/managelistings')}
          >
            <MaterialCommunityIcons name="basket" size={28} color="black" />
            <Text style={styles.iconLabel}>Listing</Text>
          </TouchableOpacity>
        </View>

        <View style={styles.row}>
          <TouchableOpacity
            style={styles.iconButton}
            onPress={() => managePage('/admin/manage/managesales')} 
          >
            <MaterialCommunityIcons name="chart-bar" size={28} color="black" />
            <Text style={styles.iconLabel}>Sales</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={styles.iconButton}
            onPress={() => managePage('/admin/marketing/manageads')}
          >
            <MaterialCommunityIcons name="bullhorn" size={28} color="black" />
            <Text style={styles.iconLabel}>Marketing</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={styles.iconButton}
            onPress={() => managePage('/admin/manage/managefinances')}
          >
            <MaterialCommunityIcons name="wallet" size={28} color="black" />
            <Text style={styles.iconLabel}>Finance</Text>
          </TouchableOpacity>
        </View>

        <View style={styles.row}>
          <TouchableOpacity
            style={styles.iconButton}
            onPress={() => managePage('/admin/manage/reportedareas')}
          >
            <MaterialCommunityIcons name="map-marker-alert" size={28} color="black" />
            <Text style={styles.iconLabel}>Reported Areas</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={styles.iconButton}
            onPress={() => managePage('/admin/manage/feedbacks')}
          >
            <MaterialCommunityIcons name="message-reply" size={28} color="black" />
            <Text style={styles.iconLabel}>Feedback</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={styles.iconButton}
            onPress={() => managePage('/admin/blogs/manageblogs')}
          >
            <MaterialCommunityIcons name="pen" size={28} color="black" />
            <Text style={styles.iconLabel}>Blog</Text>
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    paddingHorizontal: 20,
    paddingTop: 40,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  logo: {
    width: 100,
    height: 40,
    resizeMode: 'contain',
  },
  headerIcons: {
    flexDirection: 'row',
  },
  icon: {
    marginHorizontal: 10,
  },
  graphPlaceholder: {
    marginVertical: 50,
    backgroundColor: 'white',
    height: 200,
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 10,
  },
  graphText: {
    color: '#888',
    fontStyle: 'italic',
    marginBottom: 20,
  },
  iconContainer: {
    flex: 1,
    marginBottom: 20,
  },
  row: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    marginBottom: 20,
  },
  iconButton: {
    alignItems: 'center',
    backgroundColor: '#ededed',
    padding: 20,
    borderRadius: 15,
    width: '30%',
    marginBottom: 10,
    justifyContent: 'center',
  },
  iconLabel: {
    marginTop: 8,
    fontSize: 10,
    textAlign: 'center',
  },
});

export default Dashboard;
