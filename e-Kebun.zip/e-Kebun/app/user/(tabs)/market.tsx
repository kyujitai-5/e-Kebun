import React, { useState, useEffect } from 'react';
import { View, Text, FlatList, TextInput, TouchableOpacity, StyleSheet, Image, Dimensions } from 'react-native';
import { db } from '../../src/firebaseConfig'; // Adjust import based on your setup
import { collection, getDocs, query, where } from 'firebase/firestore';
import { useRouter, useLocalSearchParams } from 'expo-router';
import Icon from 'react-native-vector-icons/Ionicons';

interface Listing {
  title: string;
  price: number;
  images: string[];
  status: 'active' | 'inactive';
  docId: string;
  location: {
    state: string;
    city: string;
    postcode: string;
    section?: string;
  };
}

const Market = () => {
  const router = useRouter();
  const params = useLocalSearchParams();

  const [listings, setListings] = useState<Listing[]>([]);
  const [searchText, setSearchText] = useState('');
  const [locationFilter, setLocationFilter] = useState({
    state: '',
    city: '',
    postcode: '',
    section: '',
  });

  useEffect(() => {
    const { filterParams, activeListings } = params;
  
    // Only update locationFilter if filterParams exists and has changed
    if (filterParams && typeof filterParams === 'string') {
      const parsedFilterParams = JSON.parse(filterParams);
      if (JSON.stringify(parsedFilterParams) !== JSON.stringify(locationFilter)) {
        setLocationFilter(parsedFilterParams); // Update only if different
      }
    }

    // Only set activeListings if it exists and has changed
    if (activeListings && typeof activeListings === 'string') {
      const parsedActiveListings = JSON.parse(activeListings);
      if (JSON.stringify(parsedActiveListings) !== JSON.stringify(listings)) {
        setListings(parsedActiveListings); // Update only if different
      }
    } else {
      fetchListings(); // Fetch data if no active listings provided
    }
  }, [params, locationFilter, listings]); // Add locationFilter and listings as dependencies to prevent unnecessary reruns
  
  // Fetch all active listings 
  const fetchListings = async () => {
    try {
      let listingsQuery = query(
        collection(db, 'listing'),
        where('status', '==', 'active')
      );

      if (locationFilter.state) {
        listingsQuery = query(
          listingsQuery,
          where('location.state', '==', locationFilter.state)
        );
      }

      if (locationFilter.city) {
        listingsQuery = query(
          listingsQuery,
          where('location.city', '==', locationFilter.city)
        );
      }

      if (locationFilter.postcode) {
        listingsQuery = query(
          listingsQuery,
          where('location.postcode', '==', locationFilter.postcode)
        );
      }

      if (locationFilter.section) {
        listingsQuery = query(
          listingsQuery,
          where('location.section', '==', locationFilter.section)
        );
      }

      const querySnapshot = await getDocs(listingsQuery);

      if (querySnapshot.empty) {
        setListings([]); // Ensure to clear listings if no results
        return;
      }

      const fetchedListings = querySnapshot.docs.map((doc) => {
        const data = doc.data();
        return {
          title: data.title,
          price: data.price,
          images: Array.isArray(data.images) && data.images.length > 0 ? data.images : ['https://via.placeholder.com/150'],
          status: data.status,
          docId: doc.id,
        } as Listing;
      });

      setListings(fetchedListings); // Update state with fetched listings
    } catch (error) {
      console.error('Error fetching listings:', error);
    }
  };

  const filteredListings = listings.filter(
    (listing) => listing.title.toLowerCase().includes(searchText.toLowerCase())
    
  );

  const handleListingPress = (docId: string) => {
    console.log("Pressed Listing with docId:", docId);

    router.push({
      pathname: '/user/listing/listingdetails',
      params: { docId },
    });
  };

  const handleFilterPress = () => {
    router.push({
      pathname: '/user/(tabs)/(nontabs)/mlocationfilter',
      params: { filterParams: JSON.stringify(locationFilter), activeListings: JSON.stringify(listings) },
    });
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.pageTitle}>Market</Text>
        <TouchableOpacity
          style={styles.cartIcon}
          onPress={() => router.push('/user/listing/listingcart')}
        >
          <Icon name="cart-outline" size={28} color="#333" />
        </TouchableOpacity>
      </View>

      <View style={styles.searchBar}>
        <TextInput
          style={styles.searchInput}
          placeholder="Search listings..."
          value={searchText}
          onChangeText={setSearchText}
        />
        <TouchableOpacity
          style={styles.filterIcon}
          onPress={handleFilterPress} 
        >
          <Icon name="filter-outline" size={28} color="#333" />
        </TouchableOpacity>
      </View>

      <FlatList
        data={filteredListings}
        keyExtractor={(item) => item.docId}
        numColumns={2} 
        contentContainerStyle={styles.gridContainer}
        renderItem={({ item }) => {
          console.log('Item Images:', item.images);

          return (
            <TouchableOpacity
              style={styles.panel}
              onPress={() => handleListingPress(item.docId)}
            >
              <Image
                source={{ uri: item.images[0] || 'https://via.placeholder.com/150' }}
                style={styles.panelImage}
              />
              <Text style={styles.panelTitle} numberOfLines={2}>
                {item.title || 'No Title'}
              </Text>
              <Text style={styles.panelPrice}>RM {item.price || 0}</Text>
            </TouchableOpacity>
          );
        }}
        
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#f9f9f9',
  },
  pageTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    textAlign: 'left',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 15,
  },
  cartIcon: {
    padding: 10,
  },
  searchBar: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 15,
  },
  searchInput: {
    flex: 1,
    height: 40,
    borderColor: '#ccc',
    borderWidth: 1,
    borderRadius: 5,
    paddingHorizontal: 10,
  },
  gridContainer: {
    paddingBottom: 20,
  },
  panel: {
    flex: 1,
    margin: 5,
    backgroundColor: '#f9f9f9',
    borderRadius: 8,
    overflow: 'hidden',
    maxWidth: (Dimensions.get('window').width - 30) / 2,
  },
  panelImage: {
    width: '100%',
    height: 120,
    backgroundColor: '#ddd',
  },
  panelTitle: {
    padding: 10,
    fontSize: 16,
    fontWeight: '600',
    color: '#333',
  },
  panelPrice: {
    paddingHorizontal: 10,
    paddingBottom: 10,
    fontSize: 14,
    fontWeight: 'bold',
    color: '#4CAF50',
  },
  filterIcon: {
    padding: 10,
    marginLeft: 10,
  },
});

export default Market;
