import React, { useState, useEffect } from 'react';
import { View, Text, FlatList, Modal, TouchableOpacity, StyleSheet } from 'react-native';
import { db } from '../../src/firebaseConfig';
import { collection, getDocs } from 'firebase/firestore';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons'; // For the back button

interface RentTransaction {
  id: string; // Document ID
  email: string;
  period: number;
  plotAreaId: string;
  plotId: string;
  plotType: string;
  price: number;
  rentalEndDate: string;
  rentalStartDate: string;
  transactionId: string;
  username: string;
}

const ManageSales = () => {
  const router = useRouter();
  const [sales, setSales] = useState<RentTransaction[]>([]);
  const [modalVisible, setModalVisible] = useState(false);
  const [selectedSale, setSelectedSale] = useState<RentTransaction | null>(null);

  useEffect(() => {
    const fetchSales = async () => {
      try {
        const rentCollection = collection(db, 'rent');
        const rentSnapshot = await getDocs(rentCollection);

        const fetchedSales = rentSnapshot.docs.map((doc) => {
          const data = doc.data();
          const rentalStartDate = new Date(data.rentalStartDate).toLocaleString(); // Convert Firestore timestamp to readable string
          const rentalEndDate = new Date(data.rentalEndDate).toLocaleString(); // Convert Firestore timestamp to readable string

          return {
            id: doc.id,
            email: data.email || '',
            period: data.period || 0,
            plotAreaId: data.plotAreaId || '',
            plotId: data.plotId || '',
            plotType: data.plotType || '',
            price: data.price || 0,
            rentalStartDate: rentalStartDate,
            rentalEndDate: rentalEndDate,
            transactionId: data.transactionId || '',
            username: data.username || '',
          };
        });

        setSales(fetchedSales);
      } catch (error) {
        console.error('Error fetching sales:', error);
      }
    };

    fetchSales();
  }, []);

  const handleItemPress = (sale: RentTransaction) => {
    setSelectedSale(sale);
    setModalVisible(true);
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()}>
          <Ionicons name="arrow-back" size={24} color="black" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Manage Sales</Text>
      </View>

      <FlatList
        data={sales}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <TouchableOpacity
            onPress={() => handleItemPress(item)}
            style={styles.saleItem}
          >
            <Text style={styles.saleId}>ID: {item.id}</Text>
            <Text style={styles.saleDate}>Start: {item.rentalStartDate}</Text>
            <Text style={styles.saleDate}>End: {item.rentalEndDate}</Text> 
          </TouchableOpacity>
        )}
      />

      {selectedSale && (
        <Modal
          visible={modalVisible}
          animationType="fade"
          transparent={true}
          onRequestClose={() => setModalVisible(false)}
        >
          <View style={styles.modalContainer}>
            <View style={styles.modalContent}>
              <TouchableOpacity onPress={() => setModalVisible(false)} style={styles.closeButton}>
                <Ionicons name="close" size={24} color="black" />
              </TouchableOpacity>

              <Text style={styles.modalTitle}>Sale Receipt</Text>
              <View style={styles.receiptContent}>
                <Text style={styles.receiptDetail}>Plot Type: {selectedSale.plotType}</Text>
                <Text style={styles.receiptDetail}>Plot Area ID: {selectedSale.plotAreaId}</Text>
                <Text style={styles.receiptDetail}>Plot ID: {selectedSale.plotId}</Text>
                <Text style={styles.receiptDetail}>Username: {selectedSale.username}</Text>
                <Text style={styles.receiptDetail}>Transaction ID: {selectedSale.transactionId}</Text>
                <Text style={styles.receiptDetail}>Price: RM {selectedSale.price}</Text>
                <Text style={styles.receiptDetail}>Period: {selectedSale.period} year(s)</Text>
                <Text style={styles.receiptDetail}>Start Date: {selectedSale.rentalStartDate}</Text>
                <Text style={styles.receiptDetail}>End Date: {selectedSale.rentalEndDate}</Text>
              </View>
            </View>
          </View>
        </Modal>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#fff',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 20,
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    marginLeft: 10,
  },
  saleItem: {
    padding: 15,
    backgroundColor: '#f9f9f9',
    marginVertical: 5,
    borderRadius: 5,
  },
  saleId: {
    fontSize: 14,
    color: '#777',
  },
  saleDate: {
    fontSize: 12,
    color: '#555',
  },
  modalContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  modalContent: {
    width: '80%',
    backgroundColor: '#fff',
    padding: 20,
    borderRadius: 10,
    alignItems: 'center',
  },
  closeButton: {
    alignSelf: 'flex-end',
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  receiptContent: {
    paddingTop: 20,
    width: '100%',
  },
  receiptDetail: {
    fontSize: 16,
    marginBottom: 10,
    textAlign: 'left',
  },
});

export default ManageSales;
