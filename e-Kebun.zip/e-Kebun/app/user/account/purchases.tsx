import React, { useState, useEffect } from 'react';
import { StyleSheet, View, Text, TouchableOpacity, FlatList, Modal, TextInput, Alert } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { db } from '../../src/firebaseConfig';
import { collection, getDocs, query, where, doc, updateDoc, getDoc, setDoc } from 'firebase/firestore';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { getAuth } from 'firebase/auth';
import { Linking } from 'react-native';
import { router } from 'expo-router';

interface Order {
  id: string;
  sellerUsername: string;
  sellerEmail: string;
  dateTime: string;
  subtotal: number;
  status: string;
}

export default function Purchases() {
  const [activeTab, setActiveTab] = useState<'Pending' | 'Completed' | 'Dispute'>('Pending');
  const [orders, setOrders] = useState<Order[]>([]);
  const [userEmail, setUserEmail] = useState<string | null>(null);
  const [feedbackModalVisible, setFeedbackModalVisible] = useState(false);
  const [feedback, setFeedback] = useState({ description: '', sellerEmail: '', sellerUsername: '', orderId: '' });

  useEffect(() => {
    const fetchUserEmail = async () => {
      try {
        let email = await AsyncStorage.getItem('userEmail');
        if (!email) {
          const auth = getAuth();
          email = auth.currentUser?.email || null;
        }
        setUserEmail(email);
        console.log('Fetched email:', email); // Add console log here
      } catch (error) {
        console.error('Error fetching user email:', error);
      }
    };

    fetchUserEmail();
  }, []);

  useEffect(() => {
    const fetchOrders = async () => {
      if (!userEmail) {
        console.log('User email not loaded yet');
        return;
      }

      try {
        const ordersQuery = query(
          collection(db, 'orders'),
          where('buyerEmail', '==', userEmail),
          where('status', '==', activeTab.toLowerCase()),
        );

        const snapshot = await getDocs(ordersQuery);

        if (snapshot.empty) {
          console.log(`No orders found for status: ${activeTab}`);
          setOrders([]);
          return;
        }

        const fetchedOrders = snapshot.docs.map((doc) => {
          const data = doc.data();
          return {
            id: doc.id,
            sellerUsername: data.sellerUsername || '',
            sellerEmail: data.sellerEmail || '',
            dateTime: data.dateTime?.toDate().toLocaleString() || '',
            subtotal: data.subtotal || 0,
            status: data.status || '',
          } as Order;
        });

        console.log('Fetched orders:', fetchedOrders);
        setOrders(fetchedOrders);
      } catch (error) {
        console.error('Error fetching orders:', error);
      }
    };

    fetchOrders();
  }, [userEmail, activeTab]);

  // Function to handle received and dispute actions
  const handleOrderAction = async (orderId: string, action: 'received' | 'dispute', orderSubtotal: number, sellerEmail: string) => {
    try {
      const orderRef = doc(db, 'orders', orderId);

      if (action === 'received') {
        await updateDoc(orderRef, { status: 'completed' });

        const userQuery = query(collection(db, 'user'), where('email', '==', sellerEmail));
        const userSnapshot = await getDocs(userQuery);

        if (!userSnapshot.empty) {
          const sellerDoc = userSnapshot.docs[0];
          const currentSellerBalance = sellerDoc.exists() ? sellerDoc.data().wallet || 0 : 0;
          await updateDoc(sellerDoc.ref, { wallet: currentSellerBalance + orderSubtotal });
        } else {
          console.error('Seller not found');
        }
      } else if (action === 'dispute') {
        await updateDoc(orderRef, { status: 'dispute' });

        const userQuery = query(collection(db, 'user'), where('email', '==', userEmail || ''));
        const userSnapshot = await getDocs(userQuery);

        if (!userSnapshot.empty) {
          const buyerDoc = userSnapshot.docs[0];
          const currentBuyerBalance = buyerDoc.exists() ? buyerDoc.data().wallet || 0 : 0;
          await updateDoc(buyerDoc.ref, { wallet: currentBuyerBalance + orderSubtotal });
        } else {
          console.error('Buyer not found');
        }
      }

      setActiveTab(activeTab);
    } catch (error) {
      console.error('Error handling order action:', error);
    }
  };

  const handleFeedbackSubmit = async () => {
    if (!feedback.description) {
      alert('Please fill in the feedback description');
      return;
    }
  
    try {
      const orderRef = doc(db, 'orders', feedback.orderId);
      const orderDoc = await getDoc(orderRef);
  
      if (!orderDoc.exists()) {
        alert('Order not found');
        return;
      }
  
      const orderData = orderDoc.data();
      const buyerUsername = orderData?.buyerUsername || '';
  
      const feedbackRef = doc(collection(db, 'feedback'));
      await setDoc(feedbackRef, {
        authorEmail: userEmail, 
        buyerEmail: userEmail,
        buyerUsername: buyerUsername,
        sellerEmail: feedback.sellerEmail,
        sellerUsername: feedback.sellerUsername,
        description: feedback.description,
        dateTime: new Date(),
        orderId: feedback.orderId,
      });
  
      setFeedbackModalVisible(false);
      setFeedback({ description: '', sellerEmail: '', sellerUsername: '', orderId: '' });
      alert('Feedback submitted successfully');
    } catch (error) {
      console.error('Error submitting feedback:', error);
      alert('Failed to submit feedback. Please try again later.');
    }
  };  

  const handleChat = async (sellerEmail: string) => {
    try {
      const userQuery = query(collection(db, 'user'), where('email', '==', sellerEmail));
      const userSnapshot = await getDocs(userQuery);
  
      if (!userSnapshot.empty) {
        const sellerDoc = userSnapshot.docs[0];
        const sellerData = sellerDoc.data(); // Get all the data for the seller
        console.log('Seller document data:', sellerData); // Log entire seller document to check its contents
  
        const phoneNumber = sellerData.phoneno;  // Make sure to use 'phoneno'
        console.log('Fetched phone number:', phoneNumber); // Log the phone number here
  
        if (phoneNumber) {
          const whatsappUrl = `https://wa.me/6${phoneNumber}`;
          console.log('WhatsApp URL:', whatsappUrl);  // Log the WhatsApp URL here
          Linking.openURL(whatsappUrl).catch(() => {
            Alert.alert('Error', 'Unable to open WhatsApp. Please ensure it is installed on your device.');
          });
        } else {
          Alert.alert('Error', 'Phone number is unavailable.');
        }
      } else {
        console.error('Seller not found');
      }
    } catch (error) {
      console.error('Error fetching seller phone number:', error);
    }
  };  
  
  const filteredOrders = orders.filter((order) => order.status.toLowerCase() === activeTab.toLowerCase());

  const renderOrderItem = ({ item }: { item: Order }) => (
    <View style={styles.orderItem}>
      <Text style={styles.text}>@{item.sellerUsername || 'N/A'}</Text>
      <Text style={styles.text}>Date: {item.dateTime || 'N/A'}</Text>
      <Text style={styles.text}>Subtotal: RM {item.subtotal.toFixed(2)}</Text>
  
      <TouchableOpacity
        style={styles.chatButton}
        onPress={() => handleChat(item.sellerEmail)}
      >
        <Ionicons name="chatbubble-ellipses-outline" size={24} color="#007BFF" />
      </TouchableOpacity>
  
      <View style={styles.buttonRow}>
        {(item.status.toLowerCase() === 'completed' || item.status.toLowerCase() === 'dispute') && (
          <TouchableOpacity
            style={styles.button}
            onPress={() => {
              setFeedback({ ...feedback, sellerEmail: item.sellerEmail, sellerUsername: item.sellerUsername, orderId: item.id });
              setFeedbackModalVisible(true);
            }}
          >
            <Text style={styles.buttonText}>Feedback</Text>
          </TouchableOpacity>
        )}
        {item.status.toLowerCase() === 'pending' && (
          <>
            <TouchableOpacity
              style={styles.button}
              onPress={() => handleOrderAction(item.id, 'received', item.subtotal, item.sellerEmail)}
            >
              <Text style={styles.buttonText}>Received</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.button, styles.disputeButton]}
              onPress={() => handleOrderAction(item.id, 'dispute', item.subtotal, item.sellerEmail)}
            >
              <Text style={styles.buttonText}>Dispute</Text>
            </TouchableOpacity>
          </>
        )}
      </View>
    </View>
  );
  
  return (
    <><FlatList
      style={styles.container}
      ListHeaderComponent={<>
        <View style={styles.header}>
          <TouchableOpacity onPress={() => router.push('/user/(tabs)/account')}>
            <Ionicons name="arrow-back" size={24} color="#333" />
          </TouchableOpacity>
          <Text style={styles.headerTitle}>My Purchases</Text>
        </View>
        <View style={styles.tabs}>
          {['Pending', 'Completed', 'Dispute'].map((tab) => (
            <TouchableOpacity
              key={tab}
              style={[styles.tab, activeTab === tab && styles.activeTab]}
              onPress={() => setActiveTab(tab as 'Pending' | 'Completed' | 'Dispute')}
            >
              <Text style={[styles.tabText, activeTab === tab && styles.tabText]}>{tab}</Text>
            </TouchableOpacity>
          ))}
        </View>
      </>}
      data={filteredOrders}
      renderItem={renderOrderItem}
      keyExtractor={(item) => item.id}
      ListEmptyComponent={<Text style={styles.emptyText}>No {activeTab} orders.</Text>} /><Modal visible={feedbackModalVisible} animationType="fade" transparent>
        <View style={styles.modal}>
          <TextInput
            style={[styles.input, styles.textArea]}
            placeholder="Write a feedback to the seller"
            value={feedback.description}
            onChangeText={(text) => setFeedback({ ...feedback, description: text })}
            multiline />
          <TouchableOpacity style={styles.submitButton} onPress={handleFeedbackSubmit}>
            <Text style={styles.submitButtonText}>Submit Feedback</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.closeButton} onPress={() => setFeedbackModalVisible(false)}>
            <Text style={styles.closeButtonText}>Close</Text>
          </TouchableOpacity>
        </View>
      </Modal></>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#fff' },
  header: { flexDirection: 'row', padding: 10, alignItems: 'center' },
  headerTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    marginLeft: 10,
  },
  tabs: { flexDirection: 'row', justifyContent: 'space-around', padding: 10 },
  tab: { paddingVertical: 10, flex: 1, alignItems: 'center' },
  activeTab: { borderBottomWidth: 2, borderBottomColor: '#007BFF' },
  tabText: {
    fontSize: 16,
    color: '#333',
  },
  orderItem: {
    margin: 10,
    padding: 15,
    backgroundColor: '#fff',
    borderRadius: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.15,
    shadowRadius: 6,
    elevation: 4, 
    borderWidth: 1,
    borderColor: '#ddd',
    position: 'relative',
  },
  text: {
    fontSize: 16,
    marginBottom: 5,
  },
  buttonRow: { flexDirection: 'row', justifyContent: 'space-between' },
  button: { backgroundColor: '#007BFF', padding: 10, borderRadius: 5, flex: 1, margin: 5 },

  disputeButton: {
    backgroundColor: '#dc3545',
  },
  buttonText: { color: '#fff', textAlign: 'center' },

  emptyText: {
    textAlign: 'center',
    marginTop: 20,
    fontSize: 16,
  },
  modal: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  input: {
    width: '80%',
    padding: 12,
    backgroundColor: '#fff',
    marginBottom: 10,
    borderRadius: 5,
    borderWidth: 1,
    borderColor: '#ddd',
  },
  textArea: {
    height: 150,
  },
  submitButton: {
    backgroundColor: '#28a745',
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 5,
  },
  submitButtonText: {
    color: '#fff',
    fontSize: 16,
  },
  closeButton: {
    marginTop: 10,
  },
  closeButtonText: {
    color: '#fff',
    fontSize: 16,
  },
  chatButton: {
    position: 'absolute', 
    top: 10, 
    right: 10, 
    padding: 10,
  },
});
