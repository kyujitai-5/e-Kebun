import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, Image, TouchableOpacity, FlatList } from 'react-native';
import { useRouter } from 'expo-router';
import { db, auth } from '../../src/firebaseConfig';
import { doc, getDoc, collection, getDocs, query, where, deleteDoc } from 'firebase/firestore';
import { Ionicons } from '@expo/vector-icons';

interface CartItem {
  plotId: string;
  name: string;
  image: string;
  type: string;
  period: string;
  quantity: number;
  price: number;
}

const PlotCart = () => {
  const router = useRouter();
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [total, setTotal] = useState(0);

  const getCurrentEmail = async (): Promise<string | null> => {
    const user = auth.currentUser;
    if (!user) return null;

    try {
      const userRef = doc(db, 'user', user.uid);
      const userSnap = await getDoc(userRef);
      if (userSnap.exists()) {
        return userSnap.data()?.email || null;
      }
    } catch (error) {
      console.error('Error fetching email:', error);
    }
    return null;
  };

  const fetchPlotDetails = async (plotAreaId: string) => {
    try {
      const plotRef = doc(db, 'plotarea', plotAreaId);
      const plotSnap = await getDoc(plotRef);

      if (plotSnap.exists()) {
        const plotData = plotSnap.data();
        return {
          name: plotData?.name || 'Unknown Plot',
          image: plotData?.images?.[0] || '',
          archived: plotData?.archived || false, // Check if plot is archived
        };
      }
      return { name: 'Unknown', image: '', archived: true };
    } catch (error) {
      console.error('Error fetching plot details:', error);
      return { name: 'Unknown', image: '', archived: true };
    }
  };

  const fetchPriceForPeriod = async (period: string) => {
    try {
      const plotSetppRef = collection(db, 'plotsetpp');
      const snapshot = await getDocs(plotSetppRef);
      for (const doc of snapshot.docs) {
        const data = doc.data();
        if (data.period === period) {
          return Number(data.price);
        }
      }
      return 0; 
    } catch (error) {
      console.error('Error fetching price for period:', error);
      return 0;
    }
  };

  // Fetch cart items for the current user and remove archived plots
  const fetchCartItems = async () => {
    try {
      const email = await getCurrentEmail();
      if (!email) {
        console.error('No user is logged in');
        return;
      }

      const cartRef = query(collection(db, 'plotcart'), where('email', '==', email));
      const cartSnap = await getDocs(cartRef);

      const fetchedItems: CartItem[] = [];
      for (const doc of cartSnap.docs) {
        const data = doc.data();
        const { name, image, archived } = await fetchPlotDetails(data.plotAreaId);
        const price = await fetchPriceForPeriod(data.period);

        if (archived) {
          // Remove the archived plot from the cart
          await deleteDoc(doc.ref);
          console.log(`Removed archived plot with ID: ${doc.id}`);
        } else {
          fetchedItems.push({
            plotId: doc.id,
            name,
            image,
            type: data.plotType,
            period: data.period,
            quantity: data.quantity,
            price,
          });
        }
      }

      setCartItems(fetchedItems);
      calculateTotal(fetchedItems);
    } catch (error) {
      console.error('Error fetching cart items:', error);
    }
  };

  // Calculate total price of all cart items
  const calculateTotal = (items: CartItem[]) => {
    const total = items.reduce((acc, item) => acc + item.price * item.quantity, 0);
    setTotal(total);
  };

  // Delete a specific cart item
  const handleDeleteItem = async (plotId: string) => {
    try {
      const cartRef = doc(db, 'plotcart', plotId);
      await deleteDoc(cartRef);

      const updatedItems = cartItems.filter((item) => item.plotId !== plotId);
      setCartItems(updatedItems);
      calculateTotal(updatedItems);
    } catch (error) {
      console.error('Error deleting item:', error);
    }
  };

  // Fetch cart items when the component mounts
  useEffect(() => {
    fetchCartItems();
  }, []);

  // Render each cart item
  const renderCartItem = ({ item }: { item: CartItem }) => {
    const subtotal = item.price * item.quantity;

    return (
      <View style={styles.cartItem}>
        <Image source={{ uri: item.image }} style={styles.cartImage} />
        <View style={styles.cartDetails}>
          <Text style={styles.cartTitle}>{item.name}</Text>
          <Text>Type: {item.type}</Text>
          <Text>Period: {item.period}</Text>
          <Text>Quantity: {item.quantity}</Text>
          <Text>Price: ${item.price}</Text>
        </View>
        <View style={styles.subtotalContainer}>
          <Text style={styles.subtotalText}>Subtotal:</Text>
          <Text style={styles.subtotal}>${subtotal.toFixed(2)}</Text>
        </View>
        <TouchableOpacity style={styles.deleteButton} onPress={() => handleDeleteItem(item.plotId)}>
          <Text style={styles.deleteText}>x</Text>
        </TouchableOpacity>
      </View>
    );
  };

  const handleCheckout = async () => {
    const email = await getCurrentEmail();
    if (!email) {
      console.error('Email not found');
      return;
    }
    router.push({
      pathname: '/user/plot/plotcheckout',
      params: { total: total.toFixed(2), email: email },
    });
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()}>
          <Ionicons name="arrow-back" size={24} color="black" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Plot Cart</Text>
      </View>
      <FlatList
        data={cartItems}
        renderItem={renderCartItem}
        keyExtractor={(item) => item.plotId}
      />
      <View style={styles.stickyFooter}>
        <Text style={styles.totalText}>Total: RM {total.toFixed(2)}</Text>
        <TouchableOpacity style={styles.checkoutButton} onPress={handleCheckout}>
          <Text style={styles.checkoutText}>Checkout</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f9f9f9',
    padding: 20,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 20,
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#000',
    marginLeft: 10,  // Adjust this value as needed

  },

  quantityButton: {
    fontSize: 18,
    fontWeight: 'bold',
    marginHorizontal: 10,
    color: '#007BFF',
  },
  deleteButton: {
    position: 'absolute',
    top: 5,
    right: 5,
  },
  deleteText: {
    fontSize: 18,
    color: 'red',
    fontWeight: 'bold',
  },
  cartItem: {
    flexDirection: 'row',
    padding: 10,
    backgroundColor: '#fff',
    marginBottom: 15,
    borderRadius: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 5,
    elevation: 5,
  },
  cartImage: {
    width: 100,
    height: 100,
    borderRadius: 8,
    marginRight: 20,
  },
  cartDetails: {
    flex: 1,
    justifyContent: 'center',
  },
  cartTitle: {
    fontSize: 18,
    fontWeight: 'bold',
  },

  stickyFooter: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    padding: 20,
    backgroundColor: '#fff',
    borderTopWidth: 1,
    borderTopColor: '#ddd',
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  totalText: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  checkoutButton: {
    backgroundColor: '#007BFF',
    paddingVertical: 12,
    paddingHorizontal: 30,
    borderRadius: 8,
  },
  checkoutText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },

  subtotalContainer: {
    justifyContent: 'center',
    alignItems: 'flex-end',
    flex: 1,
  },
  subtotalText: {
    fontSize: 16,
    color: '#333',
  },
  subtotal: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#000',
  },
});

export default PlotCart;