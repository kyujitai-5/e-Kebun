import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, Image, TouchableOpacity, FlatList, ScrollView } from 'react-native';
import { useRouter } from 'expo-router';
import { db, auth } from '../../src/firebaseConfig';
import { doc, getDoc, collection, getDocs, query, where, deleteDoc, writeBatch } from 'firebase/firestore';
import { Ionicons } from '@expo/vector-icons';

interface CartItem {
  listingId: string;
  sellerId: string;
  name: string;
  image: string;
  price: number;
  sellerEmail: string;
  sellerUsername: string; 
}

const ListingCart = () => {
  const router = useRouter();
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [total, setTotal] = useState(0);

  const getCurrentEmailAndUsername = async (): Promise<{ email: string | null; username: string | null }> => {
    const user = auth.currentUser;
    if (!user) return { email: null, username: null };
  
    try {
      const userRef = doc(db, 'user', user.uid);
      const userSnap = await getDoc(userRef);
      if (userSnap.exists()) {
        return {
          email: userSnap.data()?.email || null,
          username: userSnap.data()?.username || 'Unknown Buyer',
        };
      }
    } catch (error) {
      console.error('Error fetching email and username:', error);
    }
    return { email: null, username: 'Unknown Buyer' };
  };
  

  const fetchListingDetails = async (listingId: string) => {
    try {
      const listingRef = doc(db, 'listing', listingId);
      const listingSnap = await getDoc(listingRef);

      if (listingSnap.exists()) {
        const listingData = listingSnap.data();

        const sellerRef = query(collection(db, 'user'), where('email', '==', listingData?.email));
        const sellerSnap = await getDocs(sellerRef);

        let sellerUsername = 'Unknown User';
        let sellerEmail = listingData?.email || '';
        if (!sellerSnap.empty) {
          const sellerData = sellerSnap.docs[0].data();
          sellerUsername = sellerData?.username || 'Unknown User';
        }

        const image = Array.isArray(listingData?.images) ? listingData.images[0] : listingData?.images;

        return {
          name: listingData?.title || 'Unknown Listing',
          image: image || '',
          price: listingData?.price || 0,
          sellerUsername,
          sellerEmail,
        };
      }

      return { name: 'Unknown', image: '', price: 0, sellerUsername: '', sellerEmail: '' };
    } catch (error) {
      console.error('Error fetching listing details:', error);
      return { name: 'Unknown', image: '', price: 0, sellerUsername: '', sellerEmail: '' };
    }
  };

  const fetchCartItems = async () => {
    try {
      const { email, username } = await getCurrentEmailAndUsername();
      if (!email) {
        console.error('No user is logged in');
        return;
      }
  
      const cartRef = query(collection(db, 'listingcart'), where('email', '==', email));
      const cartSnap = await getDocs(cartRef);
  
      const fetchedItems: CartItem[] = [];
      for (const doc of cartSnap.docs) {
        const data = doc.data();
        const { name, image, price, sellerUsername, sellerEmail } = await fetchListingDetails(data.listingId);
  
        fetchedItems.push({
          listingId: doc.id,
          sellerId: data.sellerId,
          name,
          image,
          price,
          sellerEmail,
          sellerUsername,
        });
      }
  
      setCartItems(fetchedItems);
      calculateTotal(fetchedItems);
    } catch (error) {
      console.error('Error fetching cart items:', error);
    }
  };  

  const calculateTotal = (items: CartItem[]) => {
    const totalAmount = items.reduce((acc, item) => acc + item.price, 0);
    setTotal(totalAmount);
  };

  const groupItemsBySeller = (items: CartItem[]) => {
    // Create an empty object to hold groups, where each key is a seller's ID
    const grouped: { [key: string]: CartItem[] } = {};

    items.forEach((item) => {
      const sellerKey = item.sellerEmail; // Use the sellerId as the key for grouping
      if (!grouped[sellerKey]) {
        grouped[sellerKey] = [];
      }
      // Add the current item to the seller's group
      grouped[sellerKey].push(item);
    });

    return grouped;
  };

  const handleDeleteItem = async (listingId: string) => {
    try {
      const cartRef = doc(db, 'listingcart', listingId);
      await deleteDoc(cartRef);

      const updatedItems = cartItems.filter((item) => item.listingId !== listingId);
      setCartItems(updatedItems);
      calculateTotal(updatedItems);
    } catch (error) {
      console.error('Error deleting item:', error);
    }
  };

  const handleCheckout = async () => {
    const { email, username } = await getCurrentEmailAndUsername();
    if (!email || !username) {
      console.error('Buyer email or username not found');
      return;
    }
  
    try {
      // Group the cart items by seller for processing.
      const groupedCartItems = groupItemsBySeller(cartItems);
  
      const orderIds: string[] = []; // Store the generated order IDs
      const orderData = Object.keys(groupedCartItems).map((sellerEmail) => {
        const sellerItems = groupedCartItems[sellerEmail];
  
        
        const orderId = doc(collection(db, 'orders')).id;
        orderIds.push(orderId);
  
        return {
          orderId,
          sellerEmail,
          sellerUsername: sellerItems[0].sellerUsername,
          buyerEmail: email,
          buyerUsername: username,
          listingIds: sellerItems.map((item) => item.listingId),
          dateTime: new Date(),
          status: 'pending',
          subtotal: sellerItems.reduce((acc, item) => acc + item.price, 0),
        };
      });
  
      const batch = writeBatch(db);
  
      // Create orders in Firestore
      orderData.forEach((order) => {
        const docRef = doc(db, 'orders', order.orderId);
        batch.set(docRef, order);
      });
  
      // Update listings as sold and clear the cart
      const listingsToRemoveFromCarts: string[] = [];
  
      for (const item of cartItems) {
        const listingCartRef = doc(db, 'listingcart', item.listingId);
        const listingCartSnap = await getDoc(listingCartRef);
  
        if (listingCartSnap.exists()) {
          const listingId = listingCartSnap.data().listingId; // Fetch the listingId from the listingcart
          const listingRef = doc(db, 'listing', listingId);
          const listingSnap = await getDoc(listingRef);
  
          if (listingSnap.exists()) {
            const listingData = listingSnap.data();
  
            if (listingData.status === 'active') {
              // Update the listing status to 'sold'
              batch.update(listingRef, { status: 'sold' });
              listingsToRemoveFromCarts.push(listingId); // Add to the list for clearing carts
            } else {
              console.warn(`Listing with ID ${listingId} is not active.`);
            }
          } else {
            console.warn(`Listing with ID ${listingId} does not exist.`);
          }
        } else {
          console.warn(`ListingCart item with ID ${item.listingId} does not exist.`);
        }
      }
  
      // Remove the listing from other users' carts
      for (const listingId of listingsToRemoveFromCarts) {
        const cartRef = query(collection(db, 'listingcart'), where('listingId', '==', listingId));
        const cartSnap = await getDocs(cartRef);
  
        cartSnap.forEach((cartDoc) => {
          const cartDocRef = doc(db, 'listingcart', cartDoc.id);
          batch.delete(cartDocRef); // Delete the cart item for other users
        });
      }
  
      // Commit the batch operation
      await batch.commit();
  
      console.log('Orders created successfully, listings updated as sold, and cart cleared for others.');
      router.push(`/user/listing/listingcheckout?orderIds=${orderIds.join(',')}`);
    } catch (error) {
      console.error('Error during checkout:', error);
    }
  };
  
  useEffect(() => {
    fetchCartItems();
  }, []);

  const groupedCartItems = groupItemsBySeller(cartItems);

  const renderCartItem = ({ item }: { item: CartItem }) => (
    <View style={styles.cartItem}>
      <Image source={{ uri: item.image }} style={styles.cartImage} />
      <View style={styles.cartDetails}>
        <Text style={styles.cartTitle}>{item.name}</Text>
        <Text>RM {item.price}</Text>
      </View>
      <TouchableOpacity style={styles.deleteButton} onPress={() => handleDeleteItem(item.listingId)}>
        <Text style={styles.deleteText}>x</Text>
      </TouchableOpacity>
    </View>
  );

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()}>
          <Ionicons name="arrow-back" size={24} color="black" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Listing Cart</Text>
      </View>
      <FlatList
        data={Object.keys(groupedCartItems)}
        keyExtractor={(sellerId) => sellerId}
        renderItem={({ item: sellerId }) => {
          const sellerItems = groupedCartItems[sellerId];
          const sellerSubtotal = sellerItems.reduce((acc, item) => acc + item.price, 0);

          return (
            <View style={styles.groupContainer}>
              <Text style={styles.sellerTitle}>@{sellerItems[0].sellerUsername}</Text>
              <FlatList
                data={sellerItems}
                renderItem={renderCartItem}
                keyExtractor={(item) => item.listingId}
              />
              <View style={styles.subtotalContainer}>
                <Text style={styles.subtotalText}>Subtotal</Text>
                <Text style={styles.subtotalAmount}>RM {sellerSubtotal.toFixed(2)}</Text>
              </View>
            </View>
          );
        }}
      />
      <View style={styles.stickyFooter}>
        <Text style={styles.totalText}>Total: RM {total.toFixed(2)}</Text>
        <TouchableOpacity style={styles.checkoutButton} onPress={handleCheckout}>
          <Text style={styles.checkoutText}>Checkout</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f9f9f9',
    padding: 20,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 20,
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#000',
    marginLeft: 10,
  },
  scrollContainer: {
    paddingBottom: 20, 
  },
  groupContainer: {
    marginBottom: 20,
    borderRadius: 8,
    backgroundColor: '#fff',
    paddingBottom: 10,
    paddingTop: 10,
    borderWidth: 1,
    borderColor: '#ddd',
  },
  sellerTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginLeft: 10,
    marginBottom: 10,
  },
  flatListContainer: {
    paddingBottom: 10,
    marginLeft: 10,
    marginRight: 10,
  },
  cartItem: {
    flexDirection: 'row',
    padding: 10,
    borderTopWidth: 1,
    borderTopColor: '#ddd',
  },
  cartImage: {
    width: 100,
    height: 100,
    borderRadius: 8,
    marginRight: 20,
  },
  cartDetails: {
    flex: 1,
    justifyContent: 'center',
  },
  cartTitle: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  deleteButton: {
    position: 'absolute',
    top: 5,
    right: 5,
  },
  deleteText: {
    fontSize: 18,
    color: 'red',
    fontWeight: 'bold',
  },
  subtotalContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    padding: 10,
    borderTopWidth: 1,
    borderTopColor: '#ddd',
  },
  subtotalText: {
    fontSize: 16,
    color: '#333',
  },
  subtotalAmount: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#000',
  },
  stickyFooter: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    padding: 20,
    backgroundColor: '#fff',
    borderTopWidth: 1,
    borderTopColor: '#ddd',
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  totalText: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  checkoutButton: {
    backgroundColor: '#007BFF',
    paddingVertical: 12,
    paddingHorizontal: 30,
    borderRadius: 8,
  },
  checkoutText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },
});

export default ListingCart;
