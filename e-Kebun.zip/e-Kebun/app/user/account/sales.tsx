import React, { useState, useEffect } from 'react';
import { StyleSheet, View, Text, TouchableOpacity, FlatList, ScrollView, Linking, Alert, Modal, TextInput } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { db } from '../../src/firebaseConfig';
import { collection, doc, getDoc, getDocs, query, setDoc, where } from 'firebase/firestore';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { getAuth } from 'firebase/auth';
import { useRouter } from 'expo-router';

interface Order {
  id: string;
  buyerUsername: string;
  buyerEmail: string;
  dateTime: string;
  subtotal: number;
  status: string;
}

export default function Sales() {
  const [activeTab, setActiveTab] = useState<'Pending' | 'Completed' | 'Dispute'>('Pending');
  const [orders, setOrders] = useState<Order[]>([]); 
  const [userEmail, setUserEmail] = useState<string | null>(null);
  const [feedbackModalVisible, setFeedbackModalVisible] = useState(false);
  const [feedback, setFeedback] = useState({ description: '', buyerEmail: '', buyerUsername: '', orderId: '' });
  const router = useRouter();

  // Fetch user email
  useEffect(() => {
    const fetchUserEmail = async () => {
      try {
        let email = await AsyncStorage.getItem('userEmail');
        if (!email) {
          const auth = getAuth();
          email = auth.currentUser?.email || null;
        }
        setUserEmail(email);
      } catch (error) {
        console.error('Error fetching user email:', error);
      }
    };

    fetchUserEmail();
  }, []);

  // Fetch orders
  useEffect(() => {
    const fetchOrders = async () => {
      if (!userEmail) return;

      try {
        const ordersQuery = query(
          collection(db, 'orders'),
          where('sellerEmail', '==', userEmail),
          where('status', '==', activeTab.toLowerCase())
        );

        const snapshot = await getDocs(ordersQuery);

        if (snapshot.empty) {
          setOrders([]);
          return;
        }

        const fetchedOrders = snapshot.docs.map((doc) => {
          const data = doc.data();
          return {
            id: doc.id,
            buyerUsername: data.buyerUsername || '',
            buyerEmail: data.buyerEmail || '',
            dateTime: data.dateTime?.toDate().toLocaleString() || '',
            subtotal: data.subtotal || 0,
            status: data.status || '',
          } as Order;
        });

        setOrders(fetchedOrders);
      } catch (error) {
        console.error('Error fetching orders:', error);
      }
    };

    fetchOrders();
  }, [userEmail, activeTab]);

  // Filter orders based on the active tab
  const filteredOrders = orders.filter((order) => order.status.toLowerCase() === activeTab.toLowerCase());

  const handleFeedbackSubmit = async () => {
    if (!feedback.description) {
      alert('Please fill in the feedback description');
      return;
    }

    try {
      const orderRef = doc(db, 'orders', feedback.orderId);
      const orderDoc = await getDoc(orderRef);

      if (!orderDoc.exists()) {
        alert('Sale not found');
        return;
      }

      const saleData = orderDoc.data();
      const sellerUsername = saleData?.sellerUsername || '';

      const feedbackRef = doc(collection(db, 'feedback'));
      await setDoc(feedbackRef, {
        authorEmail: userEmail,
        sellerEmail: userEmail,
        sellerUsername: sellerUsername,
        buyerEmail: feedback.buyerEmail,
        buyerUsername: feedback.buyerUsername,
        description: feedback.description,
        dateTime: new Date(),
        orderId: feedback.orderId,
      });

      setFeedbackModalVisible(false);
      setFeedback({ description: '', buyerEmail: '', buyerUsername: '', orderId: '' });
      alert('Feedback submitted successfully');
    } catch (error) {
      console.error('Error submitting feedback:', error);
      alert('Failed to submit feedback. Please try again later.');
    }
  };
  
  const handleChat = async (buyerEmail: string) => {
    try {
      const userQuery = query(collection(db, 'user'), where('email', '==', buyerEmail));
      const userSnapshot = await getDocs(userQuery);

      if (!userSnapshot.empty) {
        const buyerDoc = userSnapshot.docs[0];
        const buyerData = buyerDoc.data(); // Get all the data for the buyer

        const phoneNumber = buyerData.phoneno;  // Make sure to use 'phoneno'
        
        if (phoneNumber) {
          const whatsappUrl = `https://wa.me/6${phoneNumber}`;
          Linking.openURL(whatsappUrl).catch(() => {
            Alert.alert('Error', 'Unable to open WhatsApp. Please ensure it is installed on your device.');
          });
        } else {
          Alert.alert('Error', 'Phone number is unavailable.');
        }
      } else {
        console.error('Buyer not found');
      }
    } catch (error) {
      console.error('Error fetching buyer phone number:', error);
    }
  };

  const renderSaleItem = ({ item }: { item: Order }) => (
    <View style={styles.orderItem}>
      <Text style={styles.text}>@{item.buyerUsername || 'N/A'}</Text>
      <Text style={styles.text}>Date: {item.dateTime || 'N/A'}</Text>
      <Text style={styles.text}>Subtotal: RM {item.subtotal.toFixed(2)}</Text>

      <TouchableOpacity
        style={styles.chatButton}
        onPress={() => handleChat(item.buyerEmail)}
      >
        <Ionicons name="chatbubble-ellipses-outline" size={24} color="#007BFF" />
      </TouchableOpacity>

      {(item.status.toLowerCase() === 'completed' || item.status.toLowerCase() === 'dispute') && (
        <TouchableOpacity
          style={styles.feedbackButton}
          onPress={() => {
            setFeedback({ ...feedback, buyerEmail: item.buyerEmail, buyerUsername: item.buyerUsername, orderId: item.id });
            setFeedbackModalVisible(true);
          }}
        >
          <Text style={styles.buttonText}>Feedback</Text>
        </TouchableOpacity>
      )} 
    </View>
  );

  return (
    <><FlatList
      style={styles.container}
      ListHeaderComponent={<>
        <View style={styles.header}>
          <TouchableOpacity onPress={() => router.push('/user/(tabs)/account')}>
            <Ionicons name="arrow-back" size={24} color="#333" />
          </TouchableOpacity>
          <Text style={styles.headerTitle}>My Sales</Text>
        </View>
        <View style={styles.tabs}>
          {['Pending', 'Completed', 'Dispute'].map((tab) => (
            <TouchableOpacity
              key={tab}
              style={[styles.tab, activeTab === tab && styles.activeTab]}
              onPress={() => setActiveTab(tab as 'Pending' | 'Completed' | 'Dispute')}
            >
              <Text style={[styles.tabText, activeTab === tab && styles.tabText]}>{tab}</Text>
            </TouchableOpacity>
          ))}
        </View>
      </>}
        data={filteredOrders}
        renderItem={renderSaleItem}
        keyExtractor={(item) => item.id}
        ListEmptyComponent={<Text style={styles.emptyText}>No {activeTab} sales.</Text>}
      />
      <Modal visible={feedbackModalVisible} animationType="fade" transparent>
        <View style={styles.modal}>
          <TextInput
            style={[styles.input, styles.textArea]}
            placeholder="Write feedback for the buyer"
            value={feedback.description}
            onChangeText={(text) => setFeedback({ ...feedback, description: text })}
            multiline
          />
          <TouchableOpacity style={styles.submitButton} onPress={handleFeedbackSubmit}>
            <Text style={styles.buttonText}>Submit Feedback</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.closeButton} onPress={() => setFeedbackModalVisible(false)}>
            <Text style={styles.closeButtonText}>Close</Text>
          </TouchableOpacity>          
        </View>
      </Modal>
    </>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#fff' },
  header: { flexDirection: 'row', alignItems: 'center', padding: 15 },
  headerTitle: { fontSize: 18, fontWeight: 'bold', marginLeft: 10, color: '#333' },
  tabs: { flexDirection: 'row', marginBottom: 10 },
  tab: { flex: 1, padding: 10, alignItems: 'center', borderBottomWidth: 2, borderColor: '#ccc' },
  activeTab: { borderColor: '#007BFF' },
  tabText: { fontSize: 16, color: '#333' },
  orderItem: {
    margin: 10,
    padding: 15,
    backgroundColor: '#fff',
    borderRadius: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.15,
    shadowRadius: 6,
    elevation: 4, 
    borderWidth: 1,
    borderColor: '#ddd',
    position: 'relative',
  },
  text: { fontSize: 14, color: '#333', marginBottom: 5 },
  emptyText: { textAlign: 'center', color: '#888', marginTop: 20 },
  chatButton: {
    position: 'absolute', 
    top: 10, 
    right: 10, 
    padding: 10,
  },
  buttonText: { color: '#fff', textAlign: 'center' },
  modal: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  input: {
    width: '80%',
    padding: 12,
    backgroundColor: '#fff',
    marginBottom: 10,
    borderRadius: 5,
    borderWidth: 1,
    borderColor: '#ddd',
  },
  textArea: {
    height: 150,
  },
  submitButton: {
    backgroundColor: '#28a745',
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 5,
  },
  feedbackButton: {
    backgroundColor: '#007BFF',
    paddingVertical: 8,
    paddingHorizontal: 16,
    borderRadius: 5,
    alignItems: 'center',
    marginTop: 10,
  },
  closeButton: {
    marginTop: 10,
  },
  closeButtonText: {
    color: '#fff',
    fontSize: 16,
  },
});
