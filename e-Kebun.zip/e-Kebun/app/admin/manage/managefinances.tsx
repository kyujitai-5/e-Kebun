import React, { useState, useEffect } from 'react';
import { View, Text, FlatList, Modal, TouchableOpacity, StyleSheet } from 'react-native';
import { db } from '../../src/firebaseConfig';
import { collection, getDocs } from 'firebase/firestore';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons'; // For the back button

interface Transaction {
  id: string; // Document ID
  bank: string;
  email: string;
  total: number;
  transactionDate: string;
  transactionType: string;
  username: string;
}

const ManageFinances = () => {
  const router = useRouter();
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [modalVisible, setModalVisible] = useState(false);
  const [selectedTransaction, setSelectedTransaction] = useState<Transaction | null>(null);

  useEffect(() => {
    const fetchTransactions = async () => {
      try {
        const transactionCollection = collection(db, 'transactions');
        const transactionSnapshot = await getDocs(transactionCollection);

        const fetchedTransactions = transactionSnapshot.docs.map((doc) => {
          const data = doc.data();
          const transactionDate = new Date(data.transactionDate).toLocaleString(); // Convert Firestore timestamp to readable string

          return {
            id: doc.id,
            bank: data.bank || '',
            email: data.email || '',
            total: data.total || 0,
            transactionDate: transactionDate,
            transactionType: data.transactionType || '',
            username: data.username || '',
          };
        });

        setTransactions(fetchedTransactions);
      } catch (error) {
        console.error('Error fetching transactions:', error);
      }
    };

    fetchTransactions();
  }, []);

  const handleItemPress = (transaction: Transaction) => {
    setSelectedTransaction(transaction);
    setModalVisible(true);
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()}>
          <Ionicons name="arrow-back" size={24} color="black" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Manage Finances</Text>
      </View>

      <FlatList
        data={transactions}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <TouchableOpacity
            onPress={() => handleItemPress(item)}
            style={styles.transactionItem}
          >
            <Text style={styles.transactionId}>ID: {item.id}</Text>
            <Text style={styles.transactionDate}>{item.transactionDate}</Text>
          </TouchableOpacity>
        )}
      />

      {selectedTransaction && (
        <Modal
          visible={modalVisible}
          animationType="fade"
          transparent={true}
          onRequestClose={() => setModalVisible(false)}
        >
          <View style={styles.modalContainer}>
            <View style={styles.modalContent}>
              <TouchableOpacity onPress={() => setModalVisible(false)} style={styles.closeButton}>
                <Ionicons name="close" size={24} color="black" />
              </TouchableOpacity>

              <Text style={styles.modalTitle}>Receipt</Text>
              <View style={styles.receiptContent}>
                <Text style={styles.receiptDetail}>Bank: {selectedTransaction.bank}</Text>
                <Text style={styles.receiptDetail}>Username: {selectedTransaction.username}</Text>
                <Text style={styles.receiptDetail}>Transaction Type: {selectedTransaction.transactionType}</Text>
                <Text style={styles.receiptDetail}>Total: RM {selectedTransaction.total}</Text>
                <Text style={styles.receiptDetail}>Date: {selectedTransaction.transactionDate}</Text>
              </View>
            </View>
          </View>
        </Modal>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#fff',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 20,
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    marginLeft: 10,
  },
  transactionItem: {
    padding: 15,
    backgroundColor: '#f9f9f9',
    marginVertical: 5,
    borderRadius: 5,
  },
  transactionId: {
    fontSize: 14,
    color: '#777',
  },
  transactionDate: {
    fontSize: 12,
    color: '#555',
  },
  modalContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  modalContent: {
    width: '80%',
    backgroundColor: '#fff',
    padding: 20,
    borderRadius: 10,
    alignItems: 'center',
  },
  closeButton: {
    alignSelf: 'flex-end',
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  receiptContent: {
    paddingTop: 20,
    width: '100%',
  },
  receiptDetail: {
    fontSize: 16,
    marginBottom: 10,
    textAlign: 'left',
  },
});

export default ManageFinances;
