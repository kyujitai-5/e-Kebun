import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ActivityIndicator, Modal, Alert } from 'react-native';
import { useRouter, useLocalSearchParams } from 'expo-router';
import { Picker } from '@react-native-picker/picker';
import { db, auth } from '../../src/firebaseConfig';
import { collection, addDoc, getDocs, query, where, updateDoc, increment, deleteDoc, doc } from 'firebase/firestore';
import Icon from 'react-native-vector-icons/FontAwesome'; 

interface Transaction {
  email: string;
  username: string;
  transactionDate: string;
  total: number;
  bank: string;
  transactionType: string;
}

const PlotCheckout = () => {
  const router = useRouter();
  const { total, email } = useLocalSearchParams();
  const [selectedBank, setSelectedBank] = useState<string>('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [isTransactionSuccessful, setIsTransactionSuccessful] = useState(false);

  const banks = [
    { label: 'Maybank', value: 'Maybank' },
    { label: 'CIMB', value: 'CIMB' },
    { label: 'Public Bank', value: 'Public Bank' },
    { label: 'RHB', value: 'RHB' },
    { label: 'Hong Leong Bank', value: 'Hong Leong Bank' },
  ];

  const handleTransaction = async () => {
    if (!selectedBank) {
      Alert.alert('Error', 'Please select a bank');
      return;
    }
  
    setIsProcessing(true);
  
    try {
      const user = auth.currentUser;
      if (!user) throw new Error('User not authenticated');
  
      const cartQuery = query(collection(db, 'plotcart'), where('email', '==', email));
      const cartSnap = await getDocs(cartQuery);
  
      if (cartSnap.empty) {
        throw new Error('No items in cart');
      }
  
      const rentCollection = collection(db, 'rent');
      const plotsCollection = collection(db, 'plots');
      const transactionCollection = collection(db, 'transactions');
      const plotsetppCollection = collection(db, 'plotsetpp');
  
      const transactionDate = new Date().toISOString();
  
      const userQuery = query(collection(db, 'user'), where('email', '==', email));
      const userSnap = await getDocs(userQuery);
  
      if (userSnap.empty) {
        throw new Error('User not found');
      }
  
      const username = userSnap.docs[0].data().username;
  
      // Create transaction in the transactions collection and get its ID
      const transactionData: Transaction = {
        email: Array.isArray(email) ? email[0] : email,
        username,
        transactionDate,
        total: Number(total),
        bank: selectedBank,
        transactionType: 'Plot',
      };
  
      const transactionDoc = await addDoc(transactionCollection, transactionData);
      const transactionId = transactionDoc.id; // Use this as the transactionId
  
      // Process each cart item
      for (const cartDoc of cartSnap.docs) {
        const cartData = cartDoc.data();
        const { plotAreaId, plotType, quantity, period } = cartData;
  
        const priceQuery = query(plotsetppCollection, where('period', '==', period));
        const priceSnap = await getDocs(priceQuery);
  
        if (priceSnap.empty) {
          throw new Error('Price not found for the selected period');
        }
  
        const price = priceSnap.docs[0].data()?.price;
  
        if (!price) {
          throw new Error('Price is undefined or invalid');
        }
  
        // Query the plots collection to find available plots that match the cart item requirements
        const availablePlotsQuery = query(
          plotsCollection,
          where('plotAreaId', '==', plotAreaId), // Match the plot area ID
          where('status', '==', 'available'), // Only include available plots
          where('type', '==', plotType) // Match the plot type
        );
  
        const availablePlotsSnap = await getDocs(availablePlotsQuery);
        const availablePlots = availablePlotsSnap.docs.map((doc) => ({ id: doc.id, ...doc.data() }));
  
        if (availablePlots.length < quantity) {
          throw new Error(`Not enough available plots for ${plotType} in ${plotAreaId}`);
        }

        // Assign plots to the user by selecting the required quantity
        const assignedPlots = availablePlots.slice(0, quantity);
  
        for (const plot of assignedPlots) {
          const rentalEndDate = new Date(); // Initialize the rental end date
          rentalEndDate.setFullYear(rentalEndDate.getFullYear() + Number(period));
          // Calculate the rental end date based on the period
  
          // Add a rental record for the assigned plot
          await addDoc(rentCollection, {
            plotAreaId,
            plotId: plot.id, // Assign plot ID
            email,
            username,
            plotType,
            period,
            price,
            rentalStartDate: transactionDate,
            rentalEndDate: rentalEndDate.toISOString(),
            transactionId: transactionId, 
          });
  
          // Update the plot status to 'occupied' in the database
          await updateDoc(doc(db, 'plots', plot.id), { status: 'occupied' });
        }
  
        // Update the availability count for the specific plot type in the plot area
        const plotAreaRef = doc(db, 'plotarea', plotAreaId);
        await updateDoc(plotAreaRef, {
          [`plotAvailability.${plotType}`]: increment(-quantity), 
        }); // Decrease the availability count
  
        // Remove the processed cart item from the user's cart
        await deleteDoc(doc(db, 'plotcart', cartDoc.id));
      }
  
      setIsTransactionSuccessful(true);
    } catch (error: unknown) {
      if (error instanceof Error) {
        Alert.alert('Error', error.message || 'An unexpected error occurred');
      } else {
        Alert.alert('Error', 'An unexpected error occurred');
      }
    } finally {
      setIsProcessing(false);
    }
  };  

  return (
    <View style={styles.container}>
      <View style={styles.headerContainer}>
        <Text style={styles.header}>Checkout</Text>
      </View>

      <View style={styles.bankSelection}>
        <Text style={styles.bankText}>Select Bank</Text>
        <Picker
          selectedValue={selectedBank}
          onValueChange={(itemValue: string) => setSelectedBank(itemValue)}
          style={styles.picker}
        >
          {banks.map((bank) => (
            <Picker.Item key={bank.value} label={bank.label} value={bank.value} />
          ))}
        </Picker>
      </View>
      
      <View style={styles.totalContainer}>
        <Text style={styles.totalLabel}>Total Price</Text>
        <View style={styles.priceContainer}>
          <Text style={styles.totalPrice}>RM {Number(total).toFixed(2)}</Text>
          <TouchableOpacity
            style={[styles.transactionButton, isProcessing && styles.transactionButtonDisabled]}
            onPress={handleTransaction}
            disabled={isProcessing}
          >
            {isProcessing ? (
              <ActivityIndicator color="#fff" />
            ) : (
              <Text style={styles.transactionButtonText}>Pay Now</Text>
            )}
          </TouchableOpacity>
        </View>
      </View>

      <Modal visible={isTransactionSuccessful} transparent animationType="fade">
        <View style={styles.modalContainer}>
          <View style={styles.modalContent}>
            <Icon name="check-circle" size={50} color="green" style={styles.tickIcon} />
            <Text style={styles.successText}>Transaction Successful!</Text>
            <View style={styles.modalButtonsContainer}>

              <TouchableOpacity
                style={styles.modalButton}
                onPress={() => {
                  setIsTransactionSuccessful(false);
                  router.push('/user/plot/myplots');
                }}
              >
                <Text style={styles.modalButtonText}>My Plots</Text>
              </TouchableOpacity>
              <TouchableOpacity
              style={[styles.modalButton, { backgroundColor: '#ccc' }]}
              onPress={() => {
                  setIsTransactionSuccessful(false);
                  router.push('/user/(tabs)/plot');
                }}
              >
                <Text style={styles.modalButtonText}>Plots</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#f9f9f9',
  },
  headerContainer: {
    flexDirection: 'row',
    justifyContent: 'flex-start',
    alignItems: 'center',
  },
  header: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  totalContainer: {
    marginBottom: 30,
    alignItems: 'flex-start',
  },
  totalLabel: {
    fontSize: 16,
    fontWeight: 'normal',
    color: '#333',
  },
  priceContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    width: '100%',
  },
  totalPrice: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#333',
  },
  transactionButton: {
    backgroundColor: '#007BFF',
    paddingVertical: 12,
    paddingHorizontal: 30,
    borderRadius: 8,
  },
  transactionButtonDisabled: {
    backgroundColor: '#b0c4de',
  },
  transactionButtonText: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold',
  },
  bankSelection: {
    marginBottom: 30,
  },
  bankText: {
    fontSize: 18,
    marginBottom: 10,
    color: '#333',
  },
  picker: {
    height: 50,
    width: '100%',
  },
  modalContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  modalContent: {
    width: 300,
    padding: 20,
    backgroundColor: '#fff',
    borderRadius: 10,
    alignItems: 'center',
  },
  tickIcon: {
    marginBottom: 20,
  },
  successText: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#28a745',
    marginBottom: 20,
  },
  modalButtonsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    width: '100%',
  },
  modalButton: {
    backgroundColor: '#28a745',
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 5,
    marginTop: 10,
    flex: 1,
    marginHorizontal: 5,
  },
  modalButtonText: {
    color: '#fff',
    fontSize: 16,
    textAlign: 'center',
  },
});

export default PlotCheckout;
