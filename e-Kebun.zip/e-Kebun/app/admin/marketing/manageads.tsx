import React, { useState, useEffect } from 'react';
import { View, Text, FlatList, TextInput, TouchableOpacity, StyleSheet } from 'react-native';
import { db } from '../../src/firebaseConfig';
import { collection, getDocs } from 'firebase/firestore';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';

interface AdData {
  id: string; 
  title: string;
}

const ManageAds = () => {
  const router = useRouter();
  const [ads, setAds] = useState<AdData[]>([]);
  const [searchText, setSearchText] = useState('');

  useEffect(() => {
    const fetchAds = async () => {
      try {
        const adCollection = collection(db, 'ads'); 
        const adSnapshot = await getDocs(adCollection);
        const fetchedAds = adSnapshot.docs.map((doc) => ({
          id: doc.id,
          title: doc.data().adTitle || '', 
        }));
        setAds(fetchedAds);
      } catch (error) {
        console.error('Error fetching ads:', error);
      }
    };

    fetchAds();
  }, []);

  const filteredAds = ads.filter((ad) =>
    ad.title.toLowerCase().includes(searchText.toLowerCase())
  );

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.push('/admin/dashboard')}>
          <Ionicons name="arrow-back" size={24} color="black" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Manage Ads</Text>
      </View>

      <View style={styles.searchContainer}>
        <TextInput
          style={styles.searchInput}
          placeholder="Search by title..."
          value={searchText}
          onChangeText={setSearchText}
        />
        <TouchableOpacity 
          onPress={() => router.push('/admin/marketing/addnewads')} 
          style={styles.addButton}
        >
          <Ionicons name="add" size={24} color="black" />
        </TouchableOpacity>
      </View>

      <FlatList
        data={filteredAds}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <TouchableOpacity
            onPress={() => router.push(`/admin/marketing/editads?adId=${item.id}`)} 
            style={styles.adItem}
          >
            <Text style={styles.adId}>ID: {item.id}</Text> 
            <Text style={styles.adTitle}>{item.title}</Text> 
          </TouchableOpacity>
        )}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#fff',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 20,
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    marginLeft: 10,
  },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginVertical: 10,
  },
  searchInput: {
    flex: 1,
    height: 40,
    borderColor: '#ccc',
    borderWidth: 1,
    paddingLeft: 8,
  },
  addButton: {
    marginLeft: 10, 
    padding: 8,
  },
  adItem: {
    padding: 15,
    backgroundColor: '#f9f9f9',
    marginVertical: 5,
    borderRadius: 5,
  },
  adId: {
    fontSize: 14,
    color: '#888', 
  },
  adTitle: {
    fontSize: 18,
    fontWeight: 'bold',
  },
});

export default ManageAds;
