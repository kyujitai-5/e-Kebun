import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, ActivityIndicator, TouchableOpacity, Modal } from 'react-native';
import { useRouter, useLocalSearchParams } from 'expo-router';
import { db } from '../../src/firebaseConfig'; 
import { doc, getDoc, updateDoc, collection, addDoc } from 'firebase/firestore';
import RNPickerSelect from 'react-native-picker-select';
import Icon from 'react-native-vector-icons/FontAwesome'; 

const Checkout = () => {
  const router = useRouter();
  const searchParams = useLocalSearchParams();

  const orderIds = Array.isArray(searchParams.orderIds)
    ? searchParams.orderIds
    : searchParams.orderIds?.split(',') || [];

  const [loading, setLoading] = useState(false);
  const [orders, setOrders] = useState<any[]>([]);
  const [fetchedOrderIds, setFetchedOrderIds] = useState<string[]>([]);
  const [total, setTotal] = useState(0);
  const [selectedBank, setSelectedBank] = useState<string | null>(null);
  const [buyerEmail, setBuyerEmail] = useState<string | null>(null);
  const [buyerUsername, setBuyerUsername] = useState<string | null>(null);
  const [isPaymentSuccessful, setIsPaymentSuccessful] = useState(false);

  const banks = [
    { label: 'Maybank', value: 'Maybank' },
    { label: 'CIMB', value: 'CIMB' },
    { label: 'Public Bank', value: 'Public Bank' },
    { label: 'RHB', value: 'RHB' },
    { label: 'Hong Leong Bank', value: 'Hong Leong Bank' },
  ];

  useEffect(() => {
    if (orderIds.length === 0 || JSON.stringify(orderIds) === JSON.stringify(fetchedOrderIds)) {
      return;
    }

    const fetchOrderDetails = async () => {
      setLoading(true);
      try {
        const fetchedOrders = [];
        let accumulatedTotal = 0;

        for (const orderId of orderIds) {
          const orderRef = doc(db, 'orders', orderId);
          const orderSnap = await getDoc(orderRef);

          if (orderSnap.exists()) {
            const orderData = orderSnap.data();
            fetchedOrders.push({
              username: orderData.sellerUsername,
              subtotal: orderData.subtotal,
            });
            accumulatedTotal += orderData.subtotal || 0;

            if (!buyerEmail || !buyerUsername) {
              setBuyerEmail(orderData.buyerEmail);
              setBuyerUsername(orderData.buyerUsername);
            }
          }
        }

        setOrders(fetchedOrders);
        setTotal(accumulatedTotal);
        setFetchedOrderIds(orderIds);
      } catch (error) {
        console.error('Error fetching order details:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchOrderDetails();
  }, [orderIds, fetchedOrderIds]);

  const handleBankSelection = (value: string) => {
    setSelectedBank(value);
  };

  const handlePayment = async () => {
    if (!selectedBank) {
      return;
    }

    const transactionDate = new Date().toISOString();

    try {
      const transactionRef = await addDoc(collection(db, 'transactions'), {
        transactionDate: transactionDate,
        total,
        bank: selectedBank,
        transactionType: 'Listing',
        email: buyerEmail,
        username: buyerUsername,
      });

      for (const orderId of orderIds) {
        const orderRef = doc(db, 'orders', orderId);
        await updateDoc(orderRef, {
          transactionId: transactionRef.id,
        });
      }

      setIsPaymentSuccessful(true);
    } catch (error) {
      console.error('Error creating transaction:', error);
    }
  };

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#0000ff" />
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <View style={styles.headerContainer}>
        <Text style={styles.header}>Listing Check Out</Text>
      </View>

      <View style={styles.bankSelection}>
        <Text style={styles.bankText}>Select Bank</Text>
        <RNPickerSelect
          onValueChange={handleBankSelection}
          items={banks}
          placeholder={{ label: 'Select a Bank...', value: null }}
          style={{
            inputAndroid: styles.picker,
            inputIOS: styles.picker,
          }}
          value={selectedBank}
        />
        <View style={styles.separator}></View> 
      </View>

      <View style={styles.ordersContainer}>
        {orders.length > 0 ? (
          orders.map((order, index) => (
            <View key={index} style={styles.orderCard}>
              <Text style={styles.text}>@{order.username}</Text>
              <Text style={styles.text}>Subtotal: RM {order.subtotal || 0}</Text>
            </View>
          ))
        ) : (
          <Text style={styles.text}>No orders found.</Text>
        )}
      </View>

      <View style={styles.footer}>
        <View style={styles.totalCard}>
          <Text style={styles.totalText}>Total: RM {total.toFixed(2)}</Text>
        </View>
        <TouchableOpacity
          style={[styles.paymentButton, selectedBank ? {} : styles.paymentButtonDisabled]}
          onPress={handlePayment}
          disabled={!selectedBank}
        >
          {selectedBank ? (
            <Text style={styles.paymentButtonText}>Pay</Text>
          ) : (
            <ActivityIndicator color="#fff" />
          )}
        </TouchableOpacity>
      </View>

      <Modal visible={isPaymentSuccessful} transparent animationType="fade">
        <View style={styles.modalContainer}>
          <View style={styles.modalContent}>
            <View style={styles.checkmarkContainer}>
            <Icon name="check-circle" size={100} color="green" style={styles.tickIcon} />
            </View>
            <Text style={styles.successText}>Payment Successful!</Text>
            <TouchableOpacity
              style={styles.modalButton}
              onPress={() => {
                setIsPaymentSuccessful(false);
                router.push('/user/account/purchases');
              }}
            >
              <Text style={styles.modalButtonText}>View Purchases</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.modalButton, { backgroundColor: '#ccc' }]}
              onPress={() => {
                setIsPaymentSuccessful(false);
                router.push('/user/(tabs)/market');
              }}
            >
              <Text style={styles.modalButtonText}>Go to Market</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#f9f9f9',
  },
  headerContainer: {
    marginBottom: 20,
  },
  header: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#333',
  },
  bankSelection: {
    marginBottom: 20,
  },
  bankText: {
    fontSize: 18,
    color: '#333',
    marginBottom: 10,
  },
  picker: {
    height: 60,
    width: '100%',
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#ddd',
    paddingLeft: 10,
  },
  separator: {
    borderBottomWidth: 1,
    borderBottomColor: '#ddd',
    marginTop: 10,
    marginBottom: 10,
  },
  ordersContainer: {
    marginBottom: 30,
    width: '100%',
  },
  orderCard: {
    padding: 16,
    backgroundColor: '#fff',
    borderRadius: 8,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 3,
  },
  text: {
    fontSize: 16,
    color: '#333',
  },
  footer: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    padding: 20,
    backgroundColor: '#fff',
    borderTopWidth: 1,
    borderTopColor: '#ddd',
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  totalCard: {
    marginBottom: 10,
  },
  totalText: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  paymentButton: {
    backgroundColor: '#007BFF',
    paddingVertical: 12,
    paddingHorizontal: 30,
    borderRadius: 8,
  },
  paymentButtonDisabled: {
    backgroundColor: '#b0c4de',
  },
  paymentButtonText: {
    color: '#fff',
    fontSize: 18,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0,0,0,0.5)',
  },
  modalContent: {
    width: '80%',
    padding: 20,
    backgroundColor: '#fff',
    borderRadius: 10,
    alignItems: 'center',
  },
  checkmarkContainer: {
    marginBottom: 20,
  },
  successText: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#28a745',
    marginBottom: 20,
  },
  modalButton: {
    backgroundColor: '#007BFF',
    paddingVertical: 12,
    paddingHorizontal: 40,
    borderRadius: 8,
    marginBottom: 10,
  },
  modalButtonText: {
    color: '#fff',
    fontSize: 18,
  },
  tickIcon: {
    marginBottom: 0,
  },
});

export default Checkout;
