import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ActivityIndicator,
  Image,
  ScrollView,
  FlatList,
  TouchableOpacity,
  Modal,
} from 'react-native';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { db } from '../../src/firebaseConfig';
import { doc, getDoc, collection, getDocs, query, where } from 'firebase/firestore';
import { Ionicons } from '@expo/vector-icons'; 

interface Location {
  state: string;
  city: string;
  postcode: number;
  section: string;
}

interface Plot {
  plotNumber: string; 
  plotDocId: string; 
  status: string;
  type: string;
}

interface PlotDetails {
  name: string;
  description: string;
  images: string[];
  location: Location;
  plots: Plot[];
}

const PlotAreaDetails = () => {
  const { id } = useLocalSearchParams();
  const router = useRouter();
  const [plotDetails, setPlotDetails] = useState<PlotDetails | null>(null);
  const [loading, setLoading] = useState(true);
  const [modalVisible, setModalVisible] = useState(false);
  const [selectedImage, setSelectedImage] = useState<string | null>(null);

  useEffect(() => {
    if (id) {
      const fetchPlotDetails = async () => {
        try {
          const plotDoc = await getDoc(doc(db, 'plotarea', id as string));
          if (plotDoc.exists()) {
            const data = plotDoc.data() as Omit<PlotDetails, 'plots'>;

            const plotsQuery = query(
              collection(db, 'plots'),
              where('plotAreaId', '==', id)
            );
            const plotsSnapshot = await getDocs(plotsQuery);
            const plots = plotsSnapshot.docs.map((doc) => ({
              plotNumber: doc.data().plotNumber, // Readable plot number
              plotDocId: doc.id,                 // Auto-generated doc ID
              status: doc.data().status,
              type: doc.data().type,
            }));

            setPlotDetails({ ...data, plots });
          } else {
            console.log('No such document!');
          }
        } catch (error) {
          console.error('Error fetching plot details:', error);
        } finally {
          setLoading(false);
        }
      };
      fetchPlotDetails();
    }
  }, [id]);

  if (loading) {
    return <ActivityIndicator size="large" color="#007BFF" />;
  }

  if (!plotDetails) {
    return <Text style={styles.noDataText}>Plot details not found.</Text>;
  }

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.push('/admin/plots/manageplots')}>
          <Ionicons name="arrow-back" size={24} color="black" />
        </TouchableOpacity>
        <TouchableOpacity onPress={() => router.push(`/admin/plots/editplotarea?id=${id}`)}>
          <Text style={styles.editButton}>Edit</Text>
        </TouchableOpacity>
      </View>
  
      <Text style={styles.detailText}>ID: {id}</Text>
      <Text style={styles.detailText}>Name: {plotDetails.name}</Text>
      <Text style={styles.detailText}>Description: {plotDetails.description}</Text>
  
      <Text style={styles.sectionTitle}>Location</Text>
      <Text style={styles.detailText}>State: {plotDetails.location.state}</Text>
      <Text style={styles.detailText}>City: {plotDetails.location.city}</Text>
      <Text style={styles.detailText}>Postcode: {plotDetails.location.postcode}</Text>
      <Text style={styles.detailText}>Section: {plotDetails.location.section}</Text>
  
      <Text style={styles.sectionTitle}>Images</Text>
      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.imageScroll}>
        {plotDetails.images.map((image, index) => (
          <TouchableOpacity key={index} onPress={() => {
            setSelectedImage(image);
            setModalVisible(true);
          }}>
            <Image source={{ uri: image }} style={styles.imageThumbnail} />
          </TouchableOpacity>
        ))}
      </ScrollView>
      <Modal
        visible={modalVisible}
        transparent={true}
        onRequestClose={() => setModalVisible(false)}
      >
        <View style={styles.modalContainer}>
          <TouchableOpacity
            onPress={() => setModalVisible(false)}
            style={styles.closeButton}
          >
            <Text style={styles.closeButtonText}>×</Text>
          </TouchableOpacity>
          <Image
            source={selectedImage ? { uri: selectedImage } : undefined}
            style={styles.modalImage}
          />
        </View>
      </Modal>
  
      <Text style={styles.sectionTitle}>Plots</Text>
        {plotDetails.plots.map((item) => (
          <TouchableOpacity
            key={item.plotDocId}
            style={styles.plotContainer}
            onPress={() => {
              router.push(`/admin/plots/plotrentaldetails?plotId=${item.plotDocId}`);
            }}
          >
            <Text style={styles.detailText}>Plot Number: {item.plotNumber}</Text>
            <Text style={styles.detailText}>Status: {item.status}</Text>
            <Text style={styles.detailText}>Type: {item.type}</Text>
          </TouchableOpacity>
        ))}
    </ScrollView>
  );  
};

const styles = StyleSheet.create({
  container: {
    padding: 20,
    backgroundColor: '#fff',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 20,
  },
  editButton: {
    fontSize: 18,
    color: '#007BFF',
  },
  detailText: {
    fontSize: 16,
    marginBottom: 5,
  },
  noDataText: {
    fontSize: 18,
    color: '#555',
    textAlign: 'center',
    marginTop: 20,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    marginTop: 20,
    marginBottom: 10,
  },
  imageScroll: {
    marginVertical: 10,
  },
  imageThumbnail: {
    width: 100,
    height: 100,
    marginRight: 10,
    borderRadius: 5,
  },
  modalContainer: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.9)',
    justifyContent: 'center',
    alignItems: 'center',
    position: 'relative',
  },
  modalImage: {
    width: '90%',
    height: '70%',
    resizeMode: 'contain',
  },
  closeButton: {
    position: 'absolute',
    top: 40,
    right: 20,
    zIndex: 10,
  },
  closeButtonText: {
    fontSize: 30,
    color: 'white',
    fontWeight: 'bold',
  },
  plotContainer: {
    paddingVertical: 10,
    borderBottomColor: '#ccc',
    borderBottomWidth: 1,
  },
});

export default PlotAreaDetails;
