import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ActivityIndicator,
  ScrollView,
  TouchableOpacity,
} from 'react-native';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { db } from '../../src/firebaseConfig';
import { collection, query, where, getDocs } from 'firebase/firestore';
import { Ionicons } from '@expo/vector-icons';

interface PlotRentalDetails {
  username: string;
  email: string;
  transactionId: string;
  period: number;
  plotId: string;
  price: number;
  rentalEndDate: string;
  rentalStartDate: string;
}

const PlotRentalDetailsPage = () => {
  const { plotId } = useLocalSearchParams();
  const router = useRouter();

  const [plotDetails, setPlotDetails] = useState<PlotRentalDetails | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (plotId) {
      const fetchRentalDetails = async () => {
        try {
          // Query the 'rent' collection to find the document with the matching plotId
          const rentRef = collection(db, 'rent');
          const q = query(rentRef, where('plotId', '==', plotId as string));
          const querySnapshot = await getDocs(q);
          
          if (!querySnapshot.empty) {
            // Assuming only one document will match the plotId
            const rentalDoc = querySnapshot.docs[0];
            const data = rentalDoc.data() as PlotRentalDetails;
            setPlotDetails(data);  // Set the fetched data to state
          } else {
            console.log('No rental found for the given plotId!');
          }
        } catch (error) {
          console.error('Error fetching rental details:', error);
        } finally {
          setLoading(false);
        }
      };

      fetchRentalDetails();
    }
  }, [plotId]);

  if (loading) {
    return <ActivityIndicator size="large" color="#007BFF" />;
  }

  return (
    <ScrollView contentContainerStyle={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()}>
          <Ionicons name="arrow-back" size={24} color="black" />
        </TouchableOpacity>
        <Text style={styles.title}>Plot Rental Details</Text>
      </View>

      {/* If no plot details found, show a message */}
      {!plotDetails ? (
        <Text style={styles.noDataText}>Plot rental details not found.</Text>
      ) : (
        <View style={styles.panel}>
          <Text style={styles.detailText}>@{plotDetails.username}</Text>
          <Text style={styles.detailText}>Transaction ID: {plotDetails.transactionId}</Text>
          <Text style={styles.detailText}>Price: RM {plotDetails.price}</Text>
          <Text style={styles.detailText}>Period: {plotDetails.period} Year(s)</Text>
          <Text style={styles.detailText}>Rental Start Date: {new Date(plotDetails.rentalStartDate).toLocaleString()}</Text>
          <Text style={styles.detailText}>Rental End Date: {new Date(plotDetails.rentalEndDate).toLocaleString()}</Text>
        </View>
      )}
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1, // Ensure the container takes up the full screen
    padding: 20,
    backgroundColor: '#fff', // White background will cover the entire screen
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
    marginLeft: 10 
  },
  panel: {
    backgroundColor: '#f9f9f9',
    padding: 20,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#ddd',
  },
  detailText: {
    fontSize: 16,
    marginBottom: 10,
    color: '#333',
  },
  noDataText: {
    fontSize: 18,
    color: '#555',
    textAlign: 'center',
    marginTop: 20,
  },
});

export default PlotRentalDetailsPage;
