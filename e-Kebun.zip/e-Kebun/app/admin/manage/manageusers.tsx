import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  FlatList,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  Modal,
  ActivityIndicator,
  ScrollView,
  Image,
} from 'react-native';
import { db } from '../../src/firebaseConfig';
import { collection, getDocs, doc, getDoc } from 'firebase/firestore';
import { Ionicons } from '@expo/vector-icons'; 
import { router } from 'expo-router';

interface UserData {
  id: string;
  email: string;
  name: string;
  username: string;
}

const ManageUsers = () => {
  const [users, setUsers] = useState<UserData[]>([]);
  const [searchText, setSearchText] = useState('');
  const [selectedUser, setSelectedUser] = useState<any>(null); // Store details of the selected user
  const [loadingUserDetails, setLoadingUserDetails] = useState(false); // Loading state for user details
  const [modalVisible, setModalVisible] = useState(false);

  useEffect(() => {
    const fetchUsers = async () => {
      try {
        const userCollection = collection(db, 'user');
        const userSnapshot = await getDocs(userCollection);

        const fetchedUsers = userSnapshot.docs.map((doc) => ({
          id: doc.id,
          email: doc.data().email || '',
          name: doc.data().name || '',
          username: doc.data().username || '',
        }));

        setUsers(fetchedUsers);
      } catch (error) {
        console.error('Error fetching users:', error);
      }
    };

    fetchUsers();
  }, []);

  const handleUserClick = async (userId: string) => {
    setLoadingUserDetails(true);
    setModalVisible(true);

    try {
      const userDocRef = doc(db, 'user', userId);
      const userDoc = await getDoc(userDocRef);

      if (userDoc.exists()) {
        setSelectedUser(userDoc.data());
      } else {
        console.error('No such user found.');
        setSelectedUser(null);
      }
    } catch (error) {
      console.error('Error fetching user details:', error);
    } finally {
      setLoadingUserDetails(false);
    }
  };

  const filteredUsers = users.filter((user) =>
    user.email.toLowerCase().includes(searchText.toLowerCase()) ||
    user.name.toLowerCase().includes(searchText.toLowerCase()) ||
    user.username.toLowerCase().includes(searchText.toLowerCase())
  );

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()}>
          <Ionicons name="arrow-back" size={24} color="black" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Manage Users</Text>
      </View>

      <View style={styles.searchContainer}>
        <TextInput
          style={styles.searchInput}
          placeholder="Search by email, name, or username..."
          value={searchText}
          onChangeText={setSearchText}
        />
      </View>

      <FlatList
        data={filteredUsers}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <TouchableOpacity
            onPress={() => handleUserClick(item.id)}
            style={styles.userItem}
          >
            <Text style={styles.userUsername}>@{item.username}</Text>
            <Text style={styles.userName}>{item.name}</Text>
            <Text style={styles.userEmail}>{item.email}</Text>
          </TouchableOpacity>
        )}
      />

      <Modal
        visible={modalVisible}
        animationType="fade"
        transparent={true}
        onRequestClose={() => setModalVisible(false)}
      >
        <View style={styles.modalContainer}>
          <View style={styles.modalContent}>
            <TouchableOpacity
              style={styles.closeButton}
              onPress={() => setModalVisible(false)}
            >
              <Ionicons name="close" size={24} color="black" />
            </TouchableOpacity>

            {loadingUserDetails ? (
              <ActivityIndicator size="large" color="#0000ff" />
            ) : selectedUser ? (
              <ScrollView>
                {selectedUser.profilePicture ? (
                  <Image
                    source={{ uri: selectedUser.profilePicture }}
                    style={styles.profilePicture}
                  />
                ) : (
                  <Text style={styles.noPictureText}>No Profile Picture</Text>
                )}

                <Text style={styles.label}>Name</Text>
                <Text style={styles.value}>{selectedUser.name || 'N/A'}</Text>

                <Text style={styles.label}>Email</Text>
                <Text style={styles.value}>{selectedUser.email || 'N/A'}</Text>

                <Text style={styles.label}>Phone Number</Text>
                <Text style={styles.value}>{selectedUser.phoneno || 'N/A'}</Text>

                <Text style={styles.label}>Username</Text>
                <Text style={styles.value}>{selectedUser.username || 'N/A'}</Text>
                
                <Text style={styles.label}>Location</Text>
                <Text style={styles.value}>
                  {selectedUser.location
                    ? `${selectedUser.location.section || 'N/A'}, ${
                        selectedUser.location.postcode || 'N/A'
                      }, ${selectedUser.location.city || 'N/A'}, ${
                        selectedUser.location.state || 'N/A'
                      }`
                    : 'N/A'}
                </Text>
              </ScrollView>
            ) : (
              <Text style={styles.errorText}>User details not found.</Text>
            )}
          </View>
        </View>
      </Modal>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#fff',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 20,
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    marginLeft: 10,
  },
  searchContainer: {
    marginVertical: 10,
  },
  searchInput: {
    height: 40,
    borderColor: '#ccc',
    borderWidth: 1,
    paddingLeft: 8,
  },
  userItem: {
    padding: 15,
    backgroundColor: '#f9f9f9',
    marginVertical: 5,
    borderRadius: 5,
  },
  userEmail: {
    fontSize: 14,
    color: '#555',
  },
  userName: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  userUsername: {
    fontSize: 14,
    color: '#777',
  },
  modalContainer: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalContent: {
    width: '90%',
    padding: 20,
    backgroundColor: 'white',
    borderRadius: 10,
  },
  closeButton: {
    alignSelf: 'flex-end',
  },
  profilePicture: {
    width: 100,
    height: 100,
    borderRadius: 50,
    alignSelf: 'center',
    marginBottom: 20,
  },
  noPictureText: {
    textAlign: 'center',
    marginBottom: 20,
    color: '#aaa',
  },
  label: {
    fontWeight: 'bold',
    marginTop: 10,
  },
  value: {
    marginBottom: 10,
  },
  errorText: {
    color: 'red',
    textAlign: 'center',
  },
});

export default ManageUsers;
