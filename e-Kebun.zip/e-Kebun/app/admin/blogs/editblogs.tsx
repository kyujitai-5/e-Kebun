import React, { useState, useEffect } from 'react';
import { View, Text, TextInput, StyleSheet, TouchableOpacity, Alert, ActivityIndicator } from 'react-native';
import { db } from '../../src/firebaseConfig';
import { doc, getDoc, updateDoc, deleteDoc } from 'firebase/firestore';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';

const EditBlogs = () => {
  const { blogId } = useLocalSearchParams(); // Extract the blogId from the URL
  const router = useRouter();

  const [blogTitle, setBlogTitle] = useState('');
  const [blogDescription, setBlogDescription] = useState('');
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    const fetchBlogData = async () => {
      if (!blogId) {
        Alert.alert('Error', 'No Blog ID provided.');
        router.back(); 
        return;
      }

      try {
        setLoading(true);
        const blogDocRef = doc(db, 'blogs', blogId as string); // Fetch the blog document
        const blogDoc = await getDoc(blogDocRef);

        if (blogDoc.exists()) {
          const blogData = blogDoc.data();
          setBlogTitle(blogData.title || '');
          setBlogDescription(blogData.description || '');
        } else {
          Alert.alert('Error', 'Blog not found.');
          router.back();
        }
      } catch (error) {
        console.error('Error fetching blog:', error);
        Alert.alert('Error', 'Could not fetch blog data.');
      } finally {
        setLoading(false);
      }
    };

    fetchBlogData();
  }, [blogId]);

  const handleSave = async () => {
    if (saving) return;
    setSaving(true);

    try {
      if (!blogId) {
        Alert.alert('Error', 'No Blog ID found.');
        return;
      }

      const blogDocRef = doc(db, 'blogs', blogId as string);
      await updateDoc(blogDocRef, {
        title: blogTitle,
        description: blogDescription,
      });

      Alert.alert('Success', 'Blog updated successfully!');
      router.push('/admin/blogs/manageblogs'); 
    } catch (error) {
      console.error('Error updating blog:', error);
      Alert.alert('Error', 'There was an issue updating the blog.');
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async () => {
    Alert.alert(
      'Delete Blog',
      'Are you sure you want to delete this blog?',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Yes',
          onPress: async () => {
            try {
              if (!blogId) {
                Alert.alert('Error', 'No Blog ID found.');
                return;
              }

              const blogDocRef = doc(db, 'blogs', blogId as string);
              await deleteDoc(blogDocRef);

              Alert.alert('Success', 'Blog deleted successfully!');
              router.push('/admin/blogs/manageblogs'); // Navigate back to the blogs list page
            } catch (error) {
              console.error('Error deleting blog:', error);
              Alert.alert('Error', 'There was an issue deleting the blog.');
            }
          },
        },
      ],
      { cancelable: true }
    );
  };

  if (loading) {
    return (
      <View style={styles.loaderContainer}>
        <ActivityIndicator size="large" color="#000" />
        <Text>Loading blog data...</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()}>
          <Ionicons name="arrow-back" size={24} color="black" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Edit Blog</Text>
      </View>

      <View style={styles.inputContainer}>
        <Text style={styles.label}>Blog Title</Text>
        <TextInput
          value={blogTitle}
          onChangeText={setBlogTitle}
          placeholder="Enter Blog Title"
          style={styles.input}
        />
      </View>

      <View style={styles.inputContainer}>
        <Text style={styles.label}>Blog Description</Text>
        <TextInput
          value={blogDescription}
          onChangeText={setBlogDescription}
          placeholder="Enter Blog Description"
          style={styles.input}
          multiline
          numberOfLines={4}
        />
      </View>

      <View style={styles.buttonContainer}>
        <TouchableOpacity style={[styles.button, { backgroundColor: '#007BFF' }]} onPress={handleSave}>
          <Text style={styles.buttonText}>{saving ? 'Saving...' : 'Save Changes'}</Text>
        </TouchableOpacity>
        <TouchableOpacity style={[styles.button, { backgroundColor: '#FF0000' }]} onPress={handleDelete}>
          <Text style={styles.buttonText}>Delete</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#fff',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 20,
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    marginLeft: 10,
  },
  inputContainer: {
    marginVertical: 10,
  },
  label: {
    fontSize: 16,
    marginBottom: 8,
  },
  input: {
    borderWidth: 1,
    borderColor: '#ccc',
    padding: 10,
    borderRadius: 5,
    fontSize: 16,
  },
  loaderContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  buttonContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 20,
  },
  button: {
    flex: 1,
    marginHorizontal: 5,
    padding: 15,
    borderRadius: 5,
    alignItems: 'center',
  },
  buttonText: {
    color: 'white',
    fontWeight: 'bold',
  },
});

export default EditBlogs;
