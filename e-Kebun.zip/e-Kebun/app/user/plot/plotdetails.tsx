import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, ActivityIndicator, Image, ScrollView, TouchableOpacity, FlatList, Modal } from 'react-native';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { collection, doc, getDoc, getDocs, addDoc, updateDoc, query, where } from 'firebase/firestore';
import { auth, db } from '../../src/firebaseConfig';
import Icon from 'react-native-vector-icons/Ionicons';
import AsyncStorage from '@react-native-async-storage/async-storage';

interface Location {
  state: string;
  city: string;
  postcode: number;
  section: string;
}

interface PlotAvailability {
  type: string;
  quantity: number;
}

interface PlotDetails {
  name: string;
  description: string;
  images: string[];
  location: Location;
  plotAvailability: Record<string, number>;
}

interface PeriodPrice {
  period: number;
  price: number;
}

const PlotDetails = () => {
  const { id } = useLocalSearchParams();
  const router = useRouter();
  const [plotDetails, setPlotDetails] = useState<PlotDetails | null>(null);
  const [loading, setLoading] = useState(true);
  const [selectedType, setSelectedType] = useState<string | null>(null);
  const [selectedPeriod, setSelectedPeriod] = useState<number | null>(null);
  const [quantity, setQuantity] = useState(1);
  const [periodPriceData, setPeriodPriceData] = useState<PeriodPrice[]>([]);
  const [typeAddedQuantity, setTypeAddedQuantity] = useState<Record<string, number>>({});
  const [modalVisible, setModalVisible] = useState(false);
  const [selectedImage, setSelectedImage] = useState<string | null>(null);

  useEffect(() => {
    const fetchPlotDetails = async () => {
      try {
        const docRef = doc(db, 'plotarea', id as string);
        const docSnap = await getDoc(docRef);
        if (docSnap.exists()) {
          const plotData = docSnap.data() as PlotDetails;
  
          // Filter out unavailable plot types based on their status (only keep available)
          const availablePlotTypes: Record<string, number> = {};
  
          // Loop through each plot type and check if it has available plots
          for (const [type, quantity] of Object.entries(plotData.plotAvailability)) {
            const plotRef = collection(db, 'plots');
            const plotQuery = query(
              plotRef,
              where('plotAreaId', '==', id),
              where('type', '==', type),
              where('status', '==', 'available') // Only consider available plots
            );
            
            // Fetch available plots for the current type
            const plotSnapshot = await getDocs(plotQuery);
            if (!plotSnapshot.empty) {
              // If there are available plots, keep this type in the availablePlotTypes
              availablePlotTypes[type] = quantity;
            }
          }
  
          setPlotDetails({
            ...plotData,
            plotAvailability: availablePlotTypes, // Set filtered available plots
          });
        } else {
          console.error('No document found');
        }
      } catch (error) {
        console.error('Error fetching plot details:', error);
      } finally {
        setLoading(false);
      }
    };
  
    const fetchPeriodPriceData = async () => {
      try {
        const querySnapshot = await getDocs(collection(db, 'plotsetpp'));
        const data: PeriodPrice[] = [];
        querySnapshot.forEach(doc => {
          const docData = doc.data();
          if (docData.period && docData.price) {
            data.push({ period: docData.period, price: docData.price });
          }
        });
        setPeriodPriceData(data);
      } catch (error) {
        console.error('Error fetching period-price data:', error);
      }
    };
  
    fetchPlotDetails();
    fetchPeriodPriceData();
  }, [id]);
  
  const handleAddToCart = async () => {
    if (!selectedType || !selectedPeriod) {
      alert('Please select both a plot type and a period.');
      return;
    }
  
    const availableQuantity = plotDetails?.plotAvailability[selectedType] || 0;
    const cartRef = collection(db, 'plotcart');
    const cartQuery = query(
      cartRef,
      where('plotAreaId', '==', id),
      where('plotType', '==', selectedType)
    );
  
    try {
      const email = await AsyncStorage.getItem('userEmail') || auth.currentUser?.email;
      if (!email) {
        alert('Please log in to add to cart');
        return;
      }
  
      const querySnapshot = await getDocs(cartQuery);
      let totalAddedQuantity = 0;
      querySnapshot.forEach(doc => {
        totalAddedQuantity += doc.data().quantity;
      });
  
      if (quantity + totalAddedQuantity > availableQuantity) {
        alert('Not enough available plots. Please adjust your quantity.');
        return;
      }
  
      const cartData = {
        plotAreaId: id,
        plotType: selectedType,
        period: selectedPeriod,
        quantity: quantity,
        email: email,
      };
  
      if (!querySnapshot.empty) {
        const existingDoc = querySnapshot.docs.find(doc => doc.data().period === selectedPeriod);
        if (existingDoc) {
          const existingDocRef = doc(db, 'plotcart', existingDoc.id);
          await updateDoc(existingDocRef, {
            quantity: existingDoc.data().quantity + quantity,
          });
          alert('Cart item updated successfully');
        } else {
          await addDoc(cartRef, cartData);
          alert('Plot added to cart successfully');
        }
      } else {
        await addDoc(cartRef, cartData);
        alert('Plot added to cart successfully');
      }
    } catch (error) {
      console.error('Error adding to cart:', error);
      alert('There was an error adding the plot to your cart. Please try again.');
    }
  };
  
  if (loading) {
    return <ActivityIndicator size="large" color="#007BFF" />;
  }

  if (!plotDetails) {
    return <Text>Plot details not found.</Text>;
  }

  const plotAvailabilityArray = plotDetails?.plotAvailability
    ? Object.entries(plotDetails.plotAvailability).map(([type, quantity]) => ({
        type,
        quantity,
      }))
    : [];

  const selectedPrice = periodPriceData.find(item => item.period === selectedPeriod)?.price || 0;

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()}>
          <Icon name="arrow-back" size={30} color="#000" />
        </TouchableOpacity>
        <TouchableOpacity onPress={() => router.push('/user/plot/plotcart')}>
          <Icon name="cart-outline" size={30} color="#000" />
        </TouchableOpacity>
      </View>

      <FlatList
        data={plotDetails.images}
        horizontal
        renderItem={({ item }) => (
          <TouchableOpacity onPress={() => { setSelectedImage(item); setModalVisible(true); }}>
            <Image source={{ uri: item }} style={styles.plotImage} />
          </TouchableOpacity>
        )}
        keyExtractor={(item, index) => index.toString()}
      />

      {selectedImage && (
        <Modal
          visible={modalVisible}
          transparent={true}
          animationType="fade"
          onRequestClose={() => {
            setModalVisible(false);
            setSelectedImage(null);
          }}
        >
          <View style={styles.modalContainer}>
            <TouchableOpacity
              onPress={() => {
                setModalVisible(false);
                setSelectedImage(null);
              }}
              style={styles.modalCloseButton}
            >
              <Icon name="close" size={30} color="white" />
            </TouchableOpacity>
            <Image source={{ uri: selectedImage }} style={styles.expandedImage} />
          </View>
        </Modal>
      )}

      <View style={styles.detailsSection}>
        <Text style={styles.plotTitle}>{plotDetails.name}</Text>
        <Text style={styles.plotDescription}>{plotDetails.description}</Text>

        <Text style={styles.sectionTitle}>Location</Text>
        <View style={styles.locationDetails}>
          <Text><Text style={styles.bold}>Section           </Text> {plotDetails.location.section}</Text>
          <Text><Text style={styles.bold}>Postcode        </Text> {plotDetails.location.postcode}</Text>
          <Text><Text style={styles.bold}>City                 </Text> {plotDetails.location.city}</Text>
          <Text><Text style={styles.bold}>State               </Text> {plotDetails.location.state}</Text>
        </View>
      </View>

      <View style={styles.rentSection}>
        <Text style={styles.sectionTitle}>Available Plots</Text>
        <View style={styles.options}>
          <Text style={styles.bold}>Type</Text>
        </View>
        <View style={styles.options}>
          {plotAvailabilityArray
            .filter(item => item.quantity > 0)
            .map((item, index) => (
              <TouchableOpacity
                key={index}
                style={[styles.optionButton, item.quantity <= 0 && styles.disabled, selectedType === item.type && styles.selected]}
                disabled={item.quantity <= 0}
                onPress={() => item.quantity > 0 && setSelectedType(item.type)}
              >
                <Text style={styles.optionButtonText}>{item.type}</Text>
              </TouchableOpacity>
            ))}
        </View>

        <View style={styles.options}>
          <Text style={styles.bold}>Period by Year(s)</Text>
        </View>
        <View style={styles.options}>
          {periodPriceData.map((item, index) => (
            <TouchableOpacity
              key={index}
              style={[styles.optionButton, selectedPeriod === item.period && styles.selected]}
              onPress={() => setSelectedPeriod(item.period)}
            >
              <Text style={styles.optionButtonText}>{item.period}</Text>
            </TouchableOpacity>
          ))}
        </View>

        <Text style={[styles.bold, styles.price]}>RM {selectedPrice}</Text>
      </View>

      <View style={styles.quantitySection}>
        <Text style={styles.bold}>Quantity</Text>
        <TouchableOpacity onPress={() => setQuantity(prev => prev > 1 ? prev - 1 : prev)}>
          <Icon name="remove-circle-outline" size={30} color="#007BFF" />
        </TouchableOpacity>
        <Text style={styles.quantityText}>{quantity}</Text>
        <TouchableOpacity onPress={() => setQuantity(prev => prev + 1)}>
          <Icon name="add-circle-outline" size={30} color="#007BFF" />
        </TouchableOpacity>
      </View>

      <TouchableOpacity style={styles.addToCartButton} onPress={handleAddToCart}>
        <Text style={styles.addToCartText}>Add to Cart</Text>
      </TouchableOpacity>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flexGrow: 1,
    backgroundColor: '#fff',
    paddingHorizontal: 20,
    paddingBottom: 20,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 20,
  },
  plotImage: {
    width: 300,
    height: 200,
    borderRadius: 10,
    marginRight: 10,
  },
  modalContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  modalCloseButton: {
    position: 'absolute',
    top: 50, 
    right: 20,
    zIndex: 10, 
  },
  
  expandedImage: {
    width: '100%',
    height: '100%',
    resizeMode: 'contain',
  },
  detailsSection: {
    marginTop: 20,
  },
  plotTitle: {
    fontSize: 24,
    fontWeight: 'bold',
  },
  plotDescription: {
    marginVertical: 10,
    fontSize: 16,
    color: '#555',
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginTop: 20,
  },
  locationDetails: {
    marginTop: 10,
    paddingLeft: 10,
  },
  bold: {
    fontWeight: 'bold',
  },
  rentSection: {
    marginTop: 30,
  },
  options: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    marginTop: 10,
  },
  optionButton: {
    marginRight: 10,
    marginBottom: 10,
    paddingVertical: 5,
    paddingHorizontal: 15,
    backgroundColor: '#f2f2f2',
    borderRadius: 10,
  },
  optionButtonText: {
    fontSize: 16,
  },
  disabled: {
    backgroundColor: '#ccc',
  },
  selected: {
    backgroundColor: '#007BFF',
  },
  quantitySection: {
    marginTop: 30,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  quantityText: {
    fontSize: 18,
    marginHorizontal: 10,
  },
  price: {
    fontSize: 30,  
    fontWeight: 'bold',  
    color: '#000',  
  },
  addToCartButton: {
    marginTop: 30,
    backgroundColor: '#007BFF',
    paddingVertical: 15,
    borderRadius: 10,
    alignItems: 'center',
  },
  addToCartText: {
    color: '#fff',
    fontSize: 18,
  },
});

export default PlotDetails;