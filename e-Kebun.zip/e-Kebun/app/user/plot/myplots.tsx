import React, { useState, useEffect } from 'react';
import {
  StyleSheet,
  View,
  Text,
  TouchableOpacity,
  FlatList,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import {
  collection,
  getDocs,
  query,
  doc,
  getDoc,
} from 'firebase/firestore';
import { db } from '../../src/firebaseConfig';
import AsyncStorage from '@react-native-async-storage/async-storage'; // Import AsyncStorage to get the current user's email
import { getAuth } from 'firebase/auth';

interface Plot {
  id: string;
  plotNumber: string;
  plotAreaId: string;
  plotType: string;
  period: number;
  startDate: string;
  endDate: string;
  archivedDate?: string; // optional, for archived plots
}

export default function MyPlot() {
  const [activePlots, setActivePlots] = useState<Plot[]>([]);
  const [expiredPlots, setExpiredPlots] = useState<Plot[]>([]);
  const [activeTab, setActiveTab] = useState<'Active' | 'Expired'>('Active');
  const router = useRouter();
  const [userEmail, setUserEmail] = useState<string | null>(null);

  useEffect(() => {
    const fetchUserEmail = async () => {
      try {
        let email = await AsyncStorage.getItem('userEmail');
        if (!email) {
          const auth = getAuth();
          email = auth.currentUser?.email || null;
        }
        setUserEmail(email);
        console.log('Fetched email:', email); // Add console log here

      } catch (error) {
        console.error('Error fetching user email:', error);
      }
    };

    fetchUserEmail();
  }, []);
  useEffect(() => {
    if (!userEmail) return; // Do not fetch plots until the user email is available
  
    const fetchPlots = async () => {
      try {
        const rentQuery = query(collection(db, 'rent'));
        const rentSnapshots = await getDocs(rentQuery);
  
        const archivedPlotQuery = query(collection(db, 'archivedplots'));
        const archivedPlotSnapshots = await getDocs(archivedPlotQuery);
  
        const archivedPlots: string[] = [];
        archivedPlotSnapshots.forEach((docSnapshot) => {
          archivedPlots.push(docSnapshot.id); // Collect all archived plot IDs
        });
  
        const now = new Date(); // Current date
        const active: Plot[] = [];
        const expired: Plot[] = [];
  
        for (const docSnapshot of rentSnapshots.docs) {
          const rentData = docSnapshot.data() as {
            plotId: string;
            plotAreaId: string;
            plotType: string;
            period: number;
            rentalStartDate: string;
            rentalEndDate: string;
            email: string; 
          };
  
          const rentEmail = rentData.email;
  
          if (rentEmail !== userEmail) {
            continue;
          }
          
          const endDate = new Date(rentData.rentalEndDate);
          const startDate = new Date(rentData.rentalStartDate);
  
          let plotNumber = 'N/A'; 
          if (rentData.plotId) {
            const plotDoc = await getDoc(doc(db, 'plots', rentData.plotId));
            if (plotDoc.exists()) {
              plotNumber = plotDoc.data()?.plotNumber || 'N/A';
            }
          }
  
          const plot: Plot = {
            id: docSnapshot.id,
            plotNumber,
            plotAreaId: rentData.plotAreaId || 'Unknown',
            plotType: rentData.plotType || 'Unknown',
            period: rentData.period || 0,
            startDate: startDate.toLocaleDateString(), 
            endDate: endDate.toLocaleDateString(), 
          };
  
          // Check if the plot or plot area is archived
          if (archivedPlots.includes(rentData.plotId)) {
            // Plot is archived, set archivedDate
            const archivedDoc = await getDoc(doc(db, 'archivedplots', rentData.plotId));
            if (archivedDoc.exists()) {
              plot.archivedDate = archivedDoc.data()?.archivedDate?.toLocaleDateString();
            }
            expired.push(plot); // Move to expired plots
          } else {
            // Categorize into active or expired based on end date
            if (endDate >= now) {
              active.push(plot);
            } else {
              expired.push(plot);
            }
          }
        }
  
        setActivePlots(active);
        setExpiredPlots(expired);
      } catch (error) {
        console.error('Error fetching plots:', error);
      }
    };
  
    fetchPlots();
  }, [userEmail]); // This hook will run every time the `userEmail` changes
  
  
  const renderPlotItem = ({ item }: { item: Plot }) => (
    <View style={styles.plotItem}>
      <Text style={styles.plotText}>Plot Number: {item.plotNumber}</Text>
      <Text style={styles.plotText}>Plot Area ID: {item.plotAreaId}</Text>
      <Text style={styles.plotText}>Type: {item.plotType}</Text>
      <Text style={styles.plotText}>Period: {item.period} year(s)</Text>
      <Text style={styles.plotText}>Start Date: {item.startDate}</Text>

      <Text style={styles.plotText}>
        {item.archivedDate ? `Archived on: ${item.archivedDate}` : `End Date: ${item.endDate}`}
      </Text>
    </View>
  );

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.push('/user/(tabs)/account')}>
          <Ionicons name="arrow-back" size={24} color="black" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>My Plots</Text>
      </View>

      <View style={styles.tabs}>
        <TouchableOpacity
          style={[styles.tab, activeTab === 'Active' && styles.activeTab]}
          onPress={() => setActiveTab('Active')}
        >
          <Text style={styles.tabText}>Active</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.tab, activeTab === 'Expired' && styles.activeTab]}
          onPress={() => setActiveTab('Expired')}
        >
          <Text style={styles.tabText}>Expired</Text>
        </TouchableOpacity>
      </View>

      <FlatList
        data={activeTab === 'Active' ? activePlots : expiredPlots}
        renderItem={renderPlotItem}
        keyExtractor={(item) => item.id}
        contentContainerStyle={styles.plotList}
        ListEmptyComponent={
          <Text style={styles.emptyText}>
            No plots found.
          </Text>
        }
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f9f9f9',
    padding: 20,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 20,
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    marginLeft: 10,
  },
  tabs: {
    flexDirection: 'row',
    backgroundColor: '#e0e0e0',
    borderRadius: 8,
    marginBottom: 20,
    overflow: 'hidden',
  },
  tab: {
    flex: 1,
    padding: 10,
    alignItems: 'center',
  },
  activeTab: {
    backgroundColor: '#007BFF',
  },
  tabText: {
    fontSize: 16,
    color: '#fff',
  },
  plotList: {
    paddingBottom: 20,
  },
  plotItem: {
    backgroundColor: '#fff',
    padding: 15,
    borderRadius: 8,
    marginBottom: 10,
    shadowColor: '#000',
    shadowOpacity: 0.1,
    shadowRadius: 5,
    shadowOffset: { width: 0, height: 2 },
  },
  plotText: {
    fontSize: 14,
    color: '#333',
    marginBottom: 5,
  },
  emptyText: {
    textAlign: 'center',
    color: '#999',
    marginTop: 20,
  },
});
