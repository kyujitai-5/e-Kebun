import React, { useState, useEffect } from 'react';
import { View, Text, TextInput, StyleSheet, Image, TouchableOpacity, Alert, ActivityIndicator } from 'react-native';
import { db } from '../../src/firebaseConfig';
import { doc, getDoc, updateDoc, deleteDoc } from 'firebase/firestore';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import * as ImagePicker from 'expo-image-picker';

const EditAds = () => {
  const { adId } = useLocalSearchParams(); 
  const router = useRouter();

  const [adTitle, setAdTitle] = useState('');
  const [adImage, setAdImage] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    const fetchAdData = async () => {
      if (!adId) {
        Alert.alert('Error', 'No Ad ID provided.');
        router.back(); 
        return;
      }

      try {
        setLoading(true);
        const adDocRef = doc(db, 'ads', adId as string); 
        const adDoc = await getDoc(adDocRef);

        if (adDoc.exists()) {
          const adData = adDoc.data();
          setAdTitle(adData.adTitle || '');
          setAdImage(adData.adImage || null);
        } else {
          Alert.alert('Error', 'Ad not found.');
          router.back(); 
        }
      } catch (error) {
        console.error('Error fetching ad:', error);
        Alert.alert('Error', 'Could not fetch ad data.');
      } finally {
        setLoading(false);
      }
    };

    fetchAdData();
  }, [adId]);

  const handleImageChange = async () => {
    const permissionResult = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (permissionResult.granted) {
      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        quality: 1,
      });

      if (!result.canceled && result.assets && result.assets.length > 0) {
        const imageUri = result.assets[0].uri;
        setAdImage(imageUri); 
      }
    } else {
      Alert.alert('Permission', 'Permission to access media library is required!');
    }
  };

  const handleSave = async () => {
    if (saving) return;
    setSaving(true);

    try {
      if (!adId) {
        Alert.alert('Error', 'No Ad ID found.');
        return;
      }

      const adDocRef = doc(db, 'ads', adId as string);
      await updateDoc(adDocRef, {
        adTitle,
        adImage,
      });

      Alert.alert('Success', 'Ad updated successfully!');
      router.push('/admin/marketing/manageads');
    } catch (error) {
      console.error('Error updating ad:', error);
      Alert.alert('Error', 'There was an issue updating the ad.');
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async () => {
    Alert.alert(
      'Delete Ad',
      'Are you sure you want to delete this ad?',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Yes',
          onPress: async () => {
            try {
              if (!adId) {
                Alert.alert('Error', 'No Ad ID found.');
                return;
              }

              const adDocRef = doc(db, 'ads', adId as string);
              await deleteDoc(adDocRef);

              Alert.alert('Success', 'Ad deleted successfully!');
              router.push('/admin/marketing/manageads'); 
            } catch (error) {
              console.error('Error deleting ad:', error);
              Alert.alert('Error', 'There was an issue deleting the ad.');
            }
          },
        },
      ],
      { cancelable: true }
    );
  };

  if (loading) {
    return (
      <View style={styles.loaderContainer}>
        <ActivityIndicator size="large" color="#000" />
        <Text>Loading ad data...</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()}>
          <Ionicons name="arrow-back" size={24} color="black" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Edit Ad</Text>
      </View>

      <View style={styles.inputContainer}>
        <Text style={styles.label}>Ad Title</Text>
        <TextInput
          value={adTitle}
          onChangeText={setAdTitle}
          placeholder="Enter Ad Title"
          style={styles.input}
        />
      </View>

      <TouchableOpacity onPress={handleImageChange} style={styles.imageContainer}>
        {adImage ? (
          <Image source={{ uri: adImage }} style={styles.adImage} />
        ) : (
          <Text style={styles.addImageText}>Add Ad Image</Text>
        )}
      </TouchableOpacity>

      <View style={styles.buttonContainer}>
        <TouchableOpacity style={[styles.button, { backgroundColor: '#007BFF' }]} onPress={handleSave}>
          <Text style={styles.buttonText}>{saving ? 'Saving...' : 'Save Changes'}</Text>
        </TouchableOpacity>
        <TouchableOpacity style={[styles.button, { backgroundColor: '#FF0000' }]} onPress={handleDelete}>
          <Text style={styles.buttonText}>Delete</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#fff',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 20,
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    marginLeft: 10,
  },
  inputContainer: {
    marginVertical: 10,
  },
  label: {
    fontSize: 16,
    marginBottom: 8,
  },
  input: {
    borderWidth: 1,
    borderColor: '#ccc',
    padding: 10,
    borderRadius: 5,
    fontSize: 16,
  },
  imageContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 10,
    height: 200,
    width: '100%',
    marginBottom: 20,
  },
  adImage: {
    width: '100%',
    height: '100%',
    borderRadius: 10,
  },
  addImageText: {
    color: '#888',
    fontSize: 16,
  },
  loaderContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  buttonContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 20,
  },
  button: {
    flex: 1,
    marginHorizontal: 5,
    padding: 15,
    borderRadius: 5,
    alignItems: 'center',
  },
  buttonText: {
    color: 'white',
    fontWeight: 'bold',
  },
});

export default EditAds;
