import React, { useEffect, useState } from 'react';
import { StyleSheet, View, Text, TouchableOpacity, ScrollView, Image } from 'react-native';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons'; 
import { getAuth } from 'firebase/auth';
import { collection, getDocs, query, where } from 'firebase/firestore';
import { app, db } from '../../src/firebaseConfig';
import { useLocalSearchParams } from 'expo-router';

interface Listing {
  title: string;
  price: number;
  images: string[];
  status: 'active' | 'sold';
  email: string;
  docId: string;
  feedback?: string;
}

interface Feedback {
  buyerUsername: string;
  description: string;
}

export default function VisitorProfile() {
  const [userEmail, setUserEmail] = useState<string | null>(null);
  const [userInfo, setUserInfo] = useState<any | null>(null);
  const [activeListings, setActiveListings] = useState<Listing[]>([]);
  const [inactiveListings, setInactiveListings] = useState<Listing[]>([]);
  const [buyerFeedbacks, setBuyerFeedbacks] = useState<Feedback[]>([]);
  const [sellerFeedbacks, setSellerFeedbacks] = useState<Feedback[]>([]);  const [loading, setLoading] = useState(true);
  const [loadingFeedback, setLoadingFeedback] = useState(true); // Loading state for feedback  const [error, setError] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'listings' | 'feedback'>('listings');
  const [showInactive, setShowInactive] = useState(false);  
  
  const router = useRouter();
  const { email } = useLocalSearchParams();
  const targetEmail = email;

  useEffect(() => {
    const fetchData = async () => {
      if (targetEmail) {
        try {
          // Fetch visitor's user info
          const userDocQuery = query(collection(db, 'user'), where('email', '==', targetEmail));
          const userDocs = await getDocs(userDocQuery);
          if (!userDocs.empty) {
            setUserInfo(userDocs.docs[0].data());
          } else {
            console.error('Visitor data not found.');
          }

          // Fetch visitor's listings
          const listingsQuery = query(collection(db, 'listing'), where('email', '==', targetEmail));
          const querySnapshot = await getDocs(listingsQuery);
          const active: Listing[] = [];
          const inactive: Listing[] = [];

          querySnapshot.forEach((doc) => {
            const data = doc.data();
            const listing = {
              title: data.title,
              price: data.price,
              images: data.images,
              status: data.status,
              email: data.email,
              docId: doc.id,
              feedback: data.feedback || '', 
            };
            if (data.status === 'active') {
              active.push(listing);
            } else {
              inactive.push(listing);
            }
          });

          setActiveListings(active);
          setInactiveListings(inactive);
        } catch (error) {
          setError('Error fetching visitor data');
        } finally {
          setLoading(false);
        }
      }
    };

    fetchData();
  }, [targetEmail]);

  useEffect(() => {
    const fetchFeedback = async () => {
      if (targetEmail) {
        try {
          // Fetch feedback where the user is the seller (received from buyers)
          const feedbackToSellerQuery = query(
            collection(db, 'feedback'),
            where('sellerEmail', '==', targetEmail)
          );
          const feedbackToSellerSnapshot = await getDocs(feedbackToSellerQuery);
          const feedbackToSellerList: Feedback[] = [];
          feedbackToSellerSnapshot.forEach((doc) => {
            const data = doc.data();
            if (data.authorEmail !== targetEmail) { // Filter out self-feedback
              feedbackToSellerList.push({
                buyerUsername: data.buyerUsername,
                description: data.description,
              });
            }
          });
  
          // Fetch feedback where the user is the buyer (received from sellers)
          const feedbackToBuyerQuery = query(
            collection(db, 'feedback'),
            where('buyerEmail', '==', targetEmail)
          );
          const feedbackToBuyerSnapshot = await getDocs(feedbackToBuyerQuery);
          const feedbackToBuyerList: Feedback[] = [];
          feedbackToBuyerSnapshot.forEach((doc) => {
            const data = doc.data();
            if (data.authorEmail !== targetEmail) { // Filter out self-feedback
              feedbackToBuyerList.push({
                buyerUsername: data.sellerUsername, // Seller who gave feedback
                description: data.description,
              });
            }
          });
  
          setSellerFeedbacks(feedbackToSellerList);
          setBuyerFeedbacks(feedbackToBuyerList);
        } catch (error) {
          console.error('Error fetching feedback:', error);
        } finally {
          setLoadingFeedback(false);
        }
      }
    };
  
    fetchFeedback();
  }, [targetEmail]);  
  
  const renderListing = ({ item }: { item: Listing }) => (
    <TouchableOpacity
      key={item.docId} 
      onPress={() => router.push(`/user/listing/listingdetails?docId=${item.docId}`)}
      style={styles.listingCard}
    >
      <Image source={{ uri: item.images[0] }} style={styles.listingImage} />
      <View style={styles.listingInfo}>
        <Text style={styles.listingTitle}>{item.title}</Text>
        <Text style={styles.listingPrice}>RM {item.price}</Text>
        {item.feedback && <Text style={styles.listingFeedback}>Feedback: {item.feedback}</Text>}
      </View>
    </TouchableOpacity>
  );  

  return (
    <ScrollView style={styles.scrollView}>
      <View style={styles.container}>
        <View style={styles.headerContainer}>
          <TouchableOpacity onPress={() => router.back()}>
            <Ionicons name="arrow-back-outline" size={30} color="black" />
          </TouchableOpacity>
        </View>

        {loading ? (
          <Text>Loading...</Text>
        ) : error ? (
          <Text>{error}</Text>
        ) : userInfo ? (
          <>
            <View style={styles.userInfo}>
              <View style={styles.profilePictureContainer}>
                <Image
                  source={{ uri: userInfo.profilePicture || 'default-image-url' }}
                  style={styles.profilePicture}
                />
              </View>
              <View>
                <Text style={styles.name}>{userInfo.name}</Text>
                <Text style={styles.username}>@{userInfo.username}</Text>
              </View>
            </View>

            <View style={styles.tabs}>
              <TouchableOpacity
                style={[styles.tab, activeTab === 'listings' && styles.activeTab]}
                onPress={() => setActiveTab('listings')}
              >
                <Text style={styles.tabText}>Listings</Text> 
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.tab, activeTab === 'feedback' && styles.activeTab]}
                onPress={() => setActiveTab('feedback')}
              >
                <Text style={styles.tabText}>Feedback</Text>
              </TouchableOpacity>
            </View>



            <View style={styles.listingContainer}>
              {activeTab === 'listings' && (
                <>
                  <Text style={styles.sectionTitle}>Active Listings</Text>
                  {activeListings.length === 0 ? (
                    <Text>No active listings available.</Text>
                  ) : (
                    <ScrollView contentContainerStyle={styles.listingRow}>
                      {activeListings.map((item) => renderListing({ item }))}
                    </ScrollView>
                  )}

                  <TouchableOpacity
                    style={styles.toggleButton}
                    onPress={() => setShowInactive(!showInactive)}
                  >
                    <Ionicons
                      name={showInactive ? "chevron-up" : "chevron-down"}
                      size={20}
                      color="black"
                    />
                    <Text style={styles.toggleButtonText}>Inactive Listings</Text>
                  </TouchableOpacity>

                  {showInactive && (
                    <>
                      {inactiveListings.length === 0 ? (
                        <Text>No inactive listings available.</Text>
                      ) : (
                        <ScrollView contentContainerStyle={styles.listingRow}>
                          {inactiveListings.map((item) => renderListing({ item }))}
                        </ScrollView>
                      )}
                    </>
                  )}
                </>
              )}

              {activeTab === 'feedback' && (
                <View style={styles.feedbackContainer}>
                  <Text style={styles.sectionTitle}>From Buyers</Text>
                  {sellerFeedbacks.length === 0 ? (
                    <Text>No feedback received yet.</Text>
                  ) : (
                    sellerFeedbacks.map((feedback, index) => (
                      <View key={index} style={styles.feedbackCard}>
                        <Text style={styles.feedbackUsername}>@{feedback.buyerUsername}</Text>
                        <Text style={styles.feedbackDescription}>{feedback.description}</Text>
                      </View>
                    ))
                  )}

                  <Text style={styles.sectionTitle}>From Sellers</Text>
                  {buyerFeedbacks.length === 0 ? (
                    <Text>No feedback received yet.</Text>
                  ) : (
                    buyerFeedbacks.map((feedback, index) => (
                      <View key={index} style={styles.feedbackCard}>
                        <Text style={styles.feedbackUsername}>@{feedback.buyerUsername}</Text>
                        <Text style={styles.feedbackDescription}>{feedback.description}</Text>
                      </View>
                    ))
                  )}
                </View>
              )}

            </View>
          </>
        ) : (
          <Text>No visitor data available.</Text>
        )}
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#fff',
  },
  headerContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 20,
  },
  header: {
    fontSize: 24,
    fontWeight: 'bold',
    flex: 1,
    textAlign: 'center',
  },
  userInfo: {
    marginBottom: 20,
    flexDirection: 'row',
    alignItems: 'center',
  },
  profilePictureContainer: {
    marginRight: 10,
  },
  profilePicture: {
    width: 80,
    height: 80,
    borderRadius: 40,
  },
  name: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  username: {
    fontSize: 16,
    color: '#555',
  },
  tabs: {
    flexDirection: 'row',
    marginBottom: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#ddd',
  },
  tab: {
    flex: 1,
    paddingVertical: 10,
    alignItems: 'center',
  },
  activeTab: {
    borderBottomWidth: 3,
    borderBottomColor: '#007AFF',
  },
  tabText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#000', 
  },
  
  activeTabText: {
    borderBottomWidth: 3,
    borderBottomColor: '#007AFF', 
  },
  
  listingContainer: {
    marginBottom: 20,
  },
  sectionTitle: {
    fontSize: 15,
    fontWeight: 'bold',
    marginBottom: 10,
    marginTop: 10,

  },
  listingRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  listingCard: {
    width: '48%',
    marginBottom: 10,
    backgroundColor: '#fff',
    borderRadius: 8,
    overflow: 'hidden',
    elevation: 3,
  },
  listingImage: {
    width: '100%',
    height: 150,
    resizeMode: 'cover',
  },
  listingInfo: {
    padding: 10,
  },
  listingTitle: {
    fontSize: 16,
    fontWeight: 'bold',
  },
  listingPrice: {
    fontSize: 14,
    color: '#888',
  },
  listingFeedback: {
    fontSize: 12,
    color: '#555',
    marginTop: 5,
  },
  toggleButton: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
  },
  toggleButtonText: {
    fontSize: 16,
    marginLeft: 10,
    color: '#007AFF',
  },
  feedbackContainer: {
    padding: 10,
    backgroundColor: '#fff',
    borderRadius: 8,
    elevation: 3,
  },
  feedbackCard: {
    marginBottom: 10,
    padding: 10,
    backgroundColor: '#f9f9f9',
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#ddd',
  },
  feedbackUsername: {
    fontSize: 14,
    fontWeight: 'bold',
    marginBottom: 5,
  },
  feedbackDescription: {
    fontSize: 14,
    color: '#555',
  },
  scrollView: {
    backgroundColor: '#fff', 
  },
  
});
