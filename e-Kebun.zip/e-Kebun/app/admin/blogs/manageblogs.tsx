import React, { useState, useEffect } from 'react';
import { View, Text, FlatList, TextInput, TouchableOpacity, StyleSheet } from 'react-native';
import { db } from '../../src/firebaseConfig';
import { collection, getDocs } from 'firebase/firestore';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';

interface BlogData {
  id: string; 
  title: string;
}

const ManageBlogs = () => {
  const router = useRouter();
  const [blogs, setBlogs] = useState<BlogData[]>([]);
  const [searchText, setSearchText] = useState('');

  useEffect(() => {
    const fetchBlogs = async () => {
      try {
        const blogCollection = collection(db, 'blogs'); 
        const blogSnapshot = await getDocs(blogCollection);
        const fetchedBlogs = blogSnapshot.docs.map((doc) => ({
          id: doc.id,
          title: doc.data().title || '', 
        }));
        setBlogs(fetchedBlogs);
      } catch (error) {
        console.error('Error fetching blogs:', error);
      }
    };

    fetchBlogs();
  }, []);

  const filteredBlogs = blogs.filter((blog) =>
    blog.title.toLowerCase().includes(searchText.toLowerCase())
  );

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.push('/admin/dashboard')}>
          <Ionicons name="arrow-back" size={24} color="black" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Manage Blogs</Text>
      </View>

      <View style={styles.searchContainer}>
        <TextInput
          style={styles.searchInput}
          placeholder="Search by title..."
          value={searchText}
          onChangeText={setSearchText}
        />
        <TouchableOpacity
          onPress={() => router.push('/admin/blogs/addnewblog')} 
          style={styles.addButton}
        >
          <Ionicons name="add" size={24} color="black" />
        </TouchableOpacity>
      </View>

      <FlatList
        data={filteredBlogs}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <TouchableOpacity
            onPress={() => router.push(`/admin/blogs/editblogs?blogId=${item.id}`)} 
            style={styles.blogItem}
          >
            <Text style={styles.blogId}>ID: {item.id}</Text> 
            <Text style={styles.blogTitle}>{item.title}</Text> 
          </TouchableOpacity>
        )}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#fff',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 20,
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    marginLeft: 10,
  },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginVertical: 10,
  },
  searchInput: {
    flex: 1,
    height: 40,
    borderColor: '#ccc',
    borderWidth: 1,
    paddingLeft: 8,
  },
  addButton: {
    marginLeft: 10, // Space between search input and + icon
    padding: 8,
  },
  blogItem: {
    padding: 15,
    backgroundColor: '#f9f9f9',
    marginVertical: 5,
    borderRadius: 5,
  },
  blogId: {
    fontSize: 14,
    color: '#888', // Display document ID in a smaller, lighter color
  },
  blogTitle: {
    fontSize: 18,
    fontWeight: 'bold',
  },
});

export default ManageBlogs;
