import React, { useEffect, useState } from 'react';
import { View, Text, TextInput, Button, Image, TouchableOpacity, StyleSheet, Alert, ScrollView } from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import { db } from '../../src/firebaseConfig';
import { doc, getDoc, updateDoc } from 'firebase/firestore';
import { useRouter, useLocalSearchParams } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';

const EditListing = () => {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [price, setPrice] = useState('');
  const [images, setImages] = useState<string[]>([]);
  const [loading, setLoading] = useState(false);
  const router = useRouter();
  const { docId } = useLocalSearchParams(); 

  useEffect(() => {
    const fetchListing = async () => {
      if (!docId) {
        Alert.alert('Error', 'No listing ID provided.');
        router.back();
        return;
      }

      try {
        const docRef = doc(db, 'listing', docId as string);
        const listing = await getDoc(docRef);

        if (listing.exists()) {
          const data = listing.data();
          setTitle(data.title || '');
          setDescription(data.description || '');
          setPrice(data.price ? data.price.toString() : '');
          setImages(data.images || []);
        } else {
          Alert.alert('Error', 'Listing not found.');
          router.back();
        }
      } catch (error) {
        console.error('Error fetching listing:', error);
        Alert.alert('Error', 'Failed to fetch the listing.');
        router.back();
      }
    };

    fetchListing();
  }, [docId]);

  const handleImagePick = async () => {
    let result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: true,
      aspect: [4, 3],
      quality: 1,
    });

    if (!result.canceled && result.assets && result.assets.length > 0) {
      const pickedImageUri = result.assets[0].uri;
      setImages([...images, pickedImageUri]);
    }
  };

  const handleImageDelete = (index: number) => {
    const updatedImages = [...images];
    updatedImages.splice(index, 1);
    setImages(updatedImages);
  };

  const handleSubmit = async () => {
    if (!title || !description || !price || images.length === 0) {
      Alert.alert('Error', 'Please fill in all fields and upload at least one image.');
      return;
    }

    setLoading(true);

    try {
      const docRef = doc(db, 'listing', docId as string);

      await updateDoc(docRef, {
        title,
        description,
        price: parseFloat(price),
        images,
        updatedAt: new Date(),
      });

      Alert.alert('Success', 'Listing updated successfully!', [
        {
          text: 'OK',
          onPress: () => {
            router.push('/user/(tabs)/account');
          },
        },
      ]);
    } catch (error) {
      console.error('Error updating listing:', error);
      Alert.alert('Error', 'Failed to update the listing. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()}>
          <Ionicons name="arrow-back" size={24} color="black" />
        </TouchableOpacity>
        <Text style={styles.title}>Edit Listing</Text>
      </View>

      <Text style={styles.imageText}>Title</Text>
      <TextInput
        style={styles.input}
        placeholder="Title"
        value={title}
        onChangeText={setTitle}
      />

      <Text style={styles.imageText}>Description</Text>
      <TextInput
        style={[styles.input, { height: 100 }]}
        placeholder="Description"
        value={description}
        onChangeText={setDescription}
        multiline
      />

      <View style={styles.row}>
        <Text style={styles.label}>RM</Text>
        <TextInput
          style={styles.inputInline}
          placeholder="Price"
          keyboardType="numeric"
          value={price}
          onChangeText={setPrice}
        />
      </View>

      <View style={styles.imageContainer}>
        <Text style={styles.imageText}>Images</Text>
        <TouchableOpacity onPress={handleImagePick} style={styles.button}>
          <Text style={styles.buttonText}>Pick Images</Text>
        </TouchableOpacity>

        <ScrollView horizontal showsHorizontalScrollIndicator={false}>
          {images.map((image, index) => (
            <View key={index} style={styles.imageWrapper}>
              <Image source={{ uri: image }} style={styles.imageThumbnail} />
              <TouchableOpacity
                style={styles.deleteButton}
                onPress={() => handleImageDelete(index)}
              >
                <Ionicons name="close" size={20} color="white" />
              </TouchableOpacity>
            </View>
          ))}
        </ScrollView>
      </View>

      <TouchableOpacity
        onPress={handleSubmit}
        style={[styles.button, loading && { backgroundColor: '#ccc' }]}
        disabled={loading}
      >
        <Text style={styles.buttonText}>
          {loading ? 'Saving...' : 'Update Listing'}
        </Text>
      </TouchableOpacity>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    padding: 20,
    backgroundColor: '#fff',
    
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginLeft: 10,
  },
  input: {
    height: 45,
    borderColor: '#ddd',
    borderWidth: 1,
    marginBottom: 15,
    paddingLeft: 10,
    borderRadius: 5,
    backgroundColor: '#f9f9f9',
  },
  imageContainer: {
    marginBottom: 20,
    paddingVertical: 10,
  },
  imageText: {
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  imageWrapper: {
    position: 'relative',
  },
  imageThumbnail: {
    width: 100,
    height: 100,
    marginRight: 10,
    borderRadius: 5,
  },
  deleteButton: {
    position: 'absolute',
    top: 5,
    right: 5,
    borderRadius: 15,
    padding: 5,
  },
  button: {
    backgroundColor: '#007BFF',
    padding: 10,
    marginBottom: 10,
    borderRadius: 5,
    alignItems: 'center',
  },
  buttonText: {
    color: 'white',
    fontSize: 16,
  },
  row: {
    flexDirection: 'row',
    alignItems: 'center', // Align text and input vertically
    marginBottom: 15,
  },
  label: {
    fontSize: 16,
    marginRight: 10, // Adds spacing between the label and the input
    color: '#333',
    fontWeight: 'bold',
  },
  inputInline: {
    flex: 1, // Ensures the input takes up the remaining space
    height: 45,
    borderColor: '#ddd',
    borderWidth: 1,
    borderRadius: 5,
    paddingHorizontal: 10,
    backgroundColor: '#f9f9f9',
  },
});

export default EditListing;
