import React, { useState, useEffect } from 'react';
import { View, Text, FlatList, TextInput, TouchableOpacity, StyleSheet, Image, Dimensions } from 'react-native';
import { db } from '../../src/firebaseConfig';
import { collection, getDocs, query, where } from 'firebase/firestore';
import { useRouter, useLocalSearchParams } from 'expo-router';
import Icon from 'react-native-vector-icons/Ionicons'; 

interface PlotAreaData {
  id: string;
  name: string;
  description: string;
  images: string | string[];
}


const Plot = () => {
  const { filterParams, filteredPlots } = useLocalSearchParams();
  const router = useRouter();
  const [plotAreas, setPlotAreas] = useState<PlotAreaData[]>([]);
  const [searchText, setSearchText] = useState('');

  useEffect(() => {
    if (filteredPlots) {
      const parsedFilteredPlots = JSON.parse(filteredPlots as string);
      console.log('Filtered plots passed from LocationFilter:', parsedFilteredPlots);
  
      // Ensure that docId is assigned to id
      const plotWithIds = parsedFilteredPlots.map((plot: any) => ({
        ...plot,
        id: plot.docId,  // Map docId to id
      }));
  
      setPlotAreas(plotWithIds);  // Update state with corrected plot areas
    } else {
      fetchPlotAreas(); // If no filtered plots, fetch them from Firestore
    }
  }, [filteredPlots]);
  
  // Fetch all plot areas when no filtered plots are passed
  const fetchPlotAreas = async () => {
    try {
      let plotAreaQuery = query(collection(db, 'plotarea'));

      // Dynamically add query conditions based on selected filters from filterParams
      if (filterParams) {
        const filters = JSON.parse(filterParams as string);
        if (filters.state) {
          plotAreaQuery = query(plotAreaQuery, where('location.state', '==', filters.state));
        }
        if (filters.city) {
          plotAreaQuery = query(plotAreaQuery, where('location.city', '==', filters.city));
        }
        if (filters.postcode) {
          plotAreaQuery = query(plotAreaQuery, where('location.postcode', '==', filters.postcode));
        }
        if (filters.section) {
          plotAreaQuery = query(plotAreaQuery, where('location.section', '==', filters.section));
        }
      }

      const plotAreaSnapshot = await getDocs(plotAreaQuery);

      if (plotAreaSnapshot.empty) {
        console.log('No plot areas found for the given filter.');
        setPlotAreas([]); 
        return;
      }

      const fetchedPlotAreas = plotAreaSnapshot.docs.map((doc) => {
        const data = doc.data();
        return {
          id: doc.id,
          name: data.name,
          description: data.description || '',
          images: Array.isArray(data.images) ? data.images[0] : data.images || '',
        };
      });

      console.log('Fetched Plot Areas:', fetchedPlotAreas);
      setPlotAreas(fetchedPlotAreas);
    } catch (error) {
      console.error('Error fetching plot areas:', error);
    }
  };


  
  // Apply search functionality on fetched plot areas
  const filteredPlotAreas = plotAreas.filter((plotArea) =>
    plotArea.name?.toLowerCase().includes(searchText.toLowerCase()) ||
    plotArea.description?.toLowerCase().includes(searchText.toLowerCase())
  );

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.pageTitle}>Plots</Text>
        <TouchableOpacity
          style={styles.cartIcon}
          onPress={() => router.push('/user/plot/plotcart')}
        >
          <Icon name="cart-outline" size={28} color="#333" /> 
        </TouchableOpacity>
      </View>

      <View style={styles.searchBar}>
        <TextInput
          style={styles.searchInput}
          placeholder="Search plots..."
          value={searchText}
          onChangeText={setSearchText}
        />
        <TouchableOpacity
          style={styles.filterIcon}
          onPress={() => router.push('/user/(tabs)/(nontabs)/plocationfilter')}
        >
          <Icon name="filter-outline" size={28} color="#333" /> 
        </TouchableOpacity>
      </View>

      <FlatList
        data={filteredPlotAreas}
        keyExtractor={(item) => item.id }
        numColumns={2} 
        contentContainerStyle={styles.gridContainer}
        renderItem={({ item }) => (
          <TouchableOpacity
            style={styles.panel}
            onPress={() => {
              console.log(`Navigating to plot details with id: ${item.id}`);  // Add a console log to check the id
              router.push(`/user/plot/plotdetails?id=${item.id}`);
            }}
          >
            <Image
              source={{
                uri: Array.isArray(item.images) 
                  ? item.images[0] // Use the first image in the array
                  : item.images || 'https://via.placeholder.com/150',  // Fallback to placeholder
              }}
              style={styles.panelImages}
            />

            <Text style={styles.panelName} numberOfLines={2}>
              {item.name}
            </Text>
          </TouchableOpacity>
        )}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#f9f9f9',
  },
  pageTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    textAlign: 'left', 
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between', 
    alignItems: 'center',
    marginBottom: 15,
  },
  cartIcon: {
    padding: 10,
  },
  searchBar: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 15,
  },
  searchInput: {
    flex: 1,
    height: 40,
    borderColor: '#ccc',
    borderWidth: 1,
    borderRadius: 5,
    paddingHorizontal: 10,
  },
  filterIcon: {
    padding: 10,
    marginLeft: 10,
  },
  gridContainer: {
    paddingBottom: 20,
  },
  panel: {
    flex: 1,
    margin: 5,
    backgroundColor: '#f9f9f9',
    borderRadius: 8,
    overflow: 'hidden',
    maxWidth: (Dimensions.get('window').width - 30) / 2, 
  },
  panelImages: {
    width: '100%',
    height: 120,
    backgroundColor: '#ddd',
  },
  panelName: {
    padding: 10,
    fontSize: 16,
    fontWeight: '600',
    color: '#333',
  },
});

export default Plot;
