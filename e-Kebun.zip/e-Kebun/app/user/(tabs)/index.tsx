import React, { useEffect, useState, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  Image,
  Dimensions,
  TouchableOpacity,
  ScrollView,
} from 'react-native';
import { collection, getDocs } from 'firebase/firestore';
import { db } from '../../src/firebaseConfig';
import { useRouter } from 'expo-router';
import Ionicons from '@expo/vector-icons/Ionicons';
import { Linking } from 'react-native';

type PlotAreaData = {
  id: string;
  name: string;
  description: string;
  images: string[]; 
};

type Listing = {
  title: string;
  price: number;
  images: string[];
  status: 'active';
  docId: string;
  location: {
    state: string;
    city: string;
    postcode: string;
    section?: string;
  };
};

type Ad = {
  id: string;
  adImage: string;
  [key: string]: any;
};

const Home = () => {
  const [plotAreas, setPlotAreas] = useState<PlotAreaData[]>([]);
  const [listings, setListings] = useState<Listing[]>([]);
  const [ads, setAds] = useState<Ad[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const flatListRef = useRef<FlatList>(null);
  const router = useRouter();
  const screenWidth = Dimensions.get('window').width;

  useEffect(() => {
    const fetchPlotAreas = async () => {
      try {
        const querySnapshot = await getDocs(collection(db, 'plotarea'));
        const plotAreaData = querySnapshot.docs.map((doc) => ({
          id: doc.id,
          ...doc.data(),
        })) as PlotAreaData[];
        setPlotAreas(plotAreaData);
      } catch (error) {
        console.error('Error fetching plot areas:', error);
      }
    };

    const fetchListings = async () => {
      try {
        const querySnapshot = await getDocs(collection(db, 'listing'));
        const listingData = querySnapshot.docs
          .map((doc) => {
            const data = doc.data();
            return {
              docId: doc.id,
              title: data.title || '', 
              price: data.price || 0, 
              images: data.images || [], 
              status: data.status || 'sold', 
              location: data.location || { state: '', city: '', postcode: '', section: '' }, 
            };
          })
          .filter((listing) => listing.status === 'active'); 
        setListings(listingData);
      } catch (error) {
        console.error('Error fetching listings:', error);
      }
    };
    
    

    const fetchAds = async () => {
      try {
        const querySnapshot = await getDocs(collection(db, 'ads'));
        const adsData = querySnapshot.docs.map((doc) => ({
          id: doc.id,
          adImage: doc.data().adImage,
        })) as Ad[];
        setAds([...adsData, ...adsData]);
      } catch (error) {
        console.error('Error fetching ads:', error);
      }
    };

    fetchPlotAreas();
    fetchListings();
    fetchAds();
  }, []);

  useEffect(() => {
    const timer = setInterval(() => {
      if (ads.length > 0) {
        setCurrentIndex((prevIndex) => (prevIndex + 1) % ads.length);
      }
    }, 3000);

    return () => clearInterval(timer);
  }, [ads]);

  useEffect(() => {
    if (flatListRef.current && ads.length > 0) {
      flatListRef.current.scrollToIndex({
        index: currentIndex,
        animated: true,
      });
    }
  }, [currentIndex, ads]);

  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => Linking.openURL('https://wa.me/60127582208')}>
          <Ionicons name="chatbubbles-outline" size={30} color="white" />
        </TouchableOpacity>
      </View>

      {ads.length > 0 ? (
        <FlatList
          ref={flatListRef}
          data={ads}
          keyExtractor={(item, index) => `${item.id}-${index}`}
          horizontal
          pagingEnabled
          showsHorizontalScrollIndicator={false}
          renderItem={({ item }) => (
            <View style={[styles.adContainer, { width: screenWidth }]}>
              <Image source={{ uri: item.adImage }} style={styles.adImage} />
            </View>
          )}
        />
      ) : (
        <Text>Loading ads...</Text>
      )}

      <View style={styles.rectangleBoxContainer}>
        <TouchableOpacity
          style={styles.rectangleBox}
          onPress={() => router.push('/user/form/blog')}
        >
          <Ionicons name="book" size={30} color="blue" style={styles.rectangleIcon} />
          <View style={styles.textContainer}>
            <Text style={styles.rectangleHeader}>How Can I Start?</Text>
            <Text style={styles.rectangleSubtitle}>
              Explore tips and resources for your vegetable garden journey
            </Text>
          </View>
        </TouchableOpacity>
      </View>
      

      <View style={styles.plotsHeaderContainer}>
        <Text style={styles.plotsHeader}>Plots Near You</Text>
        <TouchableOpacity onPress={() => router.push('/user/(tabs)/plot')}>
          <Text style={styles.seeMore}>See More</Text>
        </TouchableOpacity>
      </View>

      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={styles.scrollContainer}
      >
        {plotAreas.map((item) => (
          <TouchableOpacity
            key={item.id}
            style={styles.panel}
            onPress={() => router.push(`/user/plot/plotdetails?id=${item.id}`)}
          >
            <Image
              source={{
                uri: item.images?.[0] || 'https://via.placeholder.com/150',
              }}
              style={styles.panelImages}
            />
            <Text style={styles.panelName} numberOfLines={2}>
              {item.name}
            </Text>
          </TouchableOpacity>
        ))}
      </ScrollView>

      <View style={styles.rectangleBoxContainer}>
        <TouchableOpacity
          style={styles.rectangleBox}
          onPress={() => router.push('/user/form/reportarea')}
        >
          <Ionicons name="location" size={30} color="red" style={styles.rectangleIcon} />
          <View style={styles.textContainer}>
            <Text style={styles.rectangleHeader}>Found a Potential Area?</Text>
            <Text style={styles.rectangleSubtitle}>
              Let us turn it into a fruitful space
            </Text>
          </View>
        </TouchableOpacity>
      </View>

      <View style={styles.plotsHeaderContainer}>
        <Text style={styles.plotsHeader}>Listings Near You</Text>
        <TouchableOpacity onPress={() => router.push('/user/(tabs)/market')}>
          <Text style={styles.seeMore}>See More</Text>
        </TouchableOpacity>
      </View>

      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={styles.scrollContainer}
      >
        {listings.map((item) => (
          <TouchableOpacity
            key={item.docId}
            style={styles.panel}
            onPress={() => router.push(`/user/listing/listingdetails?docId=${item.docId}`)}
            >
            <Image
              source={{
                uri: item.images?.[0] || 'https://via.placeholder.com/150',
              }}
              style={styles.panelImages}
            />
            <Text style={styles.panelName} numberOfLines={2}>
              {item.title}
            </Text>
            <Text style={styles.panelPrice}>RM {item.price}</Text>
          </TouchableOpacity>
        ))}
      </ScrollView>

      <View style={styles.rectangleBoxContainer}>
        <TouchableOpacity
          style={styles.rectangleBox}
          onPress={() => router.push('/user/form/feedback')}
        >
          <Ionicons name="paper-plane-outline" size={30} color="orange" style={styles.rectangleIcon} />
          <View style={styles.textContainer}>
            <Text style={styles.rectangleHeader}>Help Us Improve</Text>
            <Text style={styles.rectangleSubtitle}>
              Your feedback shapes the future of us
            </Text>
          </View>
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
};


const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f9f9f9',
  },
  header: {
    
    position: 'absolute',
    top: 20,
    width: '100%',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    zIndex: 10,
  },
  scrollContainer: {
    paddingVertical: 10,
    height: 190, 
  },
  adContainer: {
    alignItems: 'center',
  },
  adImage: {
    width: '100%',
    height: 300,
    resizeMode: 'cover',
  },
  noAdsText: {
    fontSize: 16,
    color: 'gray',
    textAlign: 'center',
    marginTop: 50,
  },
  panel: {
    marginRight: 15,
    marginLeft: 15,
    backgroundColor: '#f9f9f9',
    borderRadius: 8,
    overflow: 'hidden',
    width: (Dimensions.get('window').width - 30) / 2,
    
  },
  panelImages: {
    width: '90%',
    height: 120,
    backgroundColor: '#ddd',
    borderRadius: 8,
  },
  panelName: {
    fontSize: 14,
    marginTop: 10,
    marginLeft: 15,
    color: 'black',
  },
  panelPrice: {
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 5,
    marginLeft: 15,
  },
  plotsHeaderContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 10,
    paddingHorizontal: 20,
    marginTop: 20,
  },
  plotsHeader: {
    fontSize: 20,
    fontWeight: '600',
    color: '#333',
  },
  seeMore: {
    marginTop: 5,
    fontSize: 14,
    fontWeight: '400',
    color: '#007BFF',
    fontStyle: 'italic',
   },
   rectangleBoxContainer: {
    marginTop: 20,
    marginHorizontal: 20,
  },

  rectangleBox: {
    flexDirection: 'row',
    backgroundColor: 'white',
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#ddd',
    padding: 15,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
    width: '100%',
    marginBottom: 20,
  },

  rectangleIcon: {
    marginTop: 10,
    marginRight: 20,
    marginLeft: 10,
    marginBottom: 10,
  },

  textContainer: {
    flex: 1,
    justifyContent: 'center',
  },

  rectangleHeader: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
  },

  rectangleSubtitle: {
    fontSize: 14,
    color: '#666',
    marginTop: 0,
  },
});

export default Home;
