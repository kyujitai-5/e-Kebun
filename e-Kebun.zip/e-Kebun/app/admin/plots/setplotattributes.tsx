import React, { useState, useEffect } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet } from 'react-native';
import { db } from '../../src/firebaseConfig';
import { collection, addDoc, deleteDoc, doc, updateDoc, getDocs, getDoc } from 'firebase/firestore';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons'; 
import { ScrollView } from 'react-native';

interface PlotTypeData {
  id: string;
  type: string;
}

interface PlotPPData {
  id: string;
  period: number;
  price: number;
  isNew?: boolean; 
  isDeleted?: boolean; 
}

const UpdatePlotAttributes = () => {
  const router = useRouter();
  const [plotTypes, setPlotTypes] = useState<PlotTypeData[]>([]);
  const [plotPP, setPlotPP] = useState<PlotPPData[]>([]);
  const [newType, setNewType] = useState('');
  const [editingType, setEditingType] = useState<string | null>(null); // Track the type being edited
  const [editedTypeName, setEditedTypeName] = useState<string>(''); // Store the edited type name

  const fetchPlotData = async () => {
    try {
      const typeSnapshot = await getDocs(collection(db, 'plotsettype'));
      const fetchedTypes: PlotTypeData[] = typeSnapshot.docs.map((doc) => ({
        id: doc.id,
        type: doc.data().type,
      }));
      setPlotTypes(fetchedTypes);

      const ppSnapshot = await getDocs(collection(db, 'plotsetpp'));
      const fetchedPP: PlotPPData[] = ppSnapshot.docs.map((doc) => ({
        id: doc.id,
        period: doc.data().period,
        price: doc.data().price,
      }));
      setPlotPP(fetchedPP);
    } catch (error) {
      console.error("Error fetching plot data:", error);
    }
  };

  useEffect(() => {
    fetchPlotData();
  }, []);

  const handleTypeAdd = async () => {
    if (newType.trim()) {
      await addDoc(collection(db, 'plotsettype'), { type: newType });
      fetchPlotData();
      setNewType('');
    }
  };
  const handleTypeDelete = async (id: string) => {
    try {
      // Step 1: Get the type name to use for comparison across collections
      const typeDoc = await getDoc(doc(db, 'plotsettype', id));
      if (!typeDoc.exists()) {
        console.error('Type not found');
        return;
      }
      const typeName = typeDoc.data()?.type;
  
      // Step 2: Remove the type from `plotQuantities` in `plotarea` collection
      const plotAreaSnapshot = await getDocs(collection(db, 'plotarea'));
      for (const plotAreaDoc of plotAreaSnapshot.docs) {
        const plotAreaData = plotAreaDoc.data();
        if (plotAreaData.plotQuantities && plotAreaData.plotQuantities[typeName]) {
          const updatedPlotQuantities = { ...plotAreaData.plotQuantities };
          delete updatedPlotQuantities[typeName]; // Remove the deleted type
  
          const plotAreaRef = doc(db, 'plotarea', plotAreaDoc.id);
          await updateDoc(plotAreaRef, {
            plotQuantities: updatedPlotQuantities,
          });
        }
      }
  
      // Step 3: Move plots with the deleted type to `deletedplots` and remove from `plots`
      const plotSnapshot = await getDocs(collection(db, 'plots'));
      for (const plotDoc of plotSnapshot.docs) {
        const plotData = plotDoc.data();
        if (plotData.type === typeName) {
          await addDoc(collection(db, 'deletedplots'), plotData);
  
          // Delete the plot from `plots`
          await deleteDoc(doc(db, 'plots', plotDoc.id));
        }
      }
  
      // Step 4: Delete the type from `plotsettype` collection
      await deleteDoc(doc(db, 'plotsettype', id));
  
      // Step 5: Update the UI state to reflect the deleted type
      setPlotTypes((prevTypes) => prevTypes.filter((type) => type.id !== id));
  
      console.log(`Successfully deleted type ${id} and removed all references.`);
    } catch (error) {
      console.error("Error deleting type and associated plots:", error);
    }
  };  
  
  const handleEditTypeName = (id: string, typeName: string) => {
    setEditingType(id); // Set the type being edited
    setEditedTypeName(typeName); // Pre-populate the TextInput with the current type name
  };

  const handleSaveEditedType = async (id: string) => {
    if (editedTypeName.trim()) {
      try {
        // Step 1: Fetch the old type name from plotsettype
        const typeDoc = await getDoc(doc(db, 'plotsettype', id));
        if (!typeDoc.exists()) {
          console.error('Type not found');
          return;
        }
        const oldTypeName = typeDoc.data().type;
  
        // Step 2: Update the plotsettype collection with the new name
        const typeRef = doc(db, 'plotsettype', id);
        await updateDoc(typeRef, { type: editedTypeName });
  
        // Step 3: Update the plotQuantities in the plotarea collection
        const plotAreaSnapshot = await getDocs(collection(db, 'plotarea'));
        for (const plotAreaDoc of plotAreaSnapshot.docs) {
          const plotAreaData = plotAreaDoc.data();
  
          if (plotAreaData.plotQuantities && plotAreaData.plotQuantities[oldTypeName]) {
            // Update the key's value to the new type name
            const updatedQuantities = { ...plotAreaData.plotQuantities };
            updatedQuantities[editedTypeName] = updatedQuantities[oldTypeName];
            delete updatedQuantities[oldTypeName];
  
            const plotAreaRef = doc(db, 'plotarea', plotAreaDoc.id);
            await updateDoc(plotAreaRef, { plotQuantities: updatedQuantities });
          }
        }
  
        // Step 4: Update the type in the plots collection
        const plotSnapshot = await getDocs(collection(db, 'plots'));
        for (const plotDoc of plotSnapshot.docs) {
          const plotData = plotDoc.data();
  
          if (plotData.type === oldTypeName) {
            const plotRef = doc(db, 'plots', plotDoc.id);
            await updateDoc(plotRef, { type: editedTypeName });
          }
        }
  
        // Step 5: Update local state for the UI
        setPlotTypes((prev) =>
          prev.map((type) =>
            type.id === id ? { ...type, type: editedTypeName } : type
          )
        );
  
        // Exit editing mode
        setEditingType(null);
        setEditedTypeName('');
  
        console.log(`Successfully updated type name from ${oldTypeName} to ${editedTypeName}.`);
      } catch (error) {
        console.error('Error updating type name:', error);
      }
    }
  };
  
  

  const handleEditField = (id: string, field: keyof PlotPPData, value: any) => {
    setPlotPP((prevData) =>
      prevData.map((item) => (item.id === id ? { ...item, [field]: value } : item))
    );
  };

  // Add a new row for period and price with empty fields
  const handleAddRow = () => {
    setPlotPP((prevData) => [
      ...prevData,
      { id: Math.random().toString(), period: 0, price: 0, isNew: true }, // Temporary ID
    ]);
  };

  const handleDeleteRow = (id: string) => {
    setPlotPP((prevData) =>
      prevData.map((item) => (item.id === id ? { ...item, isDeleted: true } : item))
    );
  };

  const handleSave = async () => {
    for (const item of plotPP) {
      if (item.isNew && !item.isDeleted) {
        await addDoc(collection(db, 'plotsetpp'), { period: item.period, price: item.price });
      } else if (item.isDeleted) {
        await deleteDoc(doc(db, 'plotsetpp', item.id));
      } else {
        const docRef = doc(db, 'plotsetpp', item.id);
        await updateDoc(docRef, { period: item.period, price: item.price });
      }
    }
    fetchPlotData();
    router.push('/admin/plots/plotattributes');
  };
  return (
    <ScrollView style={styles.container}> 
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.push('/admin/plots/plotattributes')}>
          <Ionicons name="arrow-back" size={24} color="black" />
        </TouchableOpacity>
        <Text style={styles.title}>Update Plot Attributes</Text>
      </View>

      <View style={styles.section}>
        <Text style={styles.subtitle}>Type</Text>
        <View style={styles.typeContainer}>
          {plotTypes.map((type) => (
            <View key={type.id} style={styles.typeBox}>
              <TouchableOpacity onPress={() => handleEditTypeName(type.id, type.type)}>
                {editingType === type.id ? (
                  <TextInput
                    style={styles.typeInput}
                    value={editedTypeName}
                    onChangeText={setEditedTypeName}
                    onBlur={() => handleSaveEditedType(type.id)}
                  />
                ) : (
                  <Text>{type.type}</Text>
                )}
              </TouchableOpacity>
              <TouchableOpacity onPress={() => handleTypeDelete(type.id)}>
                <Text style={styles.deleteIcon}> x</Text>
              </TouchableOpacity>
            </View>
          ))}
          <View style={styles.addTypeContainer}>
            <TextInput
              style={styles.typeInput}
              placeholder="Add new type"
              value={newType}
              onChangeText={setNewType}
            />
            <TouchableOpacity onPress={handleTypeAdd}>
              <Text style={styles.plusButtonText}>+</Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>

      <View style={styles.section}>
        <Text style={styles.subtitle}>Period & Price</Text>
        {plotTypes.map((type) => (
          <View key={type.id}>
            <Text style={styles.tableType}>{type.type}</Text>
            {plotPP
              .filter((ppItem) => !ppItem.isDeleted)
              .map((ppItem) => (
                <View key={`${type.id}-${ppItem.id}`} style={styles.tableRow}>
                  <TextInput
                    style={styles.tableCell}
                    keyboardType="numeric"
                    value={String(ppItem.period)}
                    onChangeText={(value) =>
                      handleEditField(ppItem.id, 'period', Number(value))
                    }
                  />
                  <TextInput
                    style={styles.tableCell}
                    keyboardType="numeric"
                    value={String(ppItem.price)}
                    onChangeText={(value) =>
                      handleEditField(ppItem.id, 'price', Number(value))
                    }
                  />
                  <TouchableOpacity onPress={() => handleDeleteRow(ppItem.id)}>
                    <Text style={styles.deleteIcon}>x</Text>
                  </TouchableOpacity>
                </View>
              ))}
          </View>
        ))}
        <TouchableOpacity onPress={handleAddRow} style={styles.addRowButton}>
          <Text style={styles.addButtonText}>+ Add Row</Text>
        </TouchableOpacity>
      </View>

      <TouchableOpacity onPress={handleSave} style={styles.saveButton}>
        <Text style={styles.saveButtonText}>Save Changes</Text>
      </TouchableOpacity>
    </ScrollView> 
  );
};

const styles = StyleSheet.create({
  scrollContainer: {
    paddingBottom: 20, 
  },
  container: {
    padding: 16,
    flex: 1,
    backgroundColor: '#ffffff',
    },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  title: {     
    fontSize: 20,
    fontWeight: 'bold',
    marginLeft: 10 
  },
  section: {
    marginBottom: 24,
  },
  subtitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  typeContainer: {
    marginBottom: 16,
  },
  typeBox: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
    backgroundColor: '#ffffff',
    borderRadius: 8,
    padding: 10,
    shadowColor: '#000',
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  typeInput: {
    borderWidth: 1,
    borderColor: '#ced4da',
    padding: 8,
    flex: 1,
    borderRadius: 4,
    marginRight: 8,
    fontSize: 16,
    color: '#495057',
  },
  deleteIcon: {
    color: '#e74c3c',
    fontSize: 18,
    fontWeight: 'bold',
  },
  addTypeContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  addButtonText: {
    fontSize: 16,
    color: '#fff',
  },
  plusButtonText: {
    fontSize: 16,
    color: 'gray',
  },
  tableType: {
    fontWeight: 'bold',
    fontSize: 16,
    color: '#495057',
    marginBottom: 8,
  },
  tableRow: {
    flexDirection: 'row',
    marginBottom: 8,
    backgroundColor: '#ffffff',
    borderRadius: 8,
    paddingVertical: 10,
    paddingHorizontal: 12,
    shadowColor: '#000',
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  tableCell: {
    borderWidth: 1,
    borderColor: '#ced4da',
    padding: 8,
    flex: 1,
    borderRadius: 4,
    fontSize: 16,
    color: '#495057',
    marginRight: 8,
  },
  addRowButton: {
    paddingVertical: 10,
    backgroundColor: '#007BFF',
    borderRadius: 8,
    alignItems: 'center',
    marginTop: 15,
  },
  saveButton: {
    paddingVertical: 12,
    backgroundColor: '#28a745',
    borderRadius: 8,
    alignItems: 'center',
    marginTop: 10,
    marginBottom: 10,
  },
  saveButtonText: {
    fontSize: 16,
    color: '#ffffff',
  },
});

export default UpdatePlotAttributes;
