import { initializeApp, getApps, getApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";
import { initializeAuth } from "firebase/auth";
import AsyncStorage from "@react-native-async-storage/async-storage"; // Correct AsyncStorage import
import { getReactNativePersistence } from "firebase/auth/react-native"; // Correct way to get React Native persistence

const firebaseConfig = {
  apiKey: "AIzaSyBGpw-Sfb5GCPVzmGlsiL1qzScsZVoBM_M",
  authDomain: "ekebun-tp067980.firebaseapp.com",
  projectId: "ekebun-tp067980",
  storageBucket: "ekebun-tp067980.appspot.com",
  messagingSenderId: "434973050970",
  appId: "1:434973050970:web:bba319c1fb8b98a39cf063",
  measurementId: "G-TFBMBQP3JK",
};

// Initialize Firebase App
const app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApp();

// Initialize Firestore
const db = getFirestore(app);

// Initialize Firebase Auth with React Native AsyncStorage
const auth = initializeAuth(app, {
  persistence: getReactNativePersistence(AsyncStorage),
});

export { db, app, auth };
