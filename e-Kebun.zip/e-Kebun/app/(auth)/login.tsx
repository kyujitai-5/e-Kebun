import React, { useState } from 'react';
import { StyleSheet, View, TextInput, Text, TouchableOpacity, Image, Alert } from 'react-native';
import { useRouter } from 'expo-router';
import { getAuth, signInWithEmailAndPassword } from 'firebase/auth';
import { app } from '../src/firebaseConfig';
import RNPickerSelect from 'react-native-picker-select';
import { getFirestore, doc, getDoc, query, where, getDocs, collection } from 'firebase/firestore';

const Login = () => {
  const [uid, setUid] = useState(''); 
  const [password, setPassword] = useState('');
  const [userType, setUserType] = useState('user'); 
  const router = useRouter();

  const handleLogin = async () => {
    const auth = getAuth(app);
    const db = getFirestore(app);

    if (uid && password) {
      try {
        if (userType === 'admin') {
          console.log('Logging in as Admin...');
          const adminDocRef = doc(db, 'admin', uid); // Admin UID-based login
          const adminDoc = await getDoc(adminDocRef);

          if (adminDoc.exists()) {
            const adminData = adminDoc.data();
            if (adminData.password === password) {
              console.log("Admin login successful!");
              router.push('/admin/dashboard');
            } else {
              Alert.alert('Incorrect admin password!');
            }
          } else {
            Alert.alert('No admin account found!');
          }
        } else {
          console.log('Logging in as User...');

          let userDoc;

          if (uid.includes('@')) {
            // Login using email
            console.log('Signing in with email:', uid);
            await signInWithEmailAndPassword(auth, uid, password);

            const usersQuery = query(collection(db, 'user'), where('email', '==', auth.currentUser?.email));
            const querySnapshot = await getDocs(usersQuery);

            if (!querySnapshot.empty) {
              userDoc = querySnapshot.docs[0]; 
            } else {
              Alert.alert('No user account found for this email!');
              return;
            }
          } else {
            // Login using username
            console.log('Signing in with username:', uid);

            const usersQuery = query(collection(db, 'user'), where('username', '==', uid));
            const querySnapshot = await getDocs(usersQuery);

            if (!querySnapshot.empty) {
              const userSnapshot = querySnapshot.docs[0];
              const email = userSnapshot.data().email;

              await signInWithEmailAndPassword(auth, email, password);
              userDoc = userSnapshot;
            } else {
              Alert.alert('No user account found for this username!');
              return;
            }
          }

          if (userDoc) {
            console.log("User login successful! Navigating to Home...");
            router.push({
              pathname: '/user/(tabs)',
              params: { email: auth.currentUser?.email }, 
            });
          }
        }
      } catch (error) {
        console.error('Login error:', error);
        Alert.alert('Incorrect Password');
      }
    } else {
      Alert.alert('Please fill in all fields');
    }
  };
  
  return (
    <View style={styles.container}>
      <Image source={require('../../assets/images/Login.png')} style={styles.logo} />
      
      <View style={styles.dropdownContainer}>
        <RNPickerSelect
          onValueChange={(value) => setUserType(value)}
          items={[{ label: 'User', value: 'user' }, { label: 'Admin', value: 'admin' }]}
          style={{
            ...pickerSelectStyles,
            placeholder: { color: '#A9A9A9', fontSize: 12 },
          }}
          placeholder={{ label: 'Select a user type...', value: '' }}
        />
      </View>
      
      <TextInput
        style={styles.input}
        placeholder={userType === 'admin' ? 'Admin UID' : 'Email or Username'}
        placeholderTextColor="#A9A9A9"
        value={uid}
        onChangeText={setUid}
      />
      <TextInput
        style={styles.input}
        placeholder="Password"
        placeholderTextColor="#A9A9A9"
        secureTextEntry
        value={password}
        onChangeText={setPassword}
      />
      <TouchableOpacity onPress={handleLogin} style={styles.loginButton}>
        <Text style={styles.loginButtonText}>Login</Text>
      </TouchableOpacity>

      <TouchableOpacity onPress={() => router.push('/(auth)/resetpassword')} style={styles.forgotPasswordLink}>
        <Text style={styles.forgotPasswordText}>Forgot Password?</Text>
      </TouchableOpacity>

      <View style={styles.signUpContainer}>
        <Text style={styles.signUpText}>Don't have an account? </Text>
        <TouchableOpacity onPress={() => router.push('/(auth)/signup')}>
          <Text style={styles.signUpLink}>Sign up</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};


const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 20,
  },
  logo: {
    marginBottom: 40,
    width: 150,
    height: 150,
    resizeMode: 'contain',
  },
  dropdownContainer: {
    width: '100%',
    backgroundColor: '#ededed',
    borderRadius: 10,
    marginBottom: 15,
    paddingHorizontal: 15,
  },
  input: {
    width: '100%',
    height: 50,
    backgroundColor: '#ededed',
    borderRadius: 10,
    paddingHorizontal: 15,
    fontSize: 15,
    marginBottom: 15,
  },
  loginButton: {
    width: '100%',
    height: 50,
    backgroundColor: '#945e25',
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 10,
    marginBottom: 30,
  },
  loginButtonText: {
    color: '#fff',
    fontWeight: 'bold',
    fontSize: 15,
    
  },
  forgotPasswordLink: {
    alignSelf: 'flex-end',
    marginBottom: 10,
    marginRight: 10,
    fontSize: 12,
  },
  forgotPasswordText: {
    fontSize: 12,
    fontStyle: 'italic',
    textDecorationLine: 'underline',
    color: 'blue',
  },
  signUpContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  signUpText: {
    fontSize: 12,
  },
  signUpLink: {
    fontSize: 12,
    color: 'blue',
    fontStyle: 'italic',
    textDecorationLine: 'underline',
  },
});

const pickerSelectStyles = StyleSheet.create({
  inputIOS: {
    width: '100%',
    height: 50,
    backgroundColor: '#ededed',
    borderRadius: 10,
    paddingHorizontal: 15,
    fontSize: 12,
    color: '#000',
  },
  inputAndroid: {
    width: '100%',
    height: 50,
    backgroundColor: '#ededed',
    borderRadius: 10,
    paddingHorizontal: 15,
    fontSize: 12,
    color: '#000',
  },
});

export default Login;
