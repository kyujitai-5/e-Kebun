import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  FlatList,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  Modal,
  ScrollView,
  Image,
} from 'react-native';
import { db } from '../../src/firebaseConfig';
import { collection, getDocs } from 'firebase/firestore';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';

interface ListingData {
  id: string;
  username: string;
  email: string;
  title: string;
  description: string;
  price: number;
  images: string[];
  status: string;
  createdAt: string;
}

const ManageListings = () => {
  const [listings, setListings] = useState<ListingData[]>([]);
  const [searchText, setSearchText] = useState('');
  const [selectedListing, setSelectedListing] = useState<ListingData | null>(null);
  const [modalVisible, setModalVisible] = useState(false);

  useEffect(() => {
    const fetchListings = async () => {
      try {
        const listingCollection = collection(db, 'listing');
        const listingSnapshot = await getDocs(listingCollection);

        const fetchedListings = listingSnapshot.docs.map((doc) => ({
          id: doc.id,
          email: doc.data().email || '',
          username: doc.data().username || '',
          title: doc.data().title || '',
          description: doc.data().description || '',
          price: doc.data().price || 0,
          images: doc.data().images || [],
          status: doc.data().status || 'inactive',
          createdAt: doc.data().createdAt || '',
        }));

        setListings(fetchedListings);
      } catch (error) {
        console.error('Error fetching listings:', error);
      }
    };

    fetchListings();
  }, []);

  const filteredListings = listings.filter((listing) =>
    listing.username.toLowerCase().includes(searchText.toLowerCase()) ||
    listing.email.toLowerCase().includes(searchText.toLowerCase()) ||
    listing.title.toLowerCase().includes(searchText.toLowerCase()) ||
    listing.id.toLowerCase().includes(searchText.toLowerCase())
  );

  const formatDate = (date: any) => {
    const cleanedDateString = typeof date === 'string' ? date : date?.toDate().toString();
    const dateObj = new Date(cleanedDateString.replace(' at', '').replace(' UTC+8', ''));
    return dateObj.toLocaleString();
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()}>
          <Ionicons name="arrow-back" size={24} color="black" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Manage Listings</Text>
      </View>

      <View style={styles.searchContainer}>
        <TextInput
          style={styles.searchInput}
          placeholder="Search..."
          value={searchText}
          onChangeText={setSearchText}
        />
      </View>

      <FlatList
        data={filteredListings}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <TouchableOpacity
            onPress={() => {
              setSelectedListing(item);
              setModalVisible(true);
            }}
            style={styles.listingItem}
          >
            <Text style={styles.listingId}>ID: {item.id}</Text>
            <Text style={styles.listingTitle}>{item.title}</Text>
            <Text style={styles.listingUsername}>@{item.username}</Text>
          </TouchableOpacity>
        )}
      />

      <Modal
        visible={modalVisible}
        animationType="fade"
        transparent={false}
        onRequestClose={() => setModalVisible(false)}
      >
        {selectedListing && (
          <ScrollView contentContainerStyle={styles.modalContent}>
            <View style={styles.modalHeader}>
              <TouchableOpacity onPress={() => setModalVisible(false)}>
                <Ionicons name="close" size={24} color="black" />
              </TouchableOpacity>
            </View>

            <View style={styles.modalCard}>
              <Text style={styles.detailTitle}>{selectedListing.title}</Text>
              <Text style={styles.detailDescription}>{selectedListing.description}</Text>
              <View style={styles.priceRow}>
                <Text style={styles.priceText}>RM {selectedListing.price.toFixed(2)}</Text>
                <Text
                  style={[
                    styles.status,
                    selectedListing.status === 'active' ? styles.activeStatus : null,  // Only check for 'active' status
                  ]}
                >
                  {selectedListing.status.toUpperCase()}
                </Text>
              </View>

              <Text style={styles.detailText}>@{selectedListing.username}</Text>
              <Text style={styles.detailText}>
                Created At: {formatDate(selectedListing.createdAt)}
              </Text>

              <Text style={styles.sectionTitle}>Images</Text>
              <ScrollView horizontal showsHorizontalScrollIndicator={false}>
                {selectedListing.images.map((image, index) => (
                  <View key={index} style={styles.imageCard}>
                    <Image source={{ uri: image }} style={styles.image} />
                  </View>
                ))}
              </ScrollView>
            </View>
          </ScrollView>
        )}
      </Modal>
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20, backgroundColor: '#fff' },
  header: { flexDirection: 'row', alignItems: 'center', marginBottom: 20 },
  headerTitle: { fontSize: 20, fontWeight: 'bold', marginLeft: 10 },
  searchContainer: { flexDirection: 'row', marginVertical: 10 },
  searchInput: { flex: 1, height: 40, borderColor: '#ccc', borderWidth: 1, paddingLeft: 8 },
  listingItem: { padding: 15, backgroundColor: '#f9f9f9', marginVertical: 5, borderRadius: 5 },
  listingId: { fontSize: 14, color: '#777' },
  listingTitle: { fontSize: 18, fontWeight: 'bold' },
  listingUsername: { fontSize: 14, color: '#555' },
  modalContent: { padding: 15 },
  modalHeader: { flexDirection: 'row', alignItems: 'center', marginBottom: 15 },
  modalHeaderTitle: { fontSize: 20, fontWeight: 'bold', marginLeft: 10 },
  modalCard: { backgroundColor: '#fff', borderRadius: 10, padding: 15, elevation: 3 },
  detailTitle: { fontSize: 24, fontWeight: 'bold', marginBottom: 10 },
  detailDescription: { fontSize: 16, marginBottom: 15 },
  priceRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  priceText: { fontSize: 20, fontWeight: 'bold', color: '#007BFF' },
  status: { paddingVertical: 5, paddingHorizontal: 10, borderRadius: 5 },
  activeStatus: { backgroundColor: '#28a745', color: '#fff' },
  detailText: { fontSize: 14, marginBottom: 5 },
  sectionTitle: { fontSize: 18, fontWeight: 'bold', marginVertical: 10 },
  imageCard: { borderRadius: 10, overflow: 'hidden', marginRight: 10 },
  image: { width: 150, height: 150 },
});

export default ManageListings;
