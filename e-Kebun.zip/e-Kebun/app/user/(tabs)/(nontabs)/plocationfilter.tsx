import React, { useState, useEffect } from 'react';
import { View, Text, TouchableOpacity, FlatList, StyleSheet, ScrollView } from 'react-native';
import { db } from '../../../src/firebaseConfig';
import { collection, getDocs, query, where } from 'firebase/firestore';
import { useRouter } from 'expo-router';

const LocationFilter = () => {
  const router = useRouter();

  const [states, setStates] = useState<string[]>([]);
  const [cities, setCities] = useState<string[]>([]);
  const [postcodes, setPostcodes] = useState<string[]>([]);
  const [sections, setSections] = useState<string[]>([]);

  const [selectedState, setSelectedState] = useState('');
  const [selectedCity, setSelectedCity] = useState('');
  const [selectedPostcode, setSelectedPostcode] = useState('');
  const [selectedSection, setSelectedSection] = useState('');

  // Fetch states from the 'location' collection
  useEffect(() => {
    const fetchStates = async () => {
      try {
        console.log('Fetching states...');
        const stateSnapshot = await getDocs(collection(db, 'location'));
        const stateList = Array.from(new Set(stateSnapshot.docs.map((doc) => doc.data().state || 'Unknown')));
        console.log('Fetched states:', stateList);
        setStates(stateList);
      } catch (error) {
        console.error('Error fetching states:', error);
      }
    };

    fetchStates();
  }, []);

  // Fetch cities based on the selected state
  useEffect(() => {
    if (!selectedState) return;

    const fetchCities = async () => {
      try {
        console.log('Fetching cities for state:', selectedState);
        const citySnapshot = await getDocs(
          query(collection(db, 'location'), where('state', '==', selectedState))
        );
        const cityList = Array.from(new Set(citySnapshot.docs.map((doc) => doc.data().city || 'Unknown')));
        console.log('Fetched cities:', cityList);
        setCities(cityList);
      } catch (error) {
        console.error('Error fetching cities:', error);
      }
    };

    fetchCities();
  }, [selectedState]);

  // Fetch postcodes based on the selected city
  useEffect(() => {
    if (!selectedCity) return;

    const fetchPostcodes = async () => {
      try {
        console.log('Fetching postcodes for city:', selectedCity);
        const postcodeSnapshot = await getDocs(
          query(collection(db, 'location'), where('city', '==', selectedCity))
        );
        const postcodeList = Array.from(new Set(postcodeSnapshot.docs.map((doc) => doc.data().postcode || 'Unknown')));
        console.log('Fetched postcodes:', postcodeList);
        setPostcodes(postcodeList);
      } catch (error) {
        console.error('Error fetching postcodes:', error);
      }
    };

    fetchPostcodes();
  }, [selectedCity]);

  // Fetch sections based on the selected postcode
  useEffect(() => {
    if (!selectedPostcode) return;

    const fetchSections = async () => {
      try {
        console.log('Fetching sections for postcode:', selectedPostcode);
        const sectionSnapshot = await getDocs(
          query(collection(db, 'location'), where('postcode', '==', selectedPostcode))
        );
        const sectionList = Array.from(new Set(sectionSnapshot.docs.map((doc) => doc.data().section || 'Unknown')));
        console.log('Fetched sections:', sectionList);
        setSections(sectionList);
      } catch (error) {
        console.error('Error fetching sections:', error);
      }
    };

    fetchSections();
  }, [selectedPostcode]);

  // Reset the filter selections
  const resetFilter = () => {
    setSelectedState('');
    setSelectedCity('');
    setSelectedPostcode('');
    setSelectedSection('');
    setCities([]);
    setPostcodes([]);
    setSections([]);
  };

  // Handle applying the selected filters
  const applyFilter = async () => {
    try {
      console.log('Applying filter...');
      console.log('Selected filters:', {
        state: selectedState,
        city: selectedCity,
        postcode: selectedPostcode,
        section: selectedSection,
      });
  
      // Start with the collection reference
      let plotQuery = query(collection(db, 'plotarea'));
  
      // Apply filters conditionally
      if (selectedState) {
        plotQuery = query(plotQuery, where('location.state', '==', selectedState));
      }
  
      if (selectedCity) {
        plotQuery = query(plotQuery, where('location.city', '==', selectedCity));
      }
  
      if (selectedPostcode) {
        plotQuery = query(plotQuery, where('location.postcode', '==', selectedPostcode));
      }
  
      if (selectedSection) {
        plotQuery = query(plotQuery, where('location.section', '==', selectedSection));
      }
  
      const plotSnapshot = await getDocs(plotQuery);
      const filteredPlots = plotSnapshot.docs.map((doc) => ({
        ...doc.data(),
        docId: doc.id,
      }));
  
      console.log('Filtered plots:', filteredPlots);
  
      // Pass the filtered plots to the plot page
      router.push({
        pathname: '/user/(tabs)/plot',
        params: {
          filterParams: JSON.stringify({
            state: selectedState,
            city: selectedCity,
            postcode: selectedPostcode,
            section: selectedSection,
          }),
          filteredPlots: JSON.stringify(filteredPlots),
        },
      });
    } catch (error) {
      console.error('Error applying filter:', error);
    }
  };
  
  const handleExitFilter = () => {
    setSelectedState('');
    setSelectedCity('');
    setSelectedPostcode('');
    setSelectedSection('');
    setCities([]);
    setPostcodes([]);
    setSections([]);
  
    router.push({
      pathname: '/user/(tabs)/plot',
      params: {
        filterParams: JSON.stringify({
          state: '',
          city: '',
          postcode: '',
          section: '',
        }),
      },
    });
  };

  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={handleExitFilter}>
          <Text style={styles.headerIcon}>×</Text>
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Filter Plot Location</Text>
        <TouchableOpacity onPress={resetFilter}>
          <Text style={styles.resetButton}>Reset</Text>
        </TouchableOpacity>
      </View>

      <View>
        <Text style={styles.subtitle}>State</Text>
        {states.map((item) => (
          <TouchableOpacity
            key={item}
            style={[styles.item, selectedState === item && styles.selectedItem]}
            onPress={() => {
              setSelectedState(item);
              setSelectedCity('');
              setSelectedPostcode('');
              setSelectedSection('');
            }}
          >
            <Text>{item}</Text>
          </TouchableOpacity>
        ))}

        {selectedState && (
          <>
            <Text style={styles.subtitle}>City</Text>
            {cities.map((item) => (
              <TouchableOpacity
                key={item}
                style={[styles.item, selectedCity === item && styles.selectedItem]}
                onPress={() => {
                  setSelectedCity(item);
                  setSelectedPostcode('');
                  setSelectedSection('');
                }}
              >
                <Text>{item}</Text>
              </TouchableOpacity>
            ))}
          </>
        )}

        {selectedCity && (
          <>
            <Text style={styles.subtitle}>Postcode</Text>
            {postcodes.map((item) => (
              <TouchableOpacity
                key={String(item)}
                style={[styles.item, selectedPostcode === String(item) && styles.selectedItem]}
                onPress={() => {
                  setSelectedPostcode(String(item));
                  setSelectedSection('');
                }}
              >
                <Text>{String(item)}</Text>
              </TouchableOpacity>
            ))}
          </>
        )}

        {selectedPostcode && (
          <>
            <Text style={styles.subtitle}>Section</Text>
            {sections.map((item) => (
              <TouchableOpacity
                key={item}
                style={[styles.item, selectedSection === item && styles.selectedItem]}
                onPress={() => setSelectedSection(item)}
              >
                <Text>{item}</Text>
              </TouchableOpacity>
            ))}
          </>
        )}
      </View>

      {selectedSection && (
        <TouchableOpacity style={styles.searchButton} onPress={applyFilter}>
          <Text style={styles.searchButtonText}>Apply Filter</Text>
        </TouchableOpacity>
      )}
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    padding: 16,
    backgroundColor: '#fff',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 16,
  },
  headerIcon: {
    fontSize: 24,
    fontWeight: 'bold',
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  resetButton: {
    fontSize: 16,
    color: 'blue',
  },
  subtitle: {
    fontSize: 16,
    marginBottom: 8,
  },
  item: {
    padding: 12,
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 8,
    marginBottom: 8,
  },
  selectedItem: {
    borderColor: 'blue',
  },
  searchButton: {
    backgroundColor: 'blue',
    padding: 16,
    borderRadius: 8,
    alignItems: 'center',
    marginTop: 16,
  },
  searchButtonText: {
    color: '#fff',
    fontWeight: 'bold',
  },
});

export default LocationFilter;
