import React, { useState } from 'react';
import { View, Text, TextInput, Button, Image, TouchableOpacity, StyleSheet, Alert, ScrollView } from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import { db } from '../../src/firebaseConfig';
import { collection, addDoc, query, where, getDocs } from 'firebase/firestore';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { getAuth } from 'firebase/auth';

const AddListing = () => {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [price, setPrice] = useState('');
  const [images, setImages] = useState<string[]>([]);
  const [loading, setLoading] = useState(false);
  const router = useRouter();

  const handleImagePick = async () => {
    let result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: true,
      aspect: [4, 3],
      quality: 1,
    });

    if (!result.canceled && result.assets && result.assets.length > 0) {
      const pickedImageUri = result.assets[0].uri;
      setImages([...images, pickedImageUri]);
    }
  };

  const handleImageDelete = (index: number) => {
    const updatedImages = [...images];
    updatedImages.splice(index, 1);
    setImages(updatedImages);
  };

  const handleSubmit = async () => {
    if (!title || !description || !price || images.length === 0) {
      Alert.alert('Error', 'Please fill in all fields and upload at least one image.');
      return;
    }
  
    setLoading(true);
  
    try {
      const auth = getAuth();
      const user = auth.currentUser;
      if (!user) {
        Alert.alert('Error', 'You are not logged in.');
        return;
      }
  
      const email = user.email;
  
      // Fetch username from the 'user' collection based on the email
      const userRef = collection(db, 'user');
      const q = query(userRef, where('email', '==', email));
      const userSnap = await getDocs(q);
  
      let username = 'Anonymous'; // Default value if not found
  
      if (!userSnap.empty) {
        const userData = userSnap.docs[0].data();
        username = userData.username || 'Anonymous'; // Get the username from the document
      }
  
      const currentDate = new Date();
  
      // Add listing to Firestore
      await addDoc(collection(db, 'listing'), {
        title,
        description,
        price: parseFloat(price),
        images,
        email,
        username,
        createdAt: currentDate,
        status: 'active',
      });
  
      Alert.alert('Success', 'Listing created successfully!', [
        {
          text: 'OK',
          onPress: () => {
            setTitle('');
            setDescription('');
            setPrice('');
            setImages([]);
            router.push('/user/(tabs)/account');
          },
        },
      ]);
    } catch (error) {
      console.error('Error creating listing:', error);
      Alert.alert('Error', 'Failed to create the listing. Please try again.');
    } finally {
      setLoading(false);
    }
  };  

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()}>
        </TouchableOpacity>
        <Text style={styles.title}>Add New Listing</Text>
      </View>

      <Text style={styles.imageText}>Title</Text>
      <TextInput
        style={styles.input}
        placeholder="Title"
        value={title}
        onChangeText={setTitle}
      />
      <Text style={styles.imageText}>Description</Text>
      <TextInput
        style={[styles.input, { height: 100 }]}
        placeholder="Description"
        value={description}
        onChangeText={setDescription}
        multiline
      />
      <View style={styles.row}>
        <Text style={styles.label}>RM</Text>
        <TextInput
          style={styles.inputInline}
          placeholder="Price"
          keyboardType="numeric"
          value={price}
          onChangeText={setPrice}
        />
      </View>

      <View style={styles.imageContainer}>
        <Text style={styles.imageText}>Images</Text>
        <TouchableOpacity onPress={handleImagePick} style={styles.button}>
          <Text style={styles.buttonText}>Pick Images</Text>
        </TouchableOpacity>
        <ScrollView horizontal showsHorizontalScrollIndicator={false}>
          {images.map((image, index) => (
            <View key={index} style={styles.imageWrapper}>
              <Image source={{ uri: image }} style={styles.imageThumbnail} />
              <TouchableOpacity
                style={styles.deleteButton}
                onPress={() => handleImageDelete(index)}
              >
                <Ionicons name="close" size={20} color="white" />
              </TouchableOpacity>
            </View>
          ))}
        </ScrollView>
      </View>
      <Text style={styles.recommendation}>
        * We recommend keeping your listing active for one week only. If it’s not sold, you can join us at our Sunday market to sell it there!
      </Text>

      <TouchableOpacity
        onPress={handleSubmit}
        style={[styles.button, loading && { backgroundColor: '#ccc' }]}
        disabled={loading}
      >
        <Text style={styles.buttonText}>
          {loading ? 'Saving...' : 'Post Listing'}
        </Text>
      </TouchableOpacity>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flexGrow: 1,
    padding: 20,
    backgroundColor: '#fff',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    textAlign: 'left',
  },
  recommendation: {
    fontSize: 14,
    color: '#555',
    fontStyle: 'italic',
    marginBottom: 15,
  },
  input: {
    height: 45,
    borderColor: '#ddd',
    borderWidth: 1,
    marginBottom: 15,
    paddingLeft: 10,
    borderRadius: 5,
    backgroundColor: '#f9f9f9',
  },
  imageContainer: {
    marginBottom: 20,
    paddingVertical: 10,
  },
  imageText: {
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  imageWrapper: {
    position: 'relative',
  },
  imageThumbnail: {
    width: 100,
    height: 100,
    marginRight: 10,
    borderRadius: 5,
  },
  deleteButton: {
    position: 'absolute',
    top: 5,
    right: 5,
    borderRadius: 15,
    padding: 5,
  },
  button: {
    backgroundColor: '#007BFF',
    padding: 10,
    marginBottom: 10,
    borderRadius: 5,
    alignItems: 'center',
  },
  buttonText: {
    color: 'white',
    fontSize: 16,
  },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 15,
  },
  label: {
    fontSize: 16,
    marginRight: 10,
    color: '#333',
    fontWeight: 'bold',
  },
  inputInline: {
    flex: 1,
    height: 45,
    borderColor: '#ddd',
    borderWidth: 1,
    borderRadius: 5,
    paddingHorizontal: 10,
    backgroundColor: '#f9f9f9',
  },
});

export default AddListing;
