import React, { useState, useEffect } from 'react';
import { View, Text, TextInput, TouchableOpacity, Alert, FlatList, StyleSheet, Image, ScrollView } from 'react-native';
import { db } from '../../src/firebaseConfig';
import { doc, getDoc, setDoc, collection, getDocs, addDoc, updateDoc, deleteDoc, query, where } from 'firebase/firestore';
import { useRouter, useLocalSearchParams } from 'expo-router';
import * as ImagePicker from 'expo-image-picker';
import RNPickerSelect from 'react-native-picker-select';
import { Ionicons } from '@expo/vector-icons';

interface Plot {
  plotNumber: string;
  type: string;
  id: string;
  status: string;
  plotAreaId: string;
}

interface PlotDetails {
  name: string;
  description: string;
  location: {
    state: string;
    city: string;
    postcode: string;
    section: string;
  };
  images: string[];
  plotQuantities: { [type: string]: number };
  plotAvailability?: { [type: string]: number }; 
}

const EditPlotArea = () => {
  const router = useRouter();
  const { id } = useLocalSearchParams(); 
  const [plotDetails, setPlotDetails] = useState<PlotDetails | null>(null);
  const [plotQuantities, setPlotQuantities] = useState<{ [type: string]: string }>({});
  const [availableStates, setAvailableStates] = useState<string[]>([]);
  const [availableCities, setAvailableCities] = useState<string[]>([]);
  const [availablePostcodes, setAvailablePostcodes] = useState<string[]>([]);
  const [availableSections, setAvailableSections] = useState<string[]>([]);
  const [selectedImageIndex, setSelectedImageIndex] = useState<number | null>(null);

  useEffect(() => {
    const fetchPlotDetails = async () => {
      if (!id) return;
    
      try {
        const docRef = doc(db, 'plotarea', id as string);
        const docSnapshot = await getDoc(docRef);
    
        if (docSnapshot.exists()) {
          const data = docSnapshot.data();
    
          // Fetch all available plot types from 'plotsettype'
          const plotTypesSnapshot = await getDocs(collection(db, 'plotsettype'));
          const allPlotTypes = plotTypesSnapshot.docs.map((doc) => doc.data().type);
    
          // Initialize plot quantities map
          const plotQuantities: { [type: string]: number } = {};
          allPlotTypes.forEach((type) => {
            plotQuantities[type] = 0; // Default quantity for new types
          });
    
          // Fetch existing plots for the plot area
          const plotsSnapshot = await getDocs(
            query(collection(db, 'plots'), where('plotAreaId', '==', id))
          );
    
          const plotAvailability: { [type: string]: number } = {};
          plotsSnapshot.forEach((plotDoc) => {
            const plotData = plotDoc.data();
            const type = plotData.type;
            const status = plotData.status;
    
            // Update quantities based on plot type
            if (type in plotQuantities) {
              plotQuantities[type] += 1;
            }
    
            // Update availability based on status
            if (status === 'available') {
              plotAvailability[type] = (plotAvailability[type] || 0) + 1;
            }
          });
    
          // Update state with plot details
          setPlotDetails({
            name: data.name,
            description: data.description,
            location: data.location,
            images: data.images || [],
            plotQuantities,
            plotAvailability,
          });
    
          // Update state for form or UI (stringified quantities)
          setPlotQuantities(
            Object.keys(plotQuantities).reduce((acc, type) => {
              acc[type] = plotQuantities[type].toString();
              return acc;
            }, {} as { [type: string]: string })
          );
        }
      } catch (error) {
        console.error('Error fetching plot details:', error);
      }
    };    
  
    fetchPlotDetails();
  }, [id]);
  
  // Fetching available states and updating location data
  useEffect(() => {
    const fetchLocationData = async () => {
      try {
        const locationSnapshot = await getDocs(collection(db, 'location'));
        const states: string[] = [];
        locationSnapshot.forEach((doc) => {
          const state = doc.data().state;
          if (!states.includes(state)) states.push(state);
        });
        setAvailableStates(states);
      } catch (error) {
        console.error("Error fetching location data:", error);
      }
    };

    fetchLocationData();
  }, []);

  useEffect(() => {
    if (plotDetails?.location.state) {
      const fetchCities = async () => {
        try {
          const citySnapshot = await getDocs(collection(db, 'location'));
          const cities: string[] = [];
          citySnapshot.forEach((doc) => {
            const city = doc.data().city;
            if (doc.data().state === plotDetails.location.state && !cities.includes(city)) {
              cities.push(city);
            }
          });
          setAvailableCities(cities);
        } catch (error) {
          console.error("Error fetching cities:", error);
        }
      };
      fetchCities();
    }
  }, [plotDetails?.location.state]);

  useEffect(() => {
    if (plotDetails?.location.city) {
      const fetchPostcodes = async () => {
        try {
          const postcodeSnapshot = await getDocs(collection(db, 'location'));
          const postcodes: string[] = [];
          postcodeSnapshot.forEach((doc) => {
            const postcode = doc.data().postcode;
            if (doc.data().city === plotDetails.location.city && !postcodes.includes(postcode)) {
              postcodes.push(postcode);
            }
          });
          setAvailablePostcodes(postcodes);
        } catch (error) {
          console.error("Error fetching postcodes:", error);
        }
      };
      fetchPostcodes();
    }
  }, [plotDetails?.location.city]);

  useEffect(() => {
    if (plotDetails?.location.postcode) {
      const fetchSections = async () => {
        try {
          const sectionSnapshot = await getDocs(collection(db, 'location'));
          const sections: string[] = [];
          sectionSnapshot.forEach((doc) => {
            const section = doc.data().section;
            if (doc.data().postcode === plotDetails.location.postcode && !sections.includes(section)) {
              sections.push(section);
            }
          });
          setAvailableSections(sections);
        } catch (error) {
          console.error("Error fetching sections:", error);
        }
      };
      fetchSections();
    }
  }, [plotDetails?.location.postcode]);

  useEffect(() => {
    const fetchAvailablePlotTypes = async () => {
      try {
        const plotTypesSnapshot = await getDocs(collection(db, 'plotsettype'));
        const availableTypes = plotTypesSnapshot.docs.map((doc) => doc.data().type);
    
        setPlotQuantities((prev) => {
          const updatedQuantities = { ...prev };
          availableTypes.forEach((type) => {
            if (!(type in updatedQuantities)) {
              updatedQuantities[type] = '0'; // Add new types with default 0
            }
          });
    
          return updatedQuantities;
        });
      } catch (error) {
        console.error('Error fetching plot types:', error);
      }
    };    
  
    fetchAvailablePlotTypes();
  }, []);  
  
  const handleSave = async () => {
    if (!plotDetails || !id) return;
  
    try {
      // Move excess plots to archivedplots collection if quantity is reduced
      await handleMoveExcessPlots();
  
      // Update the plot area details in the plotarea collection
      const updatedQuantities = Object.keys(plotQuantities).reduce((acc, type) => {
        acc[type] = parseInt(plotQuantities[type]);
        return acc;
      }, {} as { [type: string]: number });
  
      // Set the new quantities in the plotarea document (without updating availability yet)
      await setDoc(
        doc(db, 'plotarea', id as string),
        {
          ...plotDetails,
          plotQuantities: updatedQuantities,
        },
        { merge: true } // Merge the fields to avoid overwriting the entire document
      );
  
      // Create new plots or restore archived plots based on updated quantity
      await handleRestoreOrCreatePlots();
  
      // Calculate the plot availability (count of available plots)
      const updatedAvailability: { [type: string]: number } = {};
      const plotsSnapshot = await getDocs(
        query(collection(db, 'plots'), where('plotAreaId', '==', id))
      );
      plotsSnapshot.forEach((plotDoc) => {
        const plotData = plotDoc.data();
        const type = plotData.type;
        const status = plotData.status;
        
        if (status === 'available') {
          updatedAvailability[type] = (updatedAvailability[type] || 0) + 1;
        }
      });
  
      // Update the availability 
      await setDoc(
        doc(db, 'plotarea', id as string),
        {
          plotAvailability: updatedAvailability, 
        },
        { merge: true } // Merge the fields to avoid overwriting the entire document
      );
  
      Alert.alert('Success', 'Plot area details updated successfully!');
  
      router.push('/admin/plots/manageplots');
    } catch (error) {
      console.error('Error updating plot area details:', error);
      Alert.alert('Error', 'Could not update plot area. Please try again.');
    }
  };
  
  const handleMoveExcessPlots = async () => {
    try {
      const plotsSnapshot = await getDocs(
        query(collection(db, 'plots'), where('plotAreaId', '==', id))
      );
  
      const plots: Plot[] = plotsSnapshot.docs.map((doc) => ({
        id: doc.id,
        plotNumber: doc.data().plotNumber,
        type: doc.data().type,
        status: doc.data().status,
        plotAreaId: doc.data().plotAreaId,
      }));
  
      for (let type of Object.keys(plotQuantities)) {
        const currentQuantity = plots.filter((plot) => plot.type === type).length;
        const newQuantity = parseInt(plotQuantities[type]);
  
        if (currentQuantity > newQuantity) {
          const excessPlots = plots
            .filter((plot) => plot.type === type)
            .sort((a, b) => {
              const plotA = parseInt(a.plotNumber.slice(1), 10);
              const plotB = parseInt(b.plotNumber.slice(1), 10);
              return plotB - plotA; 
            })
            .slice(0, currentQuantity - newQuantity); 
  
          for (let plot of excessPlots) {
            const { id, ...plotWithoutId } = plot; 
  
            // Change plot status to "unavailable"
            await updateDoc(doc(db, 'plots', id), { status: 'unavailable' });
  
            // Move the plot to the archivedplots collection
            await setDoc(doc(db, 'archivedplots', id), {
              ...plotWithoutId,
              status: 'unavailable', 
            });
  
            // Remove the plot from the plots collection
            await deleteDoc(doc(db, 'plots', id));
          }
        }
      }
    } catch (error) {
      console.error('Error moving excess plots to archivedplots:', error);
    }
  };  

// Restore archived plots if quantity increases
const handleRestoreOrCreatePlots = async () => {
  try {
    // Iterate through each plot type in the quantities
    for (let type of Object.keys(plotQuantities)) {
      const currentPlots = await getDocs(
        query(collection(db, 'plots'), where('plotAreaId', '==', id))
      );

      const currentQuantity = currentPlots.docs.filter((doc) => doc.data().type === type).length;
      const newQuantity = parseInt(plotQuantities[type]);

      // Fetch archived plots for the same type and plot area
      const archivedPlotsSnapshot = await getDocs(
        query(collection(db, 'archivedplots'), where('plotAreaId', '==', id), where('type', '==', type))
      );

      // Restore archived plots if the new quantity is greater than the current
      if (newQuantity > currentQuantity) {
        const archivedPlotsToRestore = archivedPlotsSnapshot.docs.slice(0, newQuantity - currentQuantity);

        // Move restored plots back to the 'plots' collection
        for (let plotDoc of archivedPlotsToRestore) {
          const plot = plotDoc.data();
          await setDoc(doc(db, 'plots', plotDoc.id), { ...plot, status: 'available' });
          await deleteDoc(doc(db, 'archivedplots', plotDoc.id));
        }
      }

      // Determine if new plots need to be created
      const newPlotsNeeded = newQuantity - currentQuantity - archivedPlotsSnapshot.docs.length;

      // Find the last plot number used for this type
      const lastPlotNumber = Math.max(
        ...currentPlots.docs
          .filter((doc) => doc.data().type === type)
          .map((doc) => parseInt(doc.data().plotNumber.slice(1), 10)),
        0
      );

      let startPlotNumber = lastPlotNumber > 0 ? lastPlotNumber : 0;

      // Create new plots if required
      for (let i = 1; i <= newPlotsNeeded; i++) {
        const newPlotNumber = `P${(startPlotNumber + i).toString().padStart(3, '0')}`;

        const newPlot = {
          plotAreaId: id,
          type: type,
          plotNumber: newPlotNumber,
          status: 'available',
        };

        // Add the new plot to the 'plots' collection
        await addDoc(collection(db, 'plots'), newPlot);
      }
    }
  } catch (error) {
    console.error('Error restoring or creating plots:', error);
  }
};

// Archive function for plot area and plots
const handleArchive = async () => {
  if (!id) return;

  try {
    const plotAreaDocRef = doc(db, 'plotarea', id as string);
    const plotAreaSnapshot = await getDoc(plotAreaDocRef);

    if (!plotAreaSnapshot.exists()) {
      Alert.alert('Error', 'Plot area not found.');
      return;
    }

    // Archive the plot area by copying it to the archived collection
    await setDoc(doc(db, 'archivedplotarea', id as string), plotAreaSnapshot.data());

    // Archive all associated plots by setting status to "unavailable"
    const plotsSnapshot = await getDocs(
      query(collection(db, 'plots'), where('plotAreaId', '==', id))
    );

    for (const plotDoc of plotsSnapshot.docs) {
      const plotData = plotDoc.data();

      // Mark plot as "unavailable" before archiving
      await updateDoc(doc(db, 'plots', plotDoc.id), { status: 'unavailable' });

      // Archive plot
      await setDoc(doc(db, 'archivedplots', plotDoc.id), {
        ...plotData,
        status: 'unavailable',
      });

      // Remove the plot from the 'plots' collection
      await deleteDoc(doc(db, 'plots', plotDoc.id));
    }

    // After archiving, delete the plot area
    await deleteDoc(plotAreaDocRef);

    // Show success message
    Alert.alert('Success', 'Plot area and its plots have been archived successfully!');
    
    // Redirect to manage plots page
    router.push('/admin/plots/manageplots');
  } catch (error) {
    console.error('Error archiving plot area:', error);
    Alert.alert('Error', 'Could not archive the plot area. Please try again.');
  }
};


// Handle image press to toggle selection for deletion
const handleImagePress = (index: number) => {
  if (selectedImageIndex === index) {
    const updatedImages = plotDetails?.images.filter((_, i) => i !== index) || [];
    setPlotDetails((prevDetails) => prevDetails ? { ...prevDetails, images: updatedImages } : prevDetails);
    setSelectedImageIndex(null);
  } else {
    setSelectedImageIndex(index);
  }
};

const handleImageUpload = async () => {
  const permissionResult = await ImagePicker.requestMediaLibraryPermissionsAsync();
  if (!permissionResult.granted) {
    Alert.alert("Permission Denied", "You've refused to allow this app to access your photos!");
    return;
  }

  const pickerResult = await ImagePicker.launchImageLibraryAsync({
    mediaTypes: ImagePicker.MediaTypeOptions.Images,
    allowsMultipleSelection: true,
    selectionLimit: 5 - (plotDetails?.images.length || 0),
  });

  if (!pickerResult.canceled) {
    const newImages = pickerResult.assets.map((asset) => asset.uri);
    setPlotDetails((prev) => ({
      ...prev!,
      images: [...(prev?.images || []), ...newImages],
    }));
  }
};

  if (!plotDetails) return <Text>Loading...</Text>;

  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.push('/admin/plots/manageplots')}>
          <Ionicons name="arrow-back" size={24} color="#000" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Edit Plot Area</Text>
      </View>

      <Text style={styles.label}>Name</Text>
      <TextInput
        style={styles.input}
        value={plotDetails.name}
        onChangeText={(text) => setPlotDetails((prev) => prev ? { ...prev, name: text } : prev)}
      />

      <Text style={styles.label}>Description</Text>
      <TextInput
        style={[styles.input, styles.textArea]}
        value={plotDetails.description}
        onChangeText={(text) => setPlotDetails((prev) => prev ? { ...prev, description: text } : prev)}
        multiline
      />

      <Text style={styles.label}>Location</Text>
      <RNPickerSelect
        placeholder={{ label: 'Select State', value: '' }}
        value={plotDetails.location.state}
        onValueChange={(value) =>
          setPlotDetails((prev) => ({ ...prev!, location: { ...prev!.location, state: value } }))
        }
        items={availableStates.map((state) => ({ label: state, value: state }))}
        style={pickerStyles}
      />
      <RNPickerSelect
        placeholder={{ label: 'Select City', value: '' }}
        value={plotDetails.location.city}
        onValueChange={(value) =>
          setPlotDetails((prev) => ({ ...prev!, location: { ...prev!.location, city: value } }))
        }
        items={availableCities.map((city) => ({ label: city, value: city }))}
        style={pickerStyles}
      />
      <RNPickerSelect
        placeholder={{ label: 'Select Postcode', value: '' }}
        value={plotDetails.location.postcode}
        onValueChange={(value) =>
          setPlotDetails((prev) => ({ ...prev!, location: { ...prev!.location, postcode: value } }))
        }
        items={availablePostcodes.map((postcode) => ({ label: postcode, value: postcode }))}
        style={pickerStyles}
      />
      <RNPickerSelect
        placeholder={{ label: 'Select Section', value: '' }}
        value={plotDetails.location.section}
        onValueChange={(value) =>
          setPlotDetails((prev) => ({ ...prev!, location: { ...prev!.location, section: value } }))
        }
        items={availableSections.map((section) => ({ label: section, value: section }))}
        style={pickerStyles}
      />

      <Text style={styles.label}>Plot Quantities</Text>
      {Object.keys(plotQuantities).map((type) => (
        <View key={type} style={styles.plotQuantity}>
          <Text style={styles.plotType}>{type}</Text>
          <TextInput
            style={styles.input}
            keyboardType="numeric"
            value={plotQuantities[type]}
            onChangeText={(value) =>
              setPlotQuantities((prev) => ({ ...prev, [type]: value }))
            }
          />
        </View>
      ))}

      <Text style={styles.label}>Images</Text>
      <FlatList
        data={plotDetails.images}
        horizontal
        keyExtractor={(item, index) => index.toString()}
        renderItem={({ item, index }) => (
          <TouchableOpacity onPress={() => handleImagePress(index)}>
            <Image source={{ uri: item }} style={styles.image} />
            {selectedImageIndex === index && (
              <Text style={styles.deleteIcon}>X</Text>
            )}
          </TouchableOpacity>
        )}
      />
      <TouchableOpacity onPress={handleImageUpload} style={styles.uploadButton}>
        <Text style={styles.uploadText}>Upload Images</Text>
      </TouchableOpacity>

      <View style={styles.buttonContainer}>
        <TouchableOpacity style={styles.button} onPress={handleArchive}>
          <Text style={styles.buttonText}>Archive</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.button} onPress={handleSave}>
          <Text style={styles.buttonText}>Save Changes</Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#fff',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 20,
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    marginLeft: 10,
  },
  backButton: {
    padding: 5,
  },
  label: {
    marginTop: 20,
    fontSize: 20,
    fontWeight: '600',
    color: '#333',
  },
  input: {
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 8,
    padding: 12,
    marginTop: 10,
    fontSize: 16,
    color: '#333',
  },
  textArea: {
    height: 100,
    textAlignVertical: 'top',
  },
  plotQuantity: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginVertical: 10,
  },
  plotType: {
    fontSize: 16,
    fontWeight: '600',
    color: '#333',
  },
  image: {
    width: 100,
    height: 100,
    marginRight: 10,
    borderRadius: 8,
  },
  deleteIcon: {
    position: 'absolute',
    top: 0,
    right: 0,
    backgroundColor: 'red',
    color: 'white',
    fontSize: 16,
    padding: 5,
    borderRadius: 15,
  },
  uploadButton: {
    backgroundColor: '#4CAF50',
    padding: 12,
    borderRadius: 8,
    alignItems: 'center',
    marginTop: 20,
  },
  uploadText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '600',
  },
  buttonContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 30,
  },
  button: {
    backgroundColor: '#007BFF',
    padding: 15,
    borderRadius: 8,
    flex: 1,
    marginHorizontal: 5,
    alignItems: 'center',
  },
  buttonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '600',
  },
});

// Picker style
const pickerStyles = {
  inputIOS: {
    fontSize: 16,
    paddingVertical: 12,
    paddingHorizontal: 10,
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 8,
    backgroundColor: '#fff',
    color: '#333',
    marginTop: 10,
  },
  inputAndroid: {
    fontSize: 16,
    paddingVertical: 12,
    paddingHorizontal: 10,
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 8,
    backgroundColor: '#fff',
    color: '#333',
    marginTop: 10,
  },
};

export default EditPlotArea;