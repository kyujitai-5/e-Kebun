
import React, { useEffect } from 'react';
import { View, Image, StyleSheet } from 'react-native';
import * as SplashScreen from 'expo-splash-screen';
import { useRouter } from 'expo-router';

const Splash = () => {
  const router = useRouter();

  useEffect(() => {
    const prepare = async () => {
      await SplashScreen.preventAutoHideAsync();
      setTimeout(() => {
        SplashScreen.hideAsync();
        console.log("Navigating to Login");
        router.push('/(auth)/login'); 
      }, 2000);
    };

    prepare();
  }, []);

  return (
    <View style={styles.container}>
      <Image source={require('../../assets/images/splash.png')} style={styles.logo} />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#a4d17c', 
  },
  logo: {
    width: 150, // Adjust width as needed
    height: 150, // Adjust height as needed
    resizeMode: 'contain',
  },
});

export default Splash;
