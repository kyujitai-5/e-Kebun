import React, { useState } from 'react';
import { View, Text, TextInput, Button, StyleSheet, TouchableOpacity, Alert, ActivityIndicator } from 'react-native';
import { getAuth, updatePassword } from 'firebase/auth';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';

const ChangePassword = () => {
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const router = useRouter();

  const handleChangePassword = async () => {
    if (loading) return;
    setLoading(true);

    const auth = getAuth();
    const user = auth.currentUser;

    if (user) {
      try {
        // Re-authenticate with the current password
        await updatePassword(user, newPassword);
        Alert.alert('Success', 'Your password has been updated successfully!', [
          {
            text: 'OK',
            onPress: () => router.back(), // Go back after success
          },
        ]);
      } catch (error) {
        Alert.alert('Error', 'There was an issue updating your password. Please try again.');
      } finally {
        setLoading(false);
      }
    } else {
      Alert.alert('Error', 'User not authenticated.');
      setLoading(false);
    }
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()}>
          <Ionicons name="arrow-back" size={24} color="black" />
        </TouchableOpacity>
        <Text style={styles.title}>Change Password</Text>
      </View>

      <Text style={styles.label}>Current Password</Text>
      <TextInput
        value={currentPassword}
        onChangeText={setCurrentPassword}
        placeholder="Current Password"
        style={styles.input}
        secureTextEntry
      />

      <Text style={styles.label}>New Password</Text>
      <TextInput
        value={newPassword}
        onChangeText={setNewPassword}
        placeholder="New Password"
        style={styles.input}
        secureTextEntry
      />

    <TouchableOpacity
      style={[styles.Button, { backgroundColor: loading ? '#ddd' : '#945e25' }]}
      onPress={handleChangePassword}
      disabled={loading}
    >
      {loading ? (
        <ActivityIndicator size="small" color="#fff" /> 
      ) : (
        <Text style={styles.ButtonText}>Change Password</Text>
      )}
    </TouchableOpacity>

    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: 'white',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 20,
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
    marginLeft: 10,
  },
  label: {
    fontSize: 16,
    marginBottom: 10,
  },
  input: {
    borderWidth: 1,
    borderColor: '#ccc',
    padding: 10,
    marginBottom: 20,
    borderRadius: 5,
  },
  Button: {
    width: '100%',
    height: 50,
    backgroundColor: '#945e25',
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 10,
    marginBottom: 30,
  },
  ButtonText: {
    color: '#fff',
    fontWeight: 'bold',
    fontSize: 15,
  },
});

export default ChangePassword;
