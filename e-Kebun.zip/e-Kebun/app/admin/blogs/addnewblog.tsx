import React, { useState } from 'react';
import { View, Text, TextInput, Button, StyleSheet, Alert, TouchableOpacity } from 'react-native';
import { db } from '../../src/firebaseConfig'; // Adjust import according to your setup
import { collection, addDoc } from 'firebase/firestore';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';

const AddNewBlog = () => {
  const [blogTitle, setBlogTitle] = useState('');
  const [blogDescription, setBlogDescription] = useState('');
  const [loading, setLoading] = useState(false);
  const router = useRouter();

  const handleSubmit = async () => {
    if (loading) return;
    setLoading(true);

    if (!blogTitle || !blogDescription) {
      Alert.alert('Error', 'Please fill in both the title and description.');
      setLoading(false);
      return;
    }

    try {
      const newBlogData = {
        title: blogTitle,
        description: blogDescription,
        createdAt: new Date(), // Add a timestamp for when the blog was created
      };

      // Save to Firestore
      await addDoc(collection(db, 'blogs'), newBlogData);

      Alert.alert('Success', 'Blog added successfully!');
      router.push('/admin/blogs/manageblogs'); // Navigate to the blogs management page
    } catch (error) {
      console.error('Error adding blog:', error);
      Alert.alert('Error', 'There was an issue adding the blog.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()}>
          <Ionicons name="arrow-back" size={24} color="black" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Add New Blog</Text>
      </View>

      <View style={styles.inputContainer}>
        <Text style={styles.label}>Blog Title</Text>
        <TextInput
          value={blogTitle}
          onChangeText={setBlogTitle}
          placeholder="Enter Blog Title"
          style={styles.input}
        />
      </View>

      <View style={styles.inputContainer}>
        <Text style={styles.label}>Blog Description</Text>
        <TextInput
          value={blogDescription}
          onChangeText={setBlogDescription}
          placeholder="Enter Blog Description"
          style={[styles.input, styles.textArea]}
          multiline
          numberOfLines={5}
        />
      </View>

      <Button title={loading ? 'Saving...' : 'Add Blog'} onPress={handleSubmit} disabled={loading} />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#fff',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 20,
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    marginLeft: 10,
  },
  inputContainer: {
    marginVertical: 10,
  },
  label: {
    fontSize: 16,
    marginBottom: 8,
  },
  input: {
    borderWidth: 1,
    borderColor: '#ccc',
    padding: 10,
    borderRadius: 5,
    fontSize: 16,
  },
  textArea: {
    height: 100,
    textAlignVertical: 'top',
  },
});

export default AddNewBlog;
