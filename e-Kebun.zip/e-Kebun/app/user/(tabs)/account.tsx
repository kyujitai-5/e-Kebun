import React, { useEffect, useState } from 'react';
import { StyleSheet, View, Text, TouchableOpacity, ScrollView, Image } from 'react-native';
import { useRouter } from 'expo-router';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { getAuth } from 'firebase/auth';
import { collection, getDocs, query, where, doc, getDoc } from 'firebase/firestore';
import { app, db } from '../../src/firebaseConfig';
import { Ionicons } from '@expo/vector-icons';

interface Listing {
  title: string;
  price: number;
  images: string[];
  status: 'active' | 'sold';
  email: string;
  docId: string;
}

interface Feedback {
  buyerUsername: string;
  description: string;
}

export default function Account() {
  const [userEmail, setUserEmail] = useState<string | null>(null);
  const [userInfo, setUserInfo] = useState<any | null>(null);
  const [activeTab, setActiveTab] = useState('Listing');
  const [activeListings, setActiveListings] = useState<Listing[]>([]);
  const [inactiveListings, setInactiveListings] = useState<Listing[]>([]);
  const [showInactive, setShowInactive] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [feedbacks, setFeedbacks] = useState<Feedback[]>([]);
  const [loadingFeedback, setLoadingFeedback] = useState(true);

  const router = useRouter();
  const auth = getAuth(app);
  const user = auth.currentUser;

  useEffect(() => {
    const fetchData = async () => {
      if (user) {
        setUserEmail(user.email);
        try {
          const userDoc = await getDoc(doc(db, 'user', user.uid));
          if (userDoc.exists()) {
            setUserInfo(userDoc.data());
          } else {
            console.error('User data not found in the database.');
          }

          const listingsQuery = query(collection(db, 'listing'), where('email', '==', user.email));
          const querySnapshot = await getDocs(listingsQuery);
          const active: Listing[] = [];
          const inactive: Listing[] = [];
          
          querySnapshot.forEach((doc) => {
            const data = doc.data();
            const listing: Listing = {
              title: data.title,
              price: data.price,
              images: data.images,
              status: data.status,
              email: data.email,
              docId: doc.id,
            };
            if (listing.status === 'active') {
              active.push(listing);
            } else if (listing.status === 'sold') {
              inactive.push(listing);
            }
          });

          setActiveListings(active);
          setInactiveListings(inactive);
        } catch (error) {
          setError('Error fetching user or listing data');
        } finally {
          setLoading(false);
        }
      }
    };

    fetchData();
  }, [user]);

  useEffect(() => {
    const fetchFeedback = async () => {
      if (userEmail) {
        try {
          // Fetch feedback where the user is the seller (received from buyers)
          const feedbackToSellerQuery = query(
            collection(db, 'feedback'),
            where('sellerEmail', '==', userEmail)
          );
          const feedbackToSellerSnapshot = await getDocs(feedbackToSellerQuery);
          const feedbackToSellerList: Feedback[] = [];
          feedbackToSellerSnapshot.forEach((doc) => {
            const data = doc.data();
            if (data.authorEmail !== userEmail) { // Filter out self-feedback
              feedbackToSellerList.push({
                buyerUsername: data.buyerUsername,
                description: data.description,
              });
            }
          });
  
          // Fetch feedback where the user is the buyer (received from sellers)
          const feedbackToBuyerQuery = query(
            collection(db, 'feedback'),
            where('buyerEmail', '==', userEmail)
          );
          const feedbackToBuyerSnapshot = await getDocs(feedbackToBuyerQuery);
          const feedbackToBuyerList: Feedback[] = [];
          feedbackToBuyerSnapshot.forEach((doc) => {
            const data = doc.data();
            if (data.authorEmail !== userEmail) { // Filter out self-feedback
              feedbackToBuyerList.push({
                buyerUsername: data.sellerUsername, // Seller who gave feedback
                description: data.description,
              });
            }
          });
  
          setFeedbacks([...feedbackToSellerList, ...feedbackToBuyerList]);
        } catch (error) {
          console.error('Error fetching feedback:', error);
        } finally {
          setLoadingFeedback(false);
        }
      }
    };
  
    fetchFeedback();
  }, [userEmail]);
  
const handleLogout = async () => {
  try {
    await AsyncStorage.removeItem('sessionUser');
    await AsyncStorage.removeItem('userEmail'); 
    await auth.signOut();
    router.push('/splash');
  } catch (error) {
    console.error('Error logging out:', error);
  }
};

  const handleListingPress = (docId: string) => {
    router.push({
      pathname: "/user/listing/listingdetails",
      params: { docId },
    });
  };

  const renderListing = ({ item }: { item: Listing }) => (
    <TouchableOpacity
      key={item.docId}  
      onPress={() => handleListingPress(item.docId)}
      style={styles.listingCard}
    >
      <Image source={{ uri: item.images[0] }} style={styles.listingImage} />
      <View style={styles.listingInfo}>
        <Text style={styles.listingTitle}>{item.title}</Text>
        <Text style={styles.listingPrice}>RM {item.price}</Text>
      </View>
    </TouchableOpacity>
  );
  

  const handleInactiveToggle = () => {
    setShowInactive(!showInactive);
  };

  return (
    <ScrollView style={styles.scrollView}>
      <View style={styles.container}>
        <View style={styles.headerContainer}>
          <Text style={styles.header}>Account</Text>
          <TouchableOpacity onPress={handleLogout}>
            <Ionicons name="log-out-outline" size={30} color="black" />
          </TouchableOpacity>
        </View>

        {loading ? (
          <Text>Loading...</Text>
        ) : error ? (
          <Text>{error}</Text>
        ) : userInfo ? (
          <>
            <View style={styles.userInfo}>
              <View style={styles.profilePictureContainer}>
                <Image
                  source={{ uri: userInfo.profilePicture || 'default-image-url' }}
                  style={styles.profilePicture}
                />
                <TouchableOpacity
                  onPress={() => router.push(`/user/account/editprofile?email=${userEmail}`)}
                  style={styles.editProfileIcon}
                >
                  <Ionicons name="pencil" size={16} color="white" />
                </TouchableOpacity>
              </View>
              <View>
                <Text style={styles.name}>{userInfo.name}</Text>
                <Text style={styles.username}>@{userInfo.username}</Text>
              </View>
            </View>

            <View style={styles.iconButtons}>
              <TouchableOpacity onPress={() => router.push('/user/plot/myplots')} style={styles.iconButton}>
                <Ionicons name="leaf-outline" size={30} color="black" />
                <Text style={styles.iconText}>My Plots</Text>
              </TouchableOpacity>
              <TouchableOpacity onPress={() => router.push('/user/account/wallet')} style={styles.iconButton}>
                <Ionicons name="wallet-outline" size={30} color="black" />
                <Text style={styles.iconText}>Wallet</Text>
              </TouchableOpacity>
              <TouchableOpacity onPress={() => router.push('/user/account/sales')} style={styles.iconButton}>
                <Ionicons name="bar-chart-outline" size={30} color="black" />
                <Text style={styles.iconText}>Sales</Text>
              </TouchableOpacity>
              <TouchableOpacity onPress={() => router.push('/user/account/purchases')} style={styles.iconButton}>
                <Ionicons name="bag-outline" size={30} color="black" />
                <Text style={styles.iconText}>Purchases</Text>
              </TouchableOpacity>
            </View>

            <View style={styles.tabs}>
              <TouchableOpacity
                style={[styles.tab, activeTab === 'Listing' && styles.activeTab]}
                onPress={() => setActiveTab('Listing')}
              >
                <Text style={styles.tabText}>Listing</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.tab, activeTab === 'Feedback' && styles.activeTab]}
                onPress={() => setActiveTab('Feedback')}
              >
                <Text style={styles.tabText}>Feedback</Text>
              </TouchableOpacity>
            </View>

            {activeTab === 'Listing' && (
              <>
                <View style={styles.listingContainer}>
                  {activeListings.length === 0 ? (
                    <Text>No active listings available.</Text>
                  ) : (
                    <ScrollView contentContainerStyle={styles.listingRow}>
                      {activeListings.map((item, index) => renderListing({ item }))}
                    </ScrollView>
                  )}
                </View>

                <TouchableOpacity onPress={handleInactiveToggle} style={styles.inactiveButton}>
                  <View style={styles.triangle}></View>
                </TouchableOpacity>

                {showInactive && (
                  <View style={styles.listingContainer}>
                    {inactiveListings.length === 0 ? (
                      <Text>No Inactive listings available.</Text>
                    ) : (
                      <ScrollView contentContainerStyle={styles.listingRow}>
                        {inactiveListings.map((item, index) => renderListing({ item }))}
                      </ScrollView>
                    )}
                  </View>
                )}
              </>
            )}

            {activeTab === 'Feedback' && (
              <View style={styles.feedbackContainer}>
                {loadingFeedback ? (
                  <Text>Loading feedback...</Text>
                ) : feedbacks.length === 0 ? (
                  <Text>No feedback available.</Text>
                ) : (
                  <>
                    <Text style={styles.sectionTitle}>From Buyers</Text>
                    {feedbacks
                      .filter((feedback) => feedback.buyerUsername !== undefined)
                      .map((feedback, index) => (
                        <View key={index} style={styles.feedbackCard}>
                          <Text style={styles.buyerUsername}>@{feedback.buyerUsername}</Text>
                          <Text style={styles.feedbackDescription}>{feedback.description}</Text>
                        </View>
                      ))}

                    <Text style={styles.sectionTitle}>From Sellers</Text>
                    {feedbacks
                      .filter((feedback) => feedback.buyerUsername === undefined)
                      .map((feedback, index) => (
                        <View key={index} style={styles.feedbackCard}>
                          <Text style={styles.buyerUsername}>@{feedback.buyerUsername}</Text>
                          <Text style={styles.feedbackDescription}>{feedback.description}</Text>
                        </View>
                      ))}
                  </>
                )}
              </View>
            )}
          </>
        ) : (
          <Text>No user data available.</Text>
        )}
      </View>
    </ScrollView>
  );
}


const styles = StyleSheet.create({
  container: {
    flexGrow: 1,
    padding: 20,
    backgroundColor: '#fff',
  },
  headerContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  header: {
    fontSize: 24,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 20,
  },
  userInfo: {
    marginBottom: 20,
    flexDirection: 'row',
    alignItems: 'center',
  },
  profilePictureContainer: {
    position: 'relative',
    marginRight: 10,
  },
  profilePicture: {
    width: 80,
    height: 80,
    borderRadius: 40,
  },
  editProfileIcon: {
    position: 'absolute',
    bottom: 0,
    right: 0,
    backgroundColor: '#007AFF',
    borderRadius: 15,
    padding: 5,
  },
  name: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  username: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
  },
  iconButtons: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginVertical: 20,
  },
  iconButton: {
    alignItems: 'center',
    flex: 1,
  },
  iconText: {
    marginTop: 5,
  },
  tabs: {
    flexDirection: 'row',
    marginBottom: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#ddd',
  },
  tab: {
    flex: 1,
    paddingVertical: 10,
    alignItems: 'center',
  },
  activeTab: {
    borderBottomWidth: 3,
    borderBottomColor: '#007AFF',
  },
  tabText: {
    fontSize: 16,
    fontWeight: 'bold',
  },
  sectionTitle: {
    fontSize: 15,
    fontWeight: 'bold',
    marginVertical: 10,
  },
  listingContainer: {
    marginBottom: 20,
  },
  listingRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  listingCard: {
    width: '48%',
    marginBottom: 10,
    backgroundColor: 'white',
    borderRadius: 10,
  },
  listingImage: {
    width: '100%',
    height: 120,
    borderTopLeftRadius: 10,
    borderTopRightRadius: 10,
  },
  listingInfo: {
    padding: 10,
  },
  listingTitle: {
    fontSize: 14,
    color: 'black',
  },
  listingPrice: {
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 5,
  },
  inactiveButton: {
    marginTop: 10,
    alignSelf: 'center',
    padding: 10,
    borderRadius: 50,
  },
  triangle: {
    width: 0,
    height: 0,
    borderLeftWidth: 10,
    borderLeftColor: 'transparent',
    borderRightWidth: 10,
    borderRightColor: 'transparent',
    borderTopWidth: 10,
    borderTopColor: '#007AFF',
  },
  feedbackContainer: {
    marginTop: 20,
    backgroundColor: 'white',
  },
  feedbackCard: {
    backgroundColor: '#fff',
    padding: 15,
    borderRadius: 8,
    marginBottom: 10,
    shadowColor: '#000',
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  buyerUsername: {
    fontWeight: 'bold',
    fontSize: 16,
    marginBottom: 5,
  },
  feedbackDescription: {
    fontSize: 14,
    color: '#555',
  },
  scrollView: {
    backgroundColor: '#fff', 
  },
  
});
