import React, { useEffect, useState } from 'react';
import { View, Text, TextInput, Button, StyleSheet, Alert, ScrollView, TouchableOpacity } from 'react-native';
import { getAuth, createUserWithEmailAndPassword } from 'firebase/auth';
import { db } from '../src/firebaseConfig';
import { collection, addDoc, getDocs, setDoc, doc, query, where } from 'firebase/firestore';
import { useRouter } from 'expo-router';
import RNPickerSelect from 'react-native-picker-select';
import { Ionicons } from '@expo/vector-icons';


const SignUp = () => {
  const [userDetails, setUserDetails] = useState({
    name: '',
    email: '',
    password: '',
    confirmPassword: '',
    phoneNo: '',
    username: '',
    location: {
      state: '',
      city: '',
      postcode: '',
      section: '',
    },
  });

  const [loading, setLoading] = useState(false);
  const [passwordError, setPasswordError] = useState('');
  const [usernameError, setUsernameError] = useState('');
  const [emailError, setEmailError] = useState('');
  const [availableStates, setAvailableStates] = useState<string[]>([]);
  const [availableCities, setAvailableCities] = useState<string[]>([]);
  const [availablePostcodes, setAvailablePostcodes] = useState<string[]>([]);
  const [availableSections, setAvailableSections] = useState<string[]>([]);
  
  const router = useRouter();

  const validateEmail = (email: string) => {
    const emailRegex = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    return emailRegex.test(email);
  };

  useEffect(() => {
    const fetchStates = async () => {
      try {
        const locationSnapshot = await getDocs(collection(db, 'location'));
        const states: string[] = [];
        locationSnapshot.forEach((doc) => {
          const state = doc.data().state;
          if (!states.includes(state)) states.push(state);
        });
        setAvailableStates(states);
      } catch (error) {
        console.error('Error fetching states:', error);
      }
    };

    fetchStates();
  }, []);

  useEffect(() => {
    if (userDetails.location.state) {
      const fetchCities = async () => {
        try {
          const citySnapshot = await getDocs(collection(db, 'location'));
          const cities: string[] = [];
          citySnapshot.forEach((doc) => {
            const city = doc.data().city;
            if (doc.data().state === userDetails.location.state && !cities.includes(city)) {
              cities.push(city);
            }
          });
          setAvailableCities(cities);
        } catch (error) {
          console.error('Error fetching cities:', error);
        }
      };

      fetchCities();
    }
  }, [userDetails.location.state]);

  useEffect(() => {
    if (userDetails.location.city) {
      const fetchPostcodes = async () => {
        try {
          const postcodeSnapshot = await getDocs(collection(db, 'location'));
          const postcodes: string[] = [];
          postcodeSnapshot.forEach((doc) => {
            const postcode = doc.data().postcode;
            if (doc.data().city === userDetails.location.city && !postcodes.includes(postcode)) {
              postcodes.push(postcode);
            }
          });
          setAvailablePostcodes(postcodes);
        } catch (error) {
          console.error('Error fetching postcodes:', error);
        }
      };

      fetchPostcodes();
    }
  }, [userDetails.location.city]);

  useEffect(() => {
    if (userDetails.location.postcode) {
      const fetchSections = async () => {
        try {
          const sectionSnapshot = await getDocs(collection(db, 'location'));
          const sections: string[] = [];
          sectionSnapshot.forEach((doc) => {
            const section = doc.data().section;
            if (doc.data().postcode === userDetails.location.postcode && !sections.includes(section)) {
              sections.push(section);
            }
          });
          setAvailableSections(sections);
        } catch (error) {
          console.error('Error fetching sections:', error);
        }
      };

      fetchSections();
    }
  }, [userDetails.location.postcode]);

  const checkUsernameUniqueness = async (username: string) => {
    const q = query(collection(db, 'user'), where('username', '==', username));
    const querySnapshot = await getDocs(q);
    return querySnapshot.empty;
  };

  const checkEmailUniqueness = async (email: string) => {
    const q = query(collection(db, 'user'), where('email', '==', email));
    const querySnapshot = await getDocs(q);
    return querySnapshot.empty;
  };

  const handleSubmit = async () => {
    if (loading) return;
    setLoading(true);
    setPasswordError('');
    setUsernameError('');
    setEmailError('');
  
    if (!validateEmail(userDetails.email)) {
      setEmailError('Invalid email format');
      setLoading(false);
      return;
    }
  
    const isEmailUnique = await checkEmailUniqueness(userDetails.email);
    if (!isEmailUnique) {
      setEmailError('Email is already registered');
      setLoading(false);
      return;
    }
  
    const isUsernameUnique = await checkUsernameUniqueness(userDetails.username);
    if (!isUsernameUnique) {
      setUsernameError('Username is already taken');
      setLoading(false);
      return;
    }
  
    if (userDetails.password !== userDetails.confirmPassword) {
      setPasswordError('Passwords do not match');
      setLoading(false);
      return;
    }
  
    try {
      const auth = getAuth();
      const userCredential = await createUserWithEmailAndPassword(auth, userDetails.email, userDetails.password);
      const user = userCredential.user;
  
      await setDoc(doc(db, 'user', user.uid), {
        name: userDetails.name,
        email: userDetails.email,
        phoneno: userDetails.phoneNo,
        username: userDetails.username,
        location: userDetails.location,
      });
  
      Alert.alert('Success', 'Sign up successfully, login to your account', [
        { text: 'OK', onPress: () => router.push('/(auth)/login') },
      ]);

    } catch (error) {
      console.error('Error signing up:', error);
      Alert.alert('Error', 'There was an issue with your sign-up. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()}>
          <Ionicons name="arrow-back" size={24} color="black" />
        </TouchableOpacity>
        <Text style={styles.title}>Sign Up</Text>
      </View>


      <Text style={styles.label}>Name</Text>
      <TextInput
        value={userDetails.name}
        onChangeText={(text) => setUserDetails({ ...userDetails, name: text })}
        placeholder="Full Name"
        style={styles.input}
      />

      <Text style={styles.label}>Email</Text>
      <TextInput
        value={userDetails.email}
        onChangeText={(text) => setUserDetails({ ...userDetails, email: text })}
        placeholder="Email"
        style={styles.input}
        keyboardType="email-address"
      />
      {emailError ? <Text style={styles.errorText}>{emailError}</Text> : null}

      <Text style={styles.label}>Password</Text>
      <TextInput
        value={userDetails.password}
        onChangeText={(text) => setUserDetails({ ...userDetails, password: text })}
        placeholder="Password"
        style={styles.input}
        secureTextEntry
      />

      <Text style={styles.label}>Confirm Password</Text>
      <TextInput
        value={userDetails.confirmPassword}
        onChangeText={(text) => setUserDetails({ ...userDetails, confirmPassword: text })}
        placeholder="Confirm Password"
        style={styles.input}
        secureTextEntry
      />
      {passwordError ? <Text style={styles.errorText}>{passwordError}</Text> : null}

      <Text style={styles.label}>Username</Text>
      <TextInput
        value={userDetails.username}
        onChangeText={(text) => setUserDetails({ ...userDetails, username: text })}
        placeholder="Username"
        style={styles.input}
      />
      {usernameError ? <Text style={styles.errorText}>{usernameError}</Text> : null}

      <Text style={styles.label}>Phone Number</Text>
      <TextInput
        value={userDetails.phoneNo}
        onChangeText={(text) => setUserDetails({ ...userDetails, phoneNo: text })}
        placeholder="Phone Number"
        keyboardType="numeric"
        style={styles.input}
      />

      <View style={styles.locationContainer}>
        <RNPickerSelect
          onValueChange={(value) => setUserDetails({ ...userDetails, location: { ...userDetails.location, state: value } })}
          items={availableStates.map(state => ({ label: state, value: state }))}
          placeholder={{ label: 'Select State', value: null }}
        />
        <RNPickerSelect
          onValueChange={(value) => setUserDetails({ ...userDetails, location: { ...userDetails.location, city: value } })}
          items={availableCities.map(city => ({ label: city, value: city }))}
          placeholder={{ label: 'Select City', value: null }}
        />
        <RNPickerSelect
          onValueChange={(value) => setUserDetails({ ...userDetails, location: { ...userDetails.location, postcode: value } })}
          items={availablePostcodes.map((postcode) => ({ label: String(postcode), value: postcode }))}
          placeholder={{ label: 'Select Postcode', value: null }}
        />
        <RNPickerSelect
          onValueChange={(value) => setUserDetails({ ...userDetails, location: { ...userDetails.location, section: value } })}
          items={availableSections.map(section => ({ label: section, value: section }))}
          placeholder={{ label: 'Select Section', value: null }}
        />
      </View>

      <TouchableOpacity
        style={[styles.button, loading && styles.buttonDisabled]}
        onPress={handleSubmit}
        disabled={loading}
      >
        <Text style={styles.buttonText}>{loading ? 'Signing Up...' : 'Sign Up'}</Text>
      </TouchableOpacity>

      <View style={styles.loginLinkContainer}>
        <Text style={styles.loginLinkText}>Already have an account? </Text>
        <TouchableOpacity onPress={() => router.push('/(auth)/login')}>
          <Text style={styles.loginLink}>Login</Text>
        </TouchableOpacity>
      </View>

    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: 'white',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 20,
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
    marginLeft: 10,
  },
  label: {
    fontSize: 14,
    marginVertical: 8,
  },
  input: {
    padding: 10,
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 5,
    fontSize: 16,
    marginBottom: 8,
  },
  errorText: {
    color: 'red',
    fontSize: 12,
  },
  locationContainer: {
    marginVertical: 16,
  },
  backButton: {
    paddingLeft: 10,
    paddingTop: 5,
  },
  backButtonText: {
    fontSize: 16,
    color: '#007bff',
  },
  loginLinkContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    marginTop: 15,
  },
  loginLinkText: {
    fontSize: 12,
  },
  loginLink: {
    color: '#007bff',
    fontSize: 12,
    fontStyle: 'italic',
  },
  button: {
    width: '100%',
    height: 50,
    backgroundColor: '#945e25',
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 10,
    marginBottom: 30,
  },
  buttonText: {
    color: '#fff',
    fontWeight: 'bold',
  },
  buttonDisabled: {
    backgroundColor: '#bca693',
  },
});

export default SignUp;
