import React, { useState } from 'react';
import { View, Text, TextInput, Button, StyleSheet, Image, TouchableOpacity, Alert } from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import { db } from '../../src/firebaseConfig'; // Adjust import according to your setup
import { collection, addDoc } from 'firebase/firestore';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';

const AddNewAds = () => {
  const [adTitle, setAdTitle] = useState('');
  const [adImage, setAdImage] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const router = useRouter();

  const handleImageChange = async () => {
    const permissionResult = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (permissionResult.granted) {
      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        quality: 1,
      });

      if (!result.canceled && result.assets && result.assets.length > 0) {
        const imageUri = result.assets[0].uri;
        setAdImage(imageUri); // Update adImage state with the selected image URI
      }
    } else {
      Alert.alert('Permission', 'Permission to access media library is required!');
    }
  };

  const handleSubmit = async () => {
    if (loading) return;
    setLoading(true);

    try {
      const newAdData = {
        adTitle,
        adImage, // Store the selected image URI
      };

      // Save to Firestore
      await addDoc(collection(db, 'ads'), newAdData);

      Alert.alert('Success', 'Ad added successfully!');
      router.push('/admin/marketing/manageads'); // Navigate to the ads list page or reset the form
    } catch (error) {
      console.error('Error adding ad:', error);
      Alert.alert('Error', 'There was an issue adding the ad.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()}>
          <Ionicons name="arrow-back" size={24} color="black" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Add New Ad</Text>
      </View>

      <View style={styles.inputContainer}>
        <Text style={styles.label}>Ad Title</Text>
        <TextInput
          value={adTitle}
          onChangeText={setAdTitle}
          placeholder="Enter Ad Title"
          style={styles.input}
        />
      </View>

      <TouchableOpacity onPress={handleImageChange} style={styles.imageContainer}>
        {adImage ? (
          <Image source={{ uri: adImage }} style={styles.adImage} />
        ) : (
          <Text style={styles.addImageText}>Add Ad Image</Text>
        )}
      </TouchableOpacity>

      <Button title={loading ? 'Saving...' : 'Add Ad'} onPress={handleSubmit} disabled={loading} />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#fff',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 20,
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    marginLeft: 10,
  },
  inputContainer: {
    marginVertical: 10,
  },
  label: {
    fontSize: 16,
    marginBottom: 8,
  },
  input: {
    borderWidth: 1,
    borderColor: '#ccc',
    padding: 10,
    borderRadius: 5,
    fontSize: 16,
  },
  imageContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 10,
    height: 200,
    width: '100%',
    marginBottom: 20,
  },
  adImage: {
    width: '100%',
    height: '100%',
    borderRadius: 10,
  },
  addImageText: {
    color: '#888',
    fontSize: 16,
  },
});

export default AddNewAds;
