import React, { useState, useEffect } from 'react';
import { View, Text, FlatList, TextInput, TouchableOpacity, StyleSheet, ScrollView } from 'react-native';
import { db } from '../../src/firebaseConfig';  // Import your Firestore config
import { collection, getDocs, query, where } from 'firebase/firestore';
import { useRouter, useLocalSearchParams } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';

interface PlotAreaData {
  id: string;
  name: string;
  description: string;
}

const ArchivedPlotAreas = () => {
  const { state, city, postcode, section } = useLocalSearchParams(); 
  const router = useRouter();
  const [activePlotAreas, setActivePlotAreas] = useState<PlotAreaData[]>([]);  
  const [inactivePlotAreas, setInactivePlotAreas] = useState<PlotAreaData[]>([]);  
  const [searchText, setSearchText] = useState('');  
  const [isActiveTab, setIsActiveTab] = useState(true); 

  useEffect(() => {
    const fetchActivePlotAreas = async () => {
      try {
        let plotAreaQuery = query(collection(db, 'plotarea'));  

        if (state) plotAreaQuery = query(plotAreaQuery, where('location.state', '==', state));
        if (city) plotAreaQuery = query(plotAreaQuery, where('location.city', '==', city));
        if (postcode) plotAreaQuery = query(plotAreaQuery, where('location.postcode', '==', parseInt(postcode as string)));
        if (section) plotAreaQuery = query(plotAreaQuery, where('location.section', '==', section));

        const plotAreaSnapshot = await getDocs(plotAreaQuery);
        const fetchedPlotAreas = plotAreaSnapshot.docs.map((doc) => ({
          id: doc.id,
          name: doc.data().name,
          description: doc.data().description || '',
        }));
        setActivePlotAreas(fetchedPlotAreas);
      } catch (error) {
        console.error('Error fetching active plot areas:', error);
      }
    };

    const fetchInactivePlotAreas = async () => {
      try {
        let plotAreaQuery = query(collection(db, 'archivedplotarea'));  

        if (state) plotAreaQuery = query(plotAreaQuery, where('location.state', '==', state));
        if (city) plotAreaQuery = query(plotAreaQuery, where('location.city', '==', city));
        if (postcode) plotAreaQuery = query(plotAreaQuery, where('location.postcode', '==', parseInt(postcode as string)));
        if (section) plotAreaQuery = query(plotAreaQuery, where('location.section', '==', section));

        const plotAreaSnapshot = await getDocs(plotAreaQuery);
        const fetchedPlotAreas = plotAreaSnapshot.docs.map((doc) => ({
          id: doc.id,
          name: doc.data().name,
          description: doc.data().description || '',
        }));
        setInactivePlotAreas(fetchedPlotAreas);
      } catch (error) {
        console.error('Error fetching inactive plot areas:', error);
      }
    };

    fetchActivePlotAreas();
    fetchInactivePlotAreas();
  }, [state, city, postcode, section]);

  const filteredPlotAreas = (plotAreas: PlotAreaData[]) =>
    plotAreas.filter((plotArea) =>
      (plotArea.name?.toLowerCase() || "").includes(searchText.toLowerCase()) ||
      (plotArea.id?.toLowerCase() || "").includes(searchText.toLowerCase()) ||
      (plotArea.description?.toLowerCase() || "").includes(searchText.toLowerCase())
    );

  const toggleTab = (isActive: boolean) => {
    setIsActiveTab(isActive);
  };

  const renderPlotItem = ({ item }: { item: PlotAreaData }) => (
    <TouchableOpacity
      key={item.id}
      onPress={() => router.push(`/admin/plots/archivedplotareadetails?id=${item.id}`)}
      style={styles.plotItem}
    >
      <Text style={styles.plotId}>ID: {item.id}</Text>
      <Text style={styles.plotName}>{item.name}</Text>
      <Text style={styles.plotDescription}>{item.description}</Text>
    </TouchableOpacity>
  );

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.push('/admin/plots/manageplots')}>
          <Ionicons name="arrow-back" size={24} color="#000" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Archived Plot Areas</Text>
      </View>

      <View style={styles.tabContainer}>
        <TouchableOpacity
          style={[styles.tab, isActiveTab && styles.activeTab]}
          onPress={() => toggleTab(true)}
        >
          <Text style={[styles.tabText, isActiveTab && styles.activeTabText]}>Active</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.tab, !isActiveTab && styles.inactiveTab]}
          onPress={() => toggleTab(false)}
        >
          <Text style={[styles.tabText, !isActiveTab && styles.inactiveTabText]}>Inactive</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.searchContainer}>
        <TextInput
          style={styles.searchInput}
          placeholder="Search by name, ID, or description..."
          value={searchText}
          onChangeText={setSearchText}
        />
      </View>

      <FlatList
        data={isActiveTab ? filteredPlotAreas(activePlotAreas) : filteredPlotAreas(inactivePlotAreas)}
        renderItem={renderPlotItem}
        keyExtractor={(item) => item.id}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#fff',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 20,
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    marginLeft: 10,
  },
  backButton: {
    padding: 5,
  },
  tabContainer: {
    flexDirection: 'row',
    width: '100%',
    marginVertical: 10,
    justifyContent: 'space-between',
  },
  tab: {
    flex: 1,
    paddingVertical: 10,
    alignItems: 'center',
    justifyContent: 'center',
    borderBottomWidth: 2,
    borderBottomColor: '#ccc',
  },
  activeTab: {
    backgroundColor: '#007BFF',
  },
  inactiveTab: {
    backgroundColor: '#f0f0f0',
  },
  tabText: {
    fontSize: 16,
    color: '#555',
  },
  activeTabText: {
    color: '#fff',
  },
  inactiveTabText: {
    color: '#333',
  },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginVertical: 10,
  },
  searchInput: {
    flex: 1,
    height: 40,
    borderColor: '#ccc',
    borderWidth: 1,
    paddingLeft: 8,
    marginRight: 10,
  },
  plotItem: {
    padding: 15,
    backgroundColor: '#f9f9f9',
    marginVertical: 5,
    borderRadius: 5,
  },
  plotId: {
    fontSize: 16,
    color: '#555',
  },
  plotName: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  plotDescription: {
    fontSize: 14,
    color: '#777',
  },
  scrollView: {
    paddingBottom: 20,  
  },
});

export default ArchivedPlotAreas;
