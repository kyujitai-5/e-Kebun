import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Modal, Image, ScrollView, Alert, ActivityIndicator } from 'react-native';
import { useRouter, useLocalSearchParams } from 'expo-router';
import { db, auth } from '../../src/firebaseConfig';
import { doc, getDoc, updateDoc, addDoc, collection, query, where, getDocs, deleteDoc } from 'firebase/firestore';
import { Ionicons } from '@expo/vector-icons';
import { Linking } from 'react-native';


export default function ListingDetails() {
  const router = useRouter();
  const { docId } = useLocalSearchParams(); 
  const currentUser = auth.currentUser;

  const [listing, setListing] = useState<any | null>(null);
  const [isOwner, setIsOwner] = useState(false);
  const [menuVisible, setMenuVisible] = useState(false);
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [userLocation, setUserLocation] = useState<any | null>(null);
  const [cart, setCart] = useState<any[]>([]); 
  const [username, setUsername] = useState<string | null>(null); // State for username
  const [profilePicture, setProfilePicture] = useState<string | null>(null); // State for profile picture
  const [phoneno, setPhoneno] = useState<string | null>(null); // State for username

  useEffect(() => {
    const fetchCart = async () => {
      try {
        const cartQuery = query(collection(db, 'listingcart'), where('email', '==', currentUser?.email));
        const cartSnapshot = await getDocs(cartQuery);
  
        const cartItems = cartSnapshot.docs.map(doc => doc.data());
        setCart(cartItems);  
      } catch (error) {
        console.error('Error fetching cart items:', error);
      }
    };
  
    fetchCart();
  }, [currentUser]); 
  

  useEffect(() => {
    if (!docId) {
      console.error('Listing ID is missing!');
      return;
    }
  
    const fetchListingDetails = async () => {
      try {
        const listingDoc = await getDoc(doc(db, 'listing', docId as string));
        if (listingDoc.exists()) {
          const data = listingDoc.data();
          console.log('Listing Data:', data); 
  
          setListing(data);
    
          // Check ownership
          if (data.email === currentUser?.email) {
            setIsOwner(true);
          }
  
          // Fetch user's location, username, and profile picture based on email
          if (data.email) {
            const userQuery = query(collection(db, 'user'), where('email', '==', data.email));
            const querySnapshot = await getDocs(userQuery);
    
            if (!querySnapshot.empty) {
              const userDoc = querySnapshot.docs[0];
              const userData = userDoc.data();
              if (userData) {
                if (userData.location) {
                  setUserLocation(userData.location);
                }
    
                const username = userData.username; 
                const profilePicture = userData.profilePicture;  
                const phoneno = userData.phoneno;
  
                setUsername(username);  
                setProfilePicture(profilePicture);  
                setPhoneno(phoneno); 
              }
            }
          }
        } else {
          Alert.alert('Error', 'Listing not found.');
        }
      } catch (error) {
        console.error('Error fetching listing details:', error);
      }
    };
  
    fetchListingDetails();
  }, [docId, currentUser]);  
  
  const handleAddToCart = async () => {
    // Check if the item already exists in the cart
    const itemInCart = cart.find((item) => item.listingId === docId);
    
    if (itemInCart) {
      Alert.alert('Item already in Cart', 'This item is already in your cart.');
    } else {
      try {
        await addDoc(collection(db, 'listingcart'), {
          email: currentUser?.email,
          listingId: docId,
        });
  
        setCart([...cart, { listingId: docId }]);
  
        Alert.alert('Success', 'Item added to cart.');
      } catch (error) {
        console.error('Error adding listing to cart:', error);
        Alert.alert('Error', 'There was an issue adding the item to your cart.');
      }
    }
  };
  

  const handleDeleteListing = () => {
    Alert.alert(
      "Confirm Deletion",
      "Are you sure you want to delete this listing?",
      [
        {
          text: "Cancel",
          style: "cancel",
        },
        {
          text: "Delete",
          style: "destructive",
          onPress: async () => {
            try {
              await deleteDoc(doc(db, 'listing', docId as string));
              Alert.alert("Success", "Listing deleted successfully.");
              router.back();
            } catch (error) {
              console.error("Error deleting listing:", error);
              Alert.alert("Error", "There was an issue deleting the listing.");
            }
          },
        },
      ]
    );
  };

  if (!listing) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#007bff" />
        <Text>Loading listing details...</Text>
      </View>
    );
  }

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()}>
          <Ionicons name="arrow-back" size={30} color="#000" />
        </TouchableOpacity>
        <Text style={styles.title}>Listing Details</Text>

        {!isOwner && (
          <TouchableOpacity onPress={() => router.push('/user/listing/listingcart')}>
            <Ionicons name="cart-outline" size={30} color="#000" />
          </TouchableOpacity>
        )}

        {isOwner && (
          <TouchableOpacity onPress={() => setMenuVisible(true)}>
            <Ionicons name="ellipsis-horizontal" size={30} color="#000" />
          </TouchableOpacity>
        )}
      </View>

      <View style={styles.imageSlider}>
        <ScrollView
          horizontal
          pagingEnabled
          showsHorizontalScrollIndicator={false}
          style={styles.imageSliderContainer}
        >
          {listing.images?.map((img: string, index: number) => (
            <TouchableOpacity key={index} onPress={() => setSelectedImage(img)}>
              <Image source={{ uri: img }} style={styles.image} />
            </TouchableOpacity>
          ))}
        </ScrollView>
      </View>

      {selectedImage && (
        <Modal visible transparent animationType="fade">
          <View style={styles.modalContainer}>
            <TouchableOpacity
              style={styles.modalCloseButton}
              onPress={() => setSelectedImage(null)}
            >
              <Ionicons name="close" size={30} color="#fff" />
            </TouchableOpacity>
            <Image source={{ uri: selectedImage }} style={styles.modalImage} />
          </View>
        </Modal>
      )}

      <View style={styles.detailsSection}>
        <Text style={styles.name}>{listing.title}</Text>
        <Text style={styles.description}>{listing.description}</Text>
        <Text style={styles.price}>RM {listing.price}</Text>

      <View style={styles.profileSection}>
        <Image source={{ uri: profilePicture || undefined }} style={styles.profilePic} />
        <View style={styles.profileInfo}>
          <TouchableOpacity
            onPress={() => router.push({
              pathname: '/user/account/visitorprofile',  
              params: { email: listing.email }   
            })}
          >
            <Text style={styles.username}>@{username}</Text>
          </TouchableOpacity>          
          {userLocation ? (
            <TouchableOpacity
              onPress={() => {
                const address = `${userLocation?.section}, ${userLocation?.postcode}, ${userLocation?.city}, ${userLocation?.state}`;
                const encodedAddress = encodeURIComponent(address); 
                const mapsUrl = `https://www.google.com/maps/search/?q=${encodedAddress}`; 

                Linking.openURL(mapsUrl);
              }}
            >
              <Text style={styles.location}>
                <Ionicons name="location-outline" size={20} color="#007bff" style={styles.locationIcon} />
                {userLocation?.section}, {userLocation?.postcode}, {userLocation?.city}, {userLocation?.state}
              </Text>
            </TouchableOpacity>
          ) : (
            <Text style={styles.location}>Loading location...</Text>
          )}

        </View>

        {!isOwner && (
          <TouchableOpacity
            style={styles.chatIcon}
            onPress={() => {
              const phoneNumber = phoneno; 
              console.log('Phone Number:', phoneNumber);

              if (phoneNumber) {
                const whatsappUrl = `https://wa.me/6${phoneNumber}`;
                Linking.openURL(whatsappUrl).catch(() => {
                  Alert.alert('Error', 'Unable to open WhatsApp. Please ensure it is installed on your device.');
                });
              } else {
                Alert.alert('Error', 'Phone number is unavailable.');
              }
            }}
          >
            <Ionicons name="chatbubble-ellipses-outline" size={30} color="#007bff" />
          </TouchableOpacity>
        )}
      </View>
    </View>

    {!isOwner && (
        <View style={styles.buttonContainer}>
          <TouchableOpacity style={styles.button} onPress={handleAddToCart}>
            <Text style={styles.buttonText}>Add to Cart</Text>
          </TouchableOpacity>
        </View>
      )}

      <Modal transparent visible={menuVisible} animationType="slide">
        <View style={styles.menuContainer}>
          <TouchableOpacity
            style={styles.menuOption}
            onPress={() => router.push({
              pathname: '/user/listing/editlisting',
              params: { docId: docId },
            })}
          >
            <Text style={styles.menuOptionText}>Edit Listing</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.menuOption} onPress={handleDeleteListing}>
            <Text style={[styles.menuOptionText, styles.danger]}>Delete Listing</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.menuOption} onPress={() => setMenuVisible(false)}>
            <Text style={styles.menuOptionText}>Cancel</Text>
          </TouchableOpacity>
        </View>
      </Modal>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flexGrow: 1,
    backgroundColor: '#fff',
    paddingHorizontal: 20,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginVertical: 20,
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
  },
  imageSlider: {
    marginVertical: 10,
  },
  imageSliderContainer: {
    flexDirection: 'row',
  },
  image: {
    width: 300,
    height: 300,
    borderRadius: 10,
    marginHorizontal: 10,
  },
  modalContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.8)',
  },
  modalCloseButton: {
    position: 'absolute',
    top: 50,
    right: 20,
  },
  modalImage: {
    width: '90%',
    height: '70%',
    resizeMode: 'contain',
  },
  detailsSection: {
    marginVertical: 20,
  },
  name: {
    fontSize: 20,
    fontWeight: 'bold',
  },
  description: {
    fontSize: 18,
    color: '#555',
    marginVertical: 10,
  },
  price: {
    fontSize: 25,
    fontWeight: 'bold',
    color: 'black',
  },
  location: {
    flexDirection: 'row',
    alignItems: 'center',
    fontSize: 16,
  },
  locationIcon: {
    marginRight: 10,
  },
  profileSection: {
    flexDirection: 'row',
    alignItems: 'center',
    marginVertical: 20,
  },
  profilePic: {
    width: 50,
    height: 50,
    borderRadius: 25,
  },
  profileInfo: {
    marginLeft: 10,
    flex: 1,
  },
  username: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 5,
  },
  address: {
    fontSize: 16,
    color: '#777',
  },
  chatIcon: {
    marginLeft: 10,
  },
  buttonsContainer: {
    marginVertical: 20,
  },
  button: {
    backgroundColor: '#007bff',
    padding: 15,
    borderRadius: 10,
    alignItems: 'center',
    justifyContent: 'center',
  },
  buttonText: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold',
  },
  menuContainer: {
    backgroundColor: '#fff',
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    padding: 20,
    position: 'absolute',
    bottom: 0,
    width: '100%',
  },
  menuOption: {
    paddingVertical: 15,
    borderBottomWidth: 1,
    borderBottomColor: '#ccc',
  },
  menuOptionText: {
    fontSize: 18,
  },
  danger: {
    color: 'red',
  },
  buttonContainer: {
    paddingVertical: 15,
  },
  
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
});
