import React, { useState, useEffect } from 'react';
import { View, Text, FlatList, Modal, TouchableOpacity, StyleSheet, Image } from 'react-native';
import { db } from '../../src/firebaseConfig';
import { collection, getDocs } from 'firebase/firestore';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons'; 

interface ReportedArea {
  id: string; 
  createdAt: string; 
  description: string;
  images: string[]; 
}

const ReportedAreas = () => {
  const router = useRouter();
  const [reportedAreas, setReportedAreas] = useState<ReportedArea[]>([]);
  const [modalVisible, setModalVisible] = useState(false);
  const [selectedArea, setSelectedArea] = useState<ReportedArea | null>(null);

  useEffect(() => {
    const fetchReportedAreas = async () => {
      try {
        const reportCollection = collection(db, 'reportarea');
        const reportSnapshot = await getDocs(reportCollection);

        const fetchedReportedAreas = reportSnapshot.docs.map((doc) => {
          const data = doc.data();
          const createdAt = data.createdAt ? new Date(data.createdAt.seconds * 1000).toLocaleString() : ''; 

          return {
            id: doc.id,
            createdAt: createdAt,
            description: data.description || '',
            images: data.images || [],
          };
        });

        setReportedAreas(fetchedReportedAreas);
      } catch (error) {
        console.error('Error fetching reported areas:', error);
      }
    };

    fetchReportedAreas();
  }, []);

  const handleItemPress = (area: ReportedArea) => {
    setSelectedArea(area);
    setModalVisible(true);
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()}>
          <Ionicons name="arrow-back" size={24} color="black" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Reported Areas</Text>
      </View>

      <FlatList
        data={reportedAreas}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <TouchableOpacity
            onPress={() => handleItemPress(item)}
            style={styles.areaItem}
          >
            <Text style={styles.areaId}>ID: {item.id}</Text>
            <Text style={styles.areaDate}>{item.createdAt}</Text> 
          </TouchableOpacity>
        )}
      />


      {selectedArea && (
        <Modal
          visible={modalVisible}
          animationType="fade"
          transparent={true}
          onRequestClose={() => setModalVisible(false)}
        >
          <View style={styles.modalContainer}>
            <View style={styles.modalContent}>
              <TouchableOpacity onPress={() => setModalVisible(false)} style={styles.closeButton}>
                <Ionicons name="close" size={24} color="black" />
              </TouchableOpacity>

              <Text style={styles.modalDescription}>{selectedArea.description}</Text>
              {selectedArea.images.map((image, index) => (
                <Image
                  key={index}
                  source={{ uri: image }}
                  style={styles.modalImage}
                />
              ))}
            </View>
          </View>
        </Modal>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#fff',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 20,
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    marginLeft: 10,
  },
  areaItem: {
    padding: 15,
    backgroundColor: '#f9f9f9',
    marginVertical: 5,
    borderRadius: 5,
  },
  areaId: {
    fontSize: 14,
    color: '#777',
  },
  areaDate: {
    fontSize: 12,
    color: '#555',
  },
  modalContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  modalContent: {
    width: '80%',
    backgroundColor: '#fff',
    padding: 20,
    borderRadius: 10,
    alignItems: 'center',
  },
  closeButton: {
    alignSelf: 'flex-end',
  },
  modalDescription: {
    fontSize: 16,
    marginBottom: 10,
    textAlign: 'center',
  },
  modalImage: {
    width: 200,
    height: 200,
    marginVertical: 5,
  },
});

export default ReportedAreas;
