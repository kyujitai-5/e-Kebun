import React, { useEffect, useState } from 'react';
import { StyleSheet, View, Text, TouchableOpacity, FlatList, Alert } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import { collection, query, where, getDocs, doc, getDoc, updateDoc, addDoc } from 'firebase/firestore';
import { getAuth } from 'firebase/auth'; 
import { db } from '../../src/firebaseConfig';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';

interface Transaction {
  id: string;
  transactionDate: string;
  transactionTime: string;
  bank: string;
  total: number;
  isPlotRelated: boolean;
  transactionType: string;
}

export default function Wallet() {
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [email, setEmail] = useState<string | null>(null);
  const router = useRouter();

  useEffect(() => {
    const fetchTransactions = async () => {
      try {
        const auth = getAuth();
        const user = auth.currentUser;

        if (user) {
          const userUid = user.uid; 

          const userDoc = await getDoc(doc(db, 'user', userUid));
          if (userDoc.exists()) {
            setEmail(userDoc.data().email); 
          }

          if (email) {
            const transactionQuery = query(
              collection(db, 'transactions'),
              where('email', '==', email)
            );
            const transactionSnapshots = await getDocs(transactionQuery);

            const fetchedTransactions: Transaction[] = transactionSnapshots.docs.map((doc) => {
              const data = doc.data();
              return {
                id: doc.id,
                transactionDate: data.transactionDate || 'N/A',
                transactionTime: data.transactionTime || 'N/A',
                bank: data.bank || 'Unknown Bank',
                total: data.total || 0,
                isPlotRelated: data.isPlotRelated || false,
                transactionType: data.transactionType || 'N/A', 
              };
            });

            fetchedTransactions.sort((a, b) => new Date(b.transactionDate).getTime() - new Date(a.transactionDate).getTime());

            setTransactions(fetchedTransactions);
          }
        }
      } catch (error) {
        console.error('Error fetching transactions:', error);
      }
    };

    fetchTransactions();
  }, [email]); 

  useEffect(() => {
    const fetchUserDetails = async () => {
      try {
        const auth = getAuth();
        const user = auth.currentUser;
  
        if (user) {
          const userUid = user.uid; 
  
          const userDoc = await getDoc(doc(db, 'user', userUid));
          if (userDoc.exists()) {
            const userData = userDoc.data();
            setEmail(userData.email); 
  
            const walletBalance = userData.wallet || 0; 
            setWalletBalance(walletBalance); 
          }
        }
      } catch (error) {
        console.error('Error fetching user details:', error);
      }
    };
  
    fetchUserDetails();
  }, []); 
  
  const handleWithdraw = () => {
    Alert.alert(
      'Withdraw Money',
      'Withdrawn money will be credited to your TnG wallet via your phone number.',
      [
        {
          text: 'Cancel',
          style: 'cancel',
        },
        {
          text: 'Confirm Transfer',
          onPress: async () => {
            try {
              const auth = getAuth();
              const user = auth.currentUser;
              if (user) {
                const userUid = user.uid;
                const userDocRef = doc(db, 'user', userUid);
                const userDoc = await getDoc(userDocRef);
  
                if (userDoc.exists()) {
                  const userData = userDoc.data();
                  const username = userData.username || ''; 
  
                  const transactionData = {
                    bank: 'TnG',
                    email: userData.email,
                    total: walletBalance,
                    transactionDate: new Date().toISOString(), 
                    transactionType: 'Withdraw',
                    username: username,
                  };
  
                  await addDoc(collection(db, 'transactions'), transactionData);
  
                  // Reset the wallet balance
                  await updateDoc(userDocRef, { wallet: 0 });
                  setWalletBalance(0); 
  
                  Alert.alert('Withdrawal Success', 'Your balance has been successfully withdrawn.');
                }
              }
            } catch (error) {
              console.error('Error processing withdrawal:', error);
              Alert.alert('Error', 'There was an error processing the withdrawal.');
            }
          },
        },
      ]
    );
  };
  
  const [walletBalance, setWalletBalance] = useState<number>(0); 

  const formatDate = (dateString: string) => {
    const date = new Date(dateString); 

    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0'); 
    const day = String(date.getDate()).padStart(2, '0');
    const hours = String(date.getHours()).padStart(2, '0');
    const minutes = String(date.getMinutes()).padStart(2, '0');
    const seconds = String(date.getSeconds()).padStart(2, '0');

    return `${day}-${month}-${year} ${hours}:${minutes}:${seconds}`;
  };

  const renderTransactionItem = ({ item }: { item: Transaction }) => (
    <View style={styles.transactionItem}>
      <View style={styles.transactionLeft}>
        {item.transactionType === 'Plot' ? (
          <Icon name="tree" size={24} color="brown" style={styles.icon} />
        ) : item.transactionType === 'Listing' ? (
          <Icon name="leaf" size={24} color="green" style={styles.icon} />
        ) : item.transactionType === 'Withdraw' ? (
          <Icon name="bank" size={24} color="maroon" style={styles.icon} />
        )  : (
          <Ionicons name="cash" size={24} color="gray" style={styles.icon} />
        )}
        <View>
          <Text style={styles.transactionId}>Transaction ID: {item.id}</Text>
          <Text style={styles.transactionDetails}>
            {formatDate(item.transactionDate)} 
          </Text>
          <Text style={styles.transactionDetails}>Bank: {item.bank}</Text>
          <Text style={styles.transactionDetails}>
            Transaction Type: {item.transactionType}
          </Text>
        </View>
      </View>
      <Text style = {styles.transactionAmount}>RM {item.total.toFixed(2)}</Text>
    </View>
  );  

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()}>
          <Ionicons name="arrow-back" size={24} color="black" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Wallet</Text>
      </View>

    <View style={styles.balanceContainer}>
      <View style={styles.balanceTextContainer}>
        <Ionicons name="wallet" size={24} color="blue" style={styles.icon} />
        <View style={styles.balanceDetails}>
          <Text style={styles.balanceText}>Balance</Text>
          <Text style={styles.balanceAmount}>
            RM {walletBalance.toFixed(2)} 
          </Text>
        </View>
      </View>
      <TouchableOpacity style={styles.withdrawButton} onPress={handleWithdraw}>
        <Text style={styles.buttonText}>Withdraw</Text>
      </TouchableOpacity>
    </View>

      <FlatList
        data={transactions}
        renderItem={renderTransactionItem}
        keyExtractor={(item) => item.id}
        contentContainerStyle={styles.transactionList}
        ListEmptyComponent={
          <Text style={styles.emptyText}>No transactions found.</Text>
        }
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f9f9f9',
    padding: 20,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 20,
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    marginLeft: 10,
  },

  balanceDetails: {
    marginLeft: 10,
  },
  balanceText: {
    fontSize: 16,
    color: '#555',
  },
  balanceAmount: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#000',
  },
  transactionList: {
    paddingBottom: 20,
  },
  transactionItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: '#fff',
    padding: 15,
    borderRadius: 8,
    marginBottom: 10,
    shadowColor: '#000',
    shadowOpacity: 0.1,
    shadowRadius: 5,
    shadowOffset: { width: 0, height: 2 },
  },
  transactionLeft: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  icon: {
    marginRight: 10,
  },
  transactionId: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#333',
    marginLeft: 15,

  },
  transactionDetails: {
    fontSize: 12,
    marginLeft: 15,
    color: '#555',
  },
  transactionAmount: {
    fontSize: 16,
    fontWeight: 'bold',
    position: 'absolute',  
    bottom: 10,  
    right: 10,  
  },
  emptyText: {
    textAlign: 'center',
    color: '#999',
    marginTop: 20,
  },

  balanceContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#f5f5f5',
    borderRadius: 8,
    padding: 15,
    marginBottom: 20,
    justifyContent: 'space-between',  
  },
  balanceTextContainer: {
    flexDirection: 'row',
    alignItems: 'center',  
  },
  withdrawButton: {
    padding: 10,
    backgroundColor: 'maroon',
    borderRadius: 5,
    alignItems: 'center', 
  },
  buttonText: {
    color: '#fff',
    fontSize: 16,
  }
});
