import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, Alert, ScrollView, Image } from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import { db } from '../../src/firebaseConfig';
import { collection, addDoc } from 'firebase/firestore';
import { Ionicons } from '@expo/vector-icons';
import { useRouter } from 'expo-router'; 



const ReportArea = () => {
  const [description, setDescription] = useState('');
  const [images, setImages] = useState<string[]>([]);
  const [loading, setLoading] = useState(false);
  const router = useRouter(); 

  const handleImagePick = async () => {
    let result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: true,
      aspect: [4, 3],
      quality: 1,
    });

    if (!result.canceled && result.assets && result.assets.length > 0) {
      const pickedImageUri = result.assets[0].uri;
      setImages([...images, pickedImageUri]);
    }
  };

  const handleImageDelete = (index: number) => {
    const updatedImages = [...images];
    updatedImages.splice(index, 1);
    setImages(updatedImages);
  };

  const handleSubmit = async () => {
    if (!description || images.length === 0) {
      Alert.alert('Error', 'Please fill in the description and upload at least one image.');
      return;
    }

    setLoading(true);

    try {
      await addDoc(collection(db, 'reportarea'), {
        description,
        images,
        createdAt: new Date(),
      });

      Alert.alert('Success', 'Report submitted successfully!', [
        {
          text: 'OK',
          onPress: () => {
            router.push("/user/(tabs)");
          },
        },
      ]);
    } catch (error) {
      console.error('Error submitting report:', error);
      Alert.alert('Error', 'Failed to submit the report. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()}>
          <Ionicons name="arrow-back" size={24} color="black" />
        </TouchableOpacity>
        <Text style={styles.title}>Report Area</Text>
      </View>

      <Text style={styles.subtitle}>
        Help us identify areas with potential for community planting or gardening! Please include the following details in your report:
        {"\n"}{"\n"}{"\n"}
        1. Exact location: Specify the address or nearest landmark to help us locate the area easily.{"\n"}{"\n"}
        2. Type of place: Is it an open field, an empty lot, part of a building, or something else?{"\n"}{"\n"}
        3. Building details (if applicable): Mention which part of the building (e.g., rooftop, balcony, or unused space).{"\n"}{"\n"}
        4. Current condition: Describe the area’s state (e.g., empty, overgrown, unused).{"\n"}{"\n"}
        5. Potential for growth: Why do you think this area is suitable for planting or community activities?{"\n"}{"\n"}
        6. Accessibility: Is the area accessible to the community? Are there any restrictions?{"\n"}{"\n"}
    </Text>

      <Text style={styles.inputLabel}>Description</Text>
      <TextInput
        style={[styles.input, { height: 100 }]}
        placeholder="Enter a description"
        value={description}
        onChangeText={setDescription}
        multiline
      />

      <View style={styles.imageContainer}>
        <Text style={styles.inputLabel}>Images</Text>
        <TouchableOpacity onPress={handleImagePick} style={styles.button}>
          <Text style={styles.buttonText}>Pick Images</Text>
        </TouchableOpacity>
        <ScrollView horizontal showsHorizontalScrollIndicator={false}>
          {images.map((image, index) => (
            <View key={index} style={styles.imageWrapper}>
              <Image source={{ uri: image }} style={styles.imageThumbnail} />
              <TouchableOpacity
                style={styles.deleteButton}
                onPress={() => handleImageDelete(index)}
              >
                <Ionicons name="close" size={20} color="white" />
              </TouchableOpacity>
            </View>
          ))}
        </ScrollView>
      </View>

      <TouchableOpacity
        onPress={handleSubmit}
        style={[styles.button, loading && { backgroundColor: '#ccc' }]}
        disabled={loading}
      >
        <Text style={styles.buttonText}>{loading ? 'Submitting...' : 'Submit Report'}</Text>
      </TouchableOpacity>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    padding: 20,
    backgroundColor: '#fff',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginLeft: 10,
  },
  subtitle: {
    fontSize: 16,
    color: '#555',
    marginBottom: 15,
  },
  inputLabel: {
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  input: {
    height: 45,
    borderColor: '#ddd',
    borderWidth: 1,
    marginBottom: 15,
    paddingLeft: 10,
    borderRadius: 5,
    backgroundColor: '#f9f9f9',
  },
  imageContainer: {
    marginBottom: 20,
  },
  imageWrapper: {
    position: 'relative',
  },
  imageThumbnail: {
    width: 100,
    height: 100,
    marginRight: 10,
    borderRadius: 5,
  },
  deleteButton: {
    position: 'absolute',
    top: 5,
    right: 5,
    borderRadius: 15,
    padding: 5,
  },
  button: {
    backgroundColor: '#007BFF',
    padding: 10,
    marginBottom: 10,
    borderRadius: 5,
    alignItems: 'center',
  },
  buttonText: {
    color: 'white',
    fontSize: 16,
  },
});

export default ReportArea;
