import React, { useEffect, useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { db } from '../../src/firebaseConfig';
import { collection, getDocs } from 'firebase/firestore';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons'; // For the back button

interface PlotTypeData {
  id: string;
  type: string;
}

interface PlotPPData {
  id: string;
  period: number;
  price: number;
}

const SetPlotAttributes = () => {
  const router = useRouter();
  const [plotTypes, setPlotTypes] = useState<PlotTypeData[]>([]);
  const [plotPP, setPlotPP] = useState<PlotPPData[]>([]);
  const [uniqueTypes, setUniqueTypes] = useState<string[]>([]);

  useEffect(() => {
    const fetchPlotData = async () => {
      try {
        // Fetch 'type' data from 'plotsettype'
        const typeSnapshot = await getDocs(collection(db, 'plotsettype'));
        const fetchedTypes: PlotTypeData[] = typeSnapshot.docs.map((doc) => ({
          id: doc.id,
          type: doc.data().type,
        }));
        setPlotTypes(fetchedTypes);

        // Fetch 'period' and 'price' data from 'plotsetpp'
        const ppSnapshot = await getDocs(collection(db, 'plotsetpp'));
        const fetchedPP: PlotPPData[] = ppSnapshot.docs.map((doc) => ({
          id: doc.id,
          period: doc.data().period,
          price: doc.data().price,
        }));
        setPlotPP(fetchedPP);

        // Extract unique type names for the summary display
        const types = Array.from(new Set(fetchedTypes.map((item) => item.type)));
        setUniqueTypes(types);
      } catch (error) {
        console.error("Error fetching plot data:", error);
      }
    };
    fetchPlotData();
  }, []);

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.push('/admin/plots/manageplots')}>
          <Ionicons name="arrow-back" size={24} color="black" />
        </TouchableOpacity>
        <Text style={styles.title}>Plot Attributes</Text>
        <TouchableOpacity onPress={() => router.push('/admin/plots/setplotattributes')}>
          <Text style={styles.editButton}>Edit</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.summaryTable}>
        <View style={styles.tableHeader}>
          <Text style={styles.tableColumn}>Type</Text>
          <Text style={styles.tableColumn}>Period (Years)</Text>
          <Text style={styles.tableColumn}>Price (RM)</Text>
        </View>
        {uniqueTypes.map((type) => (
          <React.Fragment key={type}>
            {plotPP.map((ppItem, index) => (
              <View key={`${type}-${ppItem.id}`} style={styles.tableRow}>

                {index === 0 && (
                  <Text style={[styles.tableCell, styles.mergedType]}>{type}</Text>
                )}
                {index !== 0 && <Text style={styles.tableCell}></Text>}
                <Text style={styles.tableCell}>{ppItem.period}</Text>
                <Text style={styles.tableCell}>{ppItem.price}</Text>
              </View>
            ))}
          </React.Fragment>
        ))}
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: { padding: 16, backgroundColor: '#fff', flex: 1 },
  header: {
    justifyContent: 'space-between',
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 20,
  },
  title: {     
    fontSize: 20,
    fontWeight: 'bold',
    marginLeft: 10 },
  editButton: { fontSize: 16, color: 'blue' },
  summaryTable: { marginTop: 10 },
  tableHeader: {
    flexDirection: 'row',
    backgroundColor: '#f7f7f7',
    borderBottomWidth: 1,
    borderColor: '#ddd',
  },
  tableColumn: { flex: 1, padding: 8, fontWeight: 'bold' },
  tableRow: { flexDirection: 'row', borderBottomWidth: 1, borderColor: '#ddd' },
  tableCell: { flex: 1, padding: 8 },
  mergedType: {
    borderRightWidth: 0,
    fontWeight: 'bold',
    textAlign: 'center',
  },
});

export default SetPlotAttributes;
