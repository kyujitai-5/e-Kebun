import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ActivityIndicator,
  Image,
  ScrollView,
  FlatList,
  TouchableOpacity,
  Modal,
} from 'react-native';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { db } from '../../src/firebaseConfig';
import { doc, getDoc, collection, getDocs, setDoc, deleteDoc, query, where } from 'firebase/firestore';
import { Ionicons } from '@expo/vector-icons';

interface Location {
  state: string;
  city: string;
  postcode: number;
  section: string;
}

interface Plot {
  plotNumber: string; // User-friendly ID
  plotDocId: string;  // Auto-generated doc ID
  status: string;
  type: string;
}

interface PlotDetails {
  name: string;
  description: string;
  images: string[];
  location: Location;
  plots: Plot[];
}

const ArchivedPlotAreaDetails = () => {
  const { id } = useLocalSearchParams();
  const router = useRouter();
  const [plotDetails, setPlotDetails] = useState<PlotDetails | null>(null);
  const [loading, setLoading] = useState(true);
  const [modalVisible, setModalVisible] = useState(false);
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [isArchived, setIsArchived] = useState(false); // To check if the plot area is archived

  useEffect(() => {
    const fetchPlotDetails = async () => {
      try {
        // First, try fetching the plot area from the 'plotarea' collection
        let plotDoc = await getDoc(doc(db, 'plotarea', id as string));

        // If it's not found in 'plotarea', try the 'archivedplotarea' collection
        if (!plotDoc.exists()) {
          console.log('Plot not found in plotarea, checking archivedplotarea...');
          plotDoc = await getDoc(doc(db, 'archivedplotarea', id as string));
          if (plotDoc.exists()) {
            setIsArchived(true); // Mark as archived
            console.log('Found archived plot area:', plotDoc.data());
          } else {
            console.log('No plot found in either collection');
            return;
          }
        } else {
          console.log('Found plot area in plotarea collection');
        }

        const data = plotDoc.data() as Omit<PlotDetails, 'plots'>;

        // Get the archived plots related to this plot area
        const plotsQuery = query(
          collection(db, 'archivedplots'),
          where('plotAreaId', '==', id)
        );
        const plotsSnapshot = await getDocs(plotsQuery);

        if (plotsSnapshot.empty) {
          console.log('No archived plots found for this plot area.');
        } else {
          const plots = plotsSnapshot.docs.map((doc) => ({
            plotNumber: doc.data().plotNumber,
            plotDocId: doc.id,
            status: doc.data().status,
            type: doc.data().type,
          }));

          console.log('Fetched archived plots:', plots);
          setPlotDetails({ ...data, plots });
        }
      } catch (error) {
        console.error('Error fetching plot details:', error);
      } finally {
        setLoading(false);
      }
    };

    if (id) {
      fetchPlotDetails();
    }
  }, [id]);

  if (loading) {
    return <ActivityIndicator size="large" color="#007BFF" />;
  }

  if (!plotDetails) {
    return <Text style={styles.noDataText}>Plot details not found.</Text>;
  }

  const handleUnarchive = async () => {
    try {
      // Fetch the archived plot area data
      const archivedPlotAreaDoc = await getDoc(doc(db, 'archivedplotarea', id as string));
      if (archivedPlotAreaDoc.exists()) {
        const data = archivedPlotAreaDoc.data();
        
        console.log('Archived Plot Data:', data); // Log the full data to inspect its structure
  
        // Ensure plotQuantities is an array, otherwise fallback to an empty array
        const plotQuantities = Array.isArray(data.plotQuantities) ? data.plotQuantities : [];
        
        if (plotQuantities.length === 0) {
          console.log('No plot quantities found or invalid data structure.');
        }
  
        // Default plot quantities for all types to 1 (adjust as needed)
        const updatedPlotQuantities = plotQuantities.map((plotType: any) => ({
          ...plotType,
          quantity: 1,
        }));
  
        // Add the plot area back to the normal collection
        console.log('Attempting to unarchive plot area to plotarea collection...');
        await setDoc(doc(db, 'plotarea', id as string), {
          ...data,
          plotQuantities: updatedPlotQuantities,
        });
  
        // Remove the plot area from the archived collection
        console.log('Attempting to remove plot area from archivedplotarea collection...');
        await deleteDoc(doc(db, 'archivedplotarea', id as string));
  
        alert('Plot area successfully unarchived!');
        router.push('/admin/plots/manageplots');
      } else {
        console.log('Error: Plot area not found in archivedplotarea.');
        alert('Plot area not found in archived collection.');
      }
    } catch (error) {
      console.error('Error unarchiving plot area:', error); // More detailed error logging
      alert('Failed to unarchive the plot area. Please try again.');
    }
  };  
  

  return (
    <FlatList
      data={[{}]}
      keyExtractor={(_, index) => index.toString()}
      renderItem={() => (
        <View style={styles.container}>
          <View style={styles.header}>
            <TouchableOpacity onPress={() => router.push('/admin/plots/archivedplotareas')}>
              <Ionicons name="arrow-back" size={24} color="#000" />
            </TouchableOpacity>
            {isArchived && (
              <TouchableOpacity onPress={handleUnarchive}>
                <Text style={styles.editButton}>Unarchive</Text>
              </TouchableOpacity>
            )}
          </View>

          <Text style={styles.detailText}>ID: {id}</Text>
          <Text style={styles.detailText}>Name: {plotDetails.name}</Text>
          <Text style={styles.detailText}>Description: {plotDetails.description}</Text>

          <Text style={styles.sectionTitle}>Location</Text>
          <Text style={styles.detailText}>State: {plotDetails.location.state}</Text>
          <Text style={styles.detailText}>City: {plotDetails.location.city}</Text>
          <Text style={styles.detailText}>Postcode: {plotDetails.location.postcode}</Text>
          <Text style={styles.detailText}>Section: {plotDetails.location.section}</Text>

          <Text style={styles.sectionTitle}>Images</Text>
          <FlatList
            data={plotDetails.images}
            horizontal
            keyExtractor={(item, index) => index.toString()}
            renderItem={({ item }) => (
              <TouchableOpacity
                onPress={() => {
                  setSelectedImage(item);
                  setModalVisible(true);
                }}
              >
                <Image source={{ uri: item }} style={styles.imageThumbnail} />
              </TouchableOpacity>
            )}
          />
          <Modal visible={modalVisible} transparent={true} onRequestClose={() => setModalVisible(false)}>
            <View style={styles.modalContainer}>
              <TouchableOpacity onPress={() => setModalVisible(false)} style={styles.closeButton}>
                <Text style={styles.closeButtonText}>×</Text>
              </TouchableOpacity>
              <Image source={selectedImage ? { uri: selectedImage } : undefined} style={styles.modalImage} />
            </View>
          </Modal>

          <Text style={styles.sectionTitle}>Archived Plots</Text>
          <FlatList
            data={plotDetails.plots}
            keyExtractor={(item) => item.plotDocId}
            renderItem={({ item }) => (
              <TouchableOpacity
                style={styles.plotContainer}
                onPress={() => {
                  router.push(`/admin/plots/plotrentaldetails?plotId=${item.plotDocId}`);
                }}
              >
                <Text style={styles.detailText}>Plot Number: {item.plotNumber}</Text>
                <Text style={styles.detailText}>Status: {item.status}</Text>
                <Text style={styles.detailText}>Type: {item.type}</Text>
              </TouchableOpacity>
            )}
          />
        </View>
      )}
    />
  );
};

const styles = StyleSheet.create({
  container: {
    padding: 20,
    backgroundColor: '#fff',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 20,
  },
  backButton: {
    padding: 5,
  },
  editButton: {
    fontSize: 18,
    color: '#007BFF',
  },
  detailText: {
    fontSize: 16,
    marginBottom: 5,
  },
  noDataText: {
    fontSize: 18,
    color: '#555',
    textAlign: 'center',
    marginTop: 20,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    marginTop: 20,
    marginBottom: 10,
  },
  imageScroll: {
    marginVertical: 10,
  },
  imageThumbnail: {
    width: 100,
    height: 100,
    marginRight: 10,
    borderRadius: 5,
  },
  modalContainer: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.9)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  closeButton: {
    position: 'absolute',
    top: 20,
    right: 20,
    zIndex: 1,
  },
  closeButtonText: {
    fontSize: 30,
    color: '#fff',
  },
  modalImage: {
    width: '90%',
    height: '80%',
    resizeMode: 'contain',
  },
  plotContainer: {
    padding: 10,
    backgroundColor: '#f0f0f0',
    marginVertical: 5,
    borderRadius: 5,
  },
});

export default ArchivedPlotAreaDetails;
