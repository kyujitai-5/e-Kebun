// addnewarea.tsx

import React, { useState, useEffect } from 'react';
import { View, Text, TextInput, TouchableOpacity, Alert, Image, FlatList, StyleSheet, ScrollView } from 'react-native';
import { db } from '../../src/firebaseConfig';
import { collection, addDoc, getDocs, doc, setDoc } from 'firebase/firestore';
import { useRouter } from 'expo-router';
import * as ImagePicker from 'expo-image-picker';
import RNPickerSelect from 'react-native-picker-select';
import { Ionicons } from '@expo/vector-icons';

interface PlotTypeData {
  id: string;
  type: string;
}

const AddNewPlot = () => {
  const router = useRouter();
  const [plotAreaId, setPlotAreaId] = useState('');
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [images, setImages] = useState<string[]>([]);
  const [plotTypes, setPlotTypes] = useState<PlotTypeData[]>([]);
  const [plotQuantities, setPlotQuantities] = useState<{ [key: string]: string }>({});
  const [selectedImageIndex, setSelectedImageIndex] = useState<number | null>(null);
  const [state, setState] = useState('');
  const [city, setCity] = useState('');
  const [postcode, setPostcode] = useState('');
  const [section, setSection] = useState('');
  const [availableStates, setAvailableStates] = useState<string[]>([]);
  const [availableCities, setAvailableCities] = useState<string[]>([]);
  const [availablePostcodes, setAvailablePostcodes] = useState<string[]>([]);
  const [availableSections, setAvailableSections] = useState<string[]>([]);

  useEffect(() => {
    const fetchPlotTypes = async () => {
      try {
        const typeSnapshot = await getDocs(collection(db, 'plotsettype'));
        const fetchedTypes = typeSnapshot.docs.map((doc) => ({
          id: doc.id,
          type: doc.data().type,
        }));
        setPlotTypes(fetchedTypes);
  
        // Fetch plot area IDs from both collections
        const plotAreaSnapshot = await getDocs(collection(db, 'plotarea'));
        const archivedPlotAreaSnapshot = await getDocs(collection(db, 'archiveplotarea'));
  
        // Combine plot area and archived plot area IDs
        const plotAreaIds = plotAreaSnapshot.docs.map((doc) => doc.id);
        const archivedPlotAreaIds = archivedPlotAreaSnapshot.docs.map((doc) => doc.id);
  
        // Extract numbers from the IDs, and get the largest number
        const allPlotIds = [...plotAreaIds, ...archivedPlotAreaIds];
        const plotAreaNumbers = allPlotIds
          .map((id) => parseInt(id.replace('PA', '')))
          .filter((num) => !isNaN(num)); // Ensure to handle invalid cases
  
        // Get the maximum plot area number and generate the new ID
        const maxPlotNumber = Math.max(...plotAreaNumbers);
        setPlotAreaId(`PA${(maxPlotNumber + 1).toString().padStart(3, '0')}`);
      } catch (error) {
        console.error("Error fetching plot data:", error);
      }
    };
  
    fetchPlotTypes();
  }, []);
  

  useEffect(() => {
    const fetchLocationData = async () => {
      try {
        const locationSnapshot = await getDocs(collection(db, 'location'));
        const states: string[] = [];
        locationSnapshot.forEach((doc) => {
          const state = doc.data().state;
          if (!states.includes(state)) {
            states.push(state);
          }
        });
        setAvailableStates(states);
      } catch (error) {
        console.error("Error fetching location data:", error);
      }
    };

    fetchLocationData();
  }, []);

  useEffect(() => {
    if (state) {
      const fetchCities = async () => {
        try {
          const citySnapshot = await getDocs(collection(db, 'location'));
          const cities: string[] = [];
          citySnapshot.forEach((doc) => {
            const city = doc.data().city;
            if (doc.data().state === state && !cities.includes(city)) {
              cities.push(city);
            }
          });
          setAvailableCities(cities);
        } catch (error) {
          console.error("Error fetching cities:", error);
        }
      };
      fetchCities();
    }
  }, [state]);

  useEffect(() => {
    if (city) {
      const fetchPostcodes = async () => {
        try {
          const postcodeSnapshot = await getDocs(collection(db, 'location'));
          const postcodes: string[] = [];
          postcodeSnapshot.forEach((doc) => {
            const postcode = doc.data().postcode;
            if (doc.data().city === city && !postcodes.includes(postcode)) {
              postcodes.push(postcode);
            }
          });
          setAvailablePostcodes(postcodes);
        } catch (error) {
          console.error("Error fetching postcodes:", error);
        }
      };
      fetchPostcodes();
    }
  }, [city]);

  useEffect(() => {
    if (postcode) {
      const fetchSections = async () => {
        try {
          const sectionSnapshot = await getDocs(collection(db, 'location'));
          const sections: string[] = [];
          sectionSnapshot.forEach((doc) => {
            const section = doc.data().section;
            if (doc.data().postcode === postcode && !sections.includes(section)) {
              sections.push(section);
            }
          });
          setAvailableSections(sections);
        } catch (error) {
          console.error("Error fetching sections:", error);
        }
      };
      fetchSections();
    }
  }, [postcode, section]);

  const handleImageUpload = async () => {
    const permissionResult = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (!permissionResult.granted) {
      Alert.alert("Permission Denied", "You've refused to allow this app to access your photos!");
      return;
    }

    const pickerResult = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsMultipleSelection: true,
      selectionLimit: 5 - images.length,
    });

    if (!pickerResult.canceled) {
      const newImages = pickerResult.assets.map((asset) => asset.uri);
      setImages((prevImages) => [...prevImages, ...newImages]);
    }
  };

  const onImagePress = (index: number) => {
    if (selectedImageIndex === index) {
      setImages((prevImages) => prevImages.filter((_, i) => i !== index));
      setSelectedImageIndex(null);
    } else {
      setSelectedImageIndex(index);
    }
  };

  const handleSave = async () => {
    if (!name.trim() || !description.trim() || Object.keys(plotQuantities).length === 0) {
      Alert.alert("Missing Information", "Please fill all fields and specify quantities.");
      return;
    }
  
    try {
      // Prepare the plotAvailability object to match plotQuantities
      const plotAvailability = Object.keys(plotQuantities).reduce((acc, type) => {
        acc[type] = Number(plotQuantities[type]); // Match availability to quantities
        return acc;
      }, {} as { [key: string]: number });
  
      // Save the plot area details along with plotAvailability
      await setDoc(doc(collection(db, 'plotarea'), plotAreaId), { 
        name, 
        description, 
        images, 
        location: { state, city, postcode, section },
        plotQuantities,    // Save plotQuantities as part of the plot area
        plotAvailability   // Save plotAvailability with matching quantities
      });
  
      // Save each plot type and its quantity as individual documents in the root 'plots' collection
      for (const [type, quantity] of Object.entries(plotQuantities)) {
        for (let i = 1; i <= Number(quantity); i++) {
          const plotNumber = `P${i.toString().padStart(3, '0')}`;
          await addDoc(collection(db, 'plots'), {
            plotAreaId,
            plotNumber,
            type,
            status: 'available',  // Initially set the status to available
          });
        }
      }
  
      Alert.alert("Success", "Plot area and plots added successfully!");
      router.push('/admin/plots/manageplots');
    } catch (error) {
      console.error("Error adding plot area and plots:", error);
      Alert.alert("Error", "Could not add plot area. Please try again.");
    }
  };  

  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.push('/admin/plots/manageplots')}>
          <Ionicons name="arrow-back" size={24} color="#000" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Add New Plot Area</Text>
      </View>

      <Text style={styles.label}>Plot Area ID</Text>
      <Text style={styles.input}>{plotAreaId}</Text>

      <Text style={styles.label}>Name</Text>
      <TextInput
        style={styles.input}
        placeholder="Name"
        value={name}
        onChangeText={setName}
      />

      <Text style={styles.label}>Description</Text>
      <TextInput
        style={[styles.input, styles.textArea]}
        placeholder="Description"
        value={description}
        onChangeText={setDescription}
        multiline
      />

      <Text style={styles.label}>Location</Text>
      <RNPickerSelect
        placeholder={{ label: 'Select State', value: '' }}
        value={state}
        onValueChange={(value) => setState(value)}
        items={availableStates.map((state) => ({ label: state, value: state }))}
        style={pickerStyles}
      />
      <RNPickerSelect
        placeholder={{ label: 'Select City', value: '' }}
        value={city}
        onValueChange={(value) => setCity(value)}
        items={availableCities.map((city) => ({ label: city, value: city }))}
        style={pickerStyles}
      />
      <RNPickerSelect
        placeholder={{ label: 'Select Postcode', value: '' }}
        value={postcode}
        onValueChange={(value) => setPostcode(value)}
        items={availablePostcodes.map((postcode) => ({ label: postcode, value: postcode }))}
        style={pickerStyles}
      />
      <RNPickerSelect
        placeholder={{ label: 'Select Section', value: '' }}
        value={section}
        onValueChange={(value) => setSection(value)}
        items={availableSections.map((section) => ({ label: section, value: section }))}
        style={pickerStyles}
      />

      <Text style={styles.label}>Plot Quantities</Text>
      {plotTypes.map((item) => (
        <View key={item.id} style={styles.plotQuantity}>
          <Text style={styles.plotType}>{item.type}</Text>
          <TextInput
            style={styles.input}
            placeholder="Quantity"
            keyboardType="numeric"
            value={plotQuantities[item.type] || ''}
            onChangeText={(value) =>
              setPlotQuantities((prev) => ({ ...prev, [item.type]: value }))
            }
          />
        </View>
      ))}

      <Text style={styles.label}>Images</Text>
      <ScrollView horizontal>
        {images.map((item, index) => (
          <TouchableOpacity key={index} onPress={() => onImagePress(index)}>
            <Image source={{ uri: item }} style={styles.image} />
            {selectedImageIndex === index && (
              <Text style={styles.deleteIcon}>X</Text>
            )}
          </TouchableOpacity>
        ))}
      </ScrollView>
      <TouchableOpacity onPress={handleImageUpload} style={styles.uploadButton}>
        <Text style={styles.uploadText}>Upload Images</Text>
      </TouchableOpacity>

      <View style={styles.buttonContainer}>
        <TouchableOpacity style={styles.button} onPress={handleSave}>
          <Text style={styles.buttonText}>Add Plot Area</Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#fff',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 20,
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    marginLeft: 10,
  },
  backButton: {
    padding: 5,
  },
  label: {
    marginTop: 20,
    fontSize: 20,
    fontWeight: '600',
    color: '#333',
  },
  input: {
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 8,
    padding: 12,
    marginTop: 10,
    fontSize: 16,
    color: '#333',
  },
  textArea: {
    height: 100,
    textAlignVertical: 'top',
  },
  plotQuantity: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginVertical: 10,
  },
  plotType: {
    fontSize: 16,
    fontWeight: '600',
    color: '#333',
  },
  image: {
    width: 100,
    height: 100,
    marginRight: 10,
    borderRadius: 8,
  },
  deleteIcon: {
    position: 'absolute',
    top: 0,
    right: 0,
    backgroundColor: 'red',
    color: 'white',
    fontSize: 16,
    padding: 5,
    borderRadius: 15,
  },
  uploadButton: {
    backgroundColor: '#4CAF50',
    padding: 12,
    borderRadius: 8,
    alignItems: 'center',
    marginTop: 20,
  },
  uploadText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '600',
  },
  buttonContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 30,
  },
  button: {
    backgroundColor: '#007BFF',
    padding: 15,
    borderRadius: 8,
    flex: 1,
    marginHorizontal: 5,
    alignItems: 'center',
  },
  buttonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '600',
  },
});

// Picker style
const pickerStyles = {
  inputIOS: {
    fontSize: 16,
    paddingVertical: 12,
    paddingHorizontal: 10,
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 8,
    backgroundColor: '#fff',
    color: '#333',
    marginTop: 10,
  },
  inputAndroid: {
    fontSize: 16,
    paddingVertical: 12,
    paddingHorizontal: 10,
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 8,
    backgroundColor: '#fff',
    color: '#333',
    marginTop: 10,
  },
};

export default AddNewPlot;
